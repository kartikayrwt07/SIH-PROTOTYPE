import { v as lazyRouteComponent, y as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-VuBbPgMI.js
var $$splitComponentImporter = () => import("./_id-CAXM5J0y.mjs");
var Route = createFileRoute("/cases/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
