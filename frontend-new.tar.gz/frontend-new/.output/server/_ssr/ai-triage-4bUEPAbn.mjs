import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { O as runTriage, T as listCases, i as Button, s as applyTriage, u as checkDuplicates } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { w as ExternalLink } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-f_2O8qQw.mjs";
import { t as PriorityMark } from "./PriorityMark-zbBOy4ZR.mjs";
import { t as Textarea } from "./textarea-BhA-x7XG.mjs";
import { t as Label } from "./label-DOLtOnoa.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
import { t as EmptyState } from "./EmptyState-BUPzGk3F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-triage-4bUEPAbn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRESET_CASES = [
	{
		label: "Approval Violation (APPR)",
		text: "Institution has unapproved intake capacity in B.Tech Computer Science. Approved intake is 60 students but college enrolled 120 students. Land and building norms violated, faculty ratio is 1:32 without required laboratory infrastructure."
	},
	{
		label: "Hostel Ragging (STU)",
		text: "Hostel senior students physically harassed first-year students during midnight inspection. Serious ragging incident compromising mental health and safety. Hostel wardens failed to intervene and suppressed student complaints."
	},
	{
		label: "Faculty 7th CPC (FDC)",
		text: "College management refusing to implement AICTE 7th CPC pay commission scales for teaching faculty. Assistant professors have 7 months salary arrears pending, and provident fund contributions have been deducted but not deposited with EPFO."
	},
	{
		label: "Capitation Fee (FIN)",
		text: "College demanding 2.5 lakhs mandatory donation and excess tuition fee beyond statutory fee committee limits. College authorities are withholding original marksheets and caution deposit after student requested admission cancellation."
	}
];
function SmartTriageView() {
	const queryClient = useQueryClient();
	const { role } = useRole();
	const canApply = role === "ADMIN" || role === "SUPERVISOR";
	const [grievanceText, setGrievanceText] = (0, import_react.useState)("");
	const [targetCaseRef, setTargetCaseRef] = (0, import_react.useState)("");
	const [triageResult, setTriageResult] = (0, import_react.useState)(null);
	const [duplicates, setDuplicates] = (0, import_react.useState)(null);
	const { data: casesData } = useQuery({
		queryKey: ["activeCasesForTriage"],
		queryFn: () => listCases({ page_size: 50 }),
		staleTime: 6e4
	});
	const availableCases = casesData?.items ?? [];
	const triageMutation = useMutation({
		mutationFn: async (text) => {
			const [triageRes, dupRes] = await Promise.all([runTriage(text), checkDuplicates({
				subject: text.slice(0, 100),
				description: text
			})]);
			return {
				triageRes,
				dupRes
			};
		},
		onSuccess: ({ triageRes, dupRes }) => {
			setTriageResult(triageRes);
			setDuplicates(dupRes);
		},
		onError: (err) => {
			toast.error(err?.message || "Failed to analyze grievance narrative.");
		}
	});
	const applyMutation = useMutation({
		mutationFn: async () => {
			if (!triageResult) return;
			if (targetCaseRef) return applyTriage(targetCaseRef, triageResult);
			return null;
		},
		onSuccess: () => {
			if (targetCaseRef) {
				queryClient.invalidateQueries({ queryKey: ["case", targetCaseRef] });
				queryClient.invalidateQueries({ queryKey: ["cases"] });
			}
			toast.success("Recommendations applied");
		},
		onError: (err) => {
			toast.error(err?.message || "Failed to apply recommendations.");
		}
	});
	const handleRunTriage = (e) => {
		if (e) e.preventDefault();
		if (!grievanceText.trim()) return;
		triageMutation.mutate(grievanceText.trim());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Smart triage",
			description: "Test classification and check for duplicates before registering a case."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 lg:grid-cols-[55%_45%] gap-10 items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "grievance-text",
								className: "font-serif text-base font-semibold text-[var(--color-ink)] tracking-tight",
								children: "Grievance narrative"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 flex-wrap",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-[var(--color-text-muted)]",
									children: "Sample:"
								}), PRESET_CASES.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setGrievanceText(preset.text);
										triageMutation.mutate(preset.text);
									},
									className: "text-[11px] px-2.5 py-1 border border-[var(--color-rule)] bg-surface hover:bg-[var(--color-page)] hover:border-[var(--color-text-muted)] rounded-[4px] text-[var(--color-text-secondary)] transition-colors cursor-pointer",
									children: preset.label
								}, preset.label))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "grievance-text",
							placeholder: "Paste grievance complaint narrative, institutional allegations, or inspection observations...",
							value: grievanceText,
							onChange: (e) => setGrievanceText(e.target.value),
							rows: 7,
							className: "text-xs bg-surface border-[var(--color-rule)] rounded-[6px] leading-relaxed p-3.5 focus-visible:ring-1 focus-visible:ring-[var(--color-action)]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => handleRunTriage(),
							disabled: triageMutation.isPending || !grievanceText.trim(),
							className: "h-8.5 px-5 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
							children: triageMutation.isPending ? "Analyzing narrative..." : "Run triage"
						}) })
					]
				}), triageResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-6 border-t border-[var(--color-rule)] space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-base font-semibold text-[var(--color-ink)] tracking-tight",
							children: "Classification result"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 bg-white/85 dark:bg-[#0B0813]/90 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[12px] space-y-5 shadow-[0_4px_24px_rgba(112,82,200,0.04)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-baseline justify-between gap-2 pb-3 border-b border-[var(--color-rule)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-[var(--color-text-muted)] uppercase tracking-wider font-medium mb-1",
										children: "Recommended bureau"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-base font-semibold text-[var(--color-ink)]",
										children: triageResult.recommended_bureau_name
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-semibold text-[var(--color-action)] bg-gradient-to-r from-[var(--color-page)] to-surface dark:from-[#05040A] dark:to-[#0B0813] px-3 py-1 border border-[var(--color-rule)] dark:border-[#201533] rounded-[6px] tabular-nums shadow-xs",
										children: [Math.round(triageResult.confidence * 100), "% confidence"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 pb-3 border-b border-[var(--color-rule)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-[var(--color-text-muted)] uppercase tracking-wider font-medium",
										children: "Recommended priority"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: triageResult.recommended_priority })]
								}),
								triageResult.matched_keywords && triageResult.matched_keywords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-[var(--color-text-muted)] uppercase tracking-wider font-medium",
										children: "Matched keywords & signals"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2",
										children: triageResult.matched_keywords.map((kw) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] px-2.5 py-1 border border-[var(--color-rule)] bg-[var(--color-page)] rounded-[4px] text-[var(--color-text-secondary)]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium text-[var(--color-text-primary)]",
													children: kw.keyword
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono tabular-nums text-[var(--color-text-muted)] ml-1",
													children: [Math.round(kw.weight * 100), "%"]
												})
											]
										}, kw.keyword))
									})]
								})
							]
						}),
						canApply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 space-y-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-medium text-[var(--color-text-secondary)] block",
									children: "Target complaint case (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: targetCaseRef,
									onValueChange: (val) => setTargetCaseRef(val),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select existing case to update, or apply globally" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "",
										className: "text-xs",
										children: "None (Apply into registration state)"
									}), availableCases.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: c.case_reference_id,
										className: "text-xs",
										children: [
											c.case_reference_id,
											" — ",
											c.institution_name
										]
									}, c.case_reference_id))] })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: () => applyMutation.mutate(),
								disabled: applyMutation.isPending,
								className: "h-8.5 px-4 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
								children: applyMutation.isPending ? "Applying..." : "Apply recommendations"
							})]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 lg:border-l border-[var(--color-rule)] lg:pl-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-[var(--color-rule)] pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)] tracking-tight",
						children: "Potential duplicates"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-muted)] mt-0.5",
						children: "Automated lexical overlap check across registered cases."
					})]
				}), !duplicates || duplicates.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No similar cases found in the repository.",
					instruction: "Run triage on a complaint narrative to scan registered records for duplicate allegations."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-[var(--color-rule)]",
					children: duplicates.map((match) => {
						const simPct = Math.round(match.similarity_score * 100);
						const isHighRisk = simPct > 70;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onClick: () => window.open(`/cases/${match.case_reference_id}`, "_blank"),
							className: "py-3.5 first:pt-1 last:pb-1 space-y-2 cursor-pointer hover:bg-[var(--color-page)] -mx-2.5 px-2.5 rounded-[4px] transition-colors",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-[var(--color-text-secondary)] font-medium",
											children: match.case_reference_id
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3 w-3 text-[var(--color-text-muted)]" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `text-xs font-semibold tabular-nums px-2 py-0.5 rounded-[4px] ${isHighRisk ? "text-[var(--sla-overdue-text)] bg-[var(--sla-overdue-bg)]" : "text-[var(--color-text-secondary)] bg-[var(--color-page)] border border-[var(--color-rule)]"}`,
										children: [simPct, "% match"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-serif text-xs font-semibold text-[var(--color-ink)] line-clamp-1",
									children: match.subject
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-[var(--color-text-muted)] line-clamp-1",
									children: match.institution_name
								}),
								match.matched_keywords && match.matched_keywords.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5 pt-1",
									children: match.matched_keywords.slice(0, 4).map((kw) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] px-2 py-0.5 bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[2px] text-[var(--color-text-secondary)]",
										children: kw
									}, kw))
								})
							]
						}, match.case_reference_id);
					})
				})]
			})]
		})]
	});
}
var SplitComponent = SmartTriageView;
//#endregion
export { SplitComponent as component };
