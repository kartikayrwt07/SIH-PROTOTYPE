import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn, n as ALL_STATUSES } from "./button-1CfnPKN-.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function LifecycleStrip({ status, variant = "compact", dueDate, createdAt, className }) {
	const isComplete = status === "Resolved" || status === "Closed";
	const currentIndex = ALL_STATUSES.indexOf(status);
	const isOverdue = dueDate ? new Date(dueDate).getTime() < Date.now() : false;
	let slaPercentage = null;
	if (!isComplete && dueDate && createdAt) {
		const start = new Date(createdAt).getTime();
		const end = new Date(dueDate).getTime();
		const now = Date.now();
		if (end > start) slaPercentage = Math.min(100, Math.max(0, Math.round((now - start) / (end - start) * 100)));
	}
	if (variant === "compact") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("inline-flex items-center gap-2", className),
		role: "group",
		"aria-label": `Lifecycle stage: ${status}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-1",
			children: ALL_STATUSES.map((stage, idx) => {
				const isFilledInk = isComplete || idx < currentIndex;
				const isCurrentAction = !isComplete && idx === currentIndex;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-1.5 w-2.5 rounded-[1px] transition-colors", isFilledInk ? "bg-[var(--color-ink)]" : isCurrentAction ? "bg-[var(--color-action)] shadow-xs" : "bg-[var(--color-rule)]/70"),
					role: "img",
					"aria-label": `Stage ${idx + 1}: ${stage} (${isCurrentAction ? "Current" : isFilledInk ? "Completed" : "Pending"})`,
					title: `${idx + 1}. ${stage}`
				}, stage);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-[var(--color-text-secondary)] font-medium truncate max-w-[140px]",
			children: status
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("w-full space-y-3 pt-1", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-9 gap-2",
				children: ALL_STATUSES.map((stage, idx) => {
					const isFilledInk = isComplete || idx < currentIndex;
					const isCurrentAction = !isComplete && idx === currentIndex;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-2 w-full rounded-[2px] transition-all", isFilledInk ? "bg-[var(--color-ink)]" : isCurrentAction ? "bg-[var(--color-action)] shadow-xs ring-2 ring-[var(--color-action)]/25" : "bg-[var(--color-rule)]/50 border border-[var(--color-rule)]"),
							role: "img",
							"aria-label": `Stage ${idx + 1}: ${stage} (${isCurrentAction ? "Current" : isFilledInk ? "Completed" : "Pending"})`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("text-[11px] leading-tight line-clamp-2", isCurrentAction ? "text-[var(--color-action)] font-bold" : isFilledInk ? "text-[var(--color-ink)] font-semibold" : "text-[var(--color-text-muted)]"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[9px] mr-1 opacity-70",
								children: [idx + 1, "."]
							}), stage]
						})]
					}, stage);
				})
			}), !isComplete && dueDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between text-xs pt-3 border-t border-[var(--color-rule)] text-[var(--color-text-secondary)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2 w-2 rounded-full", isOverdue ? "bg-[var(--sla-overdue-text)]" : "bg-[var(--sla-ontrack-text)]") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: isOverdue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[var(--sla-overdue-text)] font-semibold",
							children: "SLA resolution deadline exceeded"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[var(--sla-ontrack-text)] font-medium",
							children: "Within statutory SLA resolution window"
						})
					})]
				}), slaPercentage !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums font-mono text-[var(--color-text-muted)] text-[11px]",
					children: [slaPercentage, "% of elapsed SLA time used"]
				})]
			})]
		})
	});
}
/** Formatter for SlaPill component presentation ("Overdue by 6 h", "Due in 31 h", "On track", "Completed", "No deadline") */
function formatSlaPillLabel(status, hours, isResolved = false, hasDueDate = true) {
	if (isResolved) return "Completed";
	if (!hasDueDate && (hours === null || hours === void 0)) return "No deadline";
	if (hours === null || hours === void 0) return "On track";
	const absHours = Math.abs(hours);
	if (hours < 0) {
		if (absHours >= 24) {
			const days = Math.floor(absHours / 24);
			const rem = Math.round(absHours % 24);
			return rem > 0 ? `Overdue by ${days} d ${rem} h` : `Overdue by ${days} d`;
		}
		return `Overdue by ${Math.max(1, Math.round(absHours))} h`;
	}
	if (status === "APPROACHING" || hours <= 48) {
		if (hours >= 24) {
			const days = Math.floor(hours / 24);
			const rem = Math.round(hours % 24);
			return rem > 0 ? `Due in ${days} d ${rem} h` : `Due in ${days} d`;
		}
		return `Due in ${Math.max(1, Math.round(hours))} h`;
	}
	return "On track";
}
function deriveSlaStatus(dueDate, isResolved = false) {
	if (isResolved || !dueDate) return {
		status: "ON_TRACK",
		hoursRemaining: null
	};
	const now = Date.now();
	const due = new Date(dueDate).getTime();
	if (isNaN(due)) return {
		status: "ON_TRACK",
		hoursRemaining: null
	};
	const diffHours = (due - now) / 36e5;
	if (diffHours < 0) return {
		status: "OVERDUE",
		hoursRemaining: diffHours
	};
	if (diffHours <= 48) return {
		status: "APPROACHING",
		hoursRemaining: diffHours
	};
	return {
		status: "ON_TRACK",
		hoursRemaining: diffHours
	};
}
function SlaPill({ status: explicitStatus, dueDate, hoursRemaining: explicitHours, className, isResolved = false }) {
	if (isResolved) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium tabular-nums whitespace-nowrap bg-sla-completed-bg text-sla-completed", className),
		children: "Completed"
	});
	let status = explicitStatus;
	let hours = explicitHours;
	if (!status) {
		const derived = deriveSlaStatus(dueDate, isResolved);
		status = derived.status;
		hours = derived.hoursRemaining;
	}
	const hasDueDate = !!dueDate;
	if (!hasDueDate && (hours === null || hours === void 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium tabular-nums whitespace-nowrap bg-sla-completed-bg text-sla-completed", className),
		children: "No deadline"
	});
	let styleClasses = "bg-sla-ontrack-bg text-sla-ontrack";
	if (status === "OVERDUE") styleClasses = "bg-sla-overdue-bg text-sla-overdue";
	else if (status === "APPROACHING") styleClasses = "bg-sla-approaching-bg text-sla-approaching";
	const label = formatSlaPillLabel(status ?? "ON_TRACK", hours, isResolved, hasDueDate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium tabular-nums whitespace-nowrap", styleClasses, className),
		children: label
	});
}
//#endregion
export { SlaPill as n, deriveSlaStatus as r, LifecycleStrip as t };
