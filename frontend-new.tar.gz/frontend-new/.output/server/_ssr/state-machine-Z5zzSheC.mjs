import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { C as isTerminal, S as isActive, T as listCases, a as TRANSITION_GUARD_RULES, i as Button, l as canTransition, m as getAllowedTransitions, n as ALL_STATUSES, t as ALLOWED_TRANSITIONS } from "./button-1CfnPKN-.mjs";
import { C as Eye, D as CircleQuestionMark, F as ArrowRight, I as Activity, O as CircleCheck, P as Check, S as FileCheck, b as Funnel, h as Lock, i as Undo2, k as CircleAlert, n as UserCheck, s as Sparkles, u as Repeat2, v as Inbox } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-f_2O8qQw.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as StatusMark } from "./StatusMark-DJcf1lip.mjs";
import { t as Label } from "./label-DOLtOnoa.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/state-machine-Z5zzSheC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_ICONS = {
	Received: Inbox,
	Registered: FileCheck,
	"Under Triage": Funnel,
	Assigned: UserCheck,
	"In Progress": Activity,
	"Awaiting Information": CircleQuestionMark,
	"Under Review": Eye,
	Resolved: CircleCheck,
	Closed: Lock
};
var STAGE_NUMBERS = {
	Received: "01",
	Registered: "02",
	"Under Triage": "03",
	Assigned: "04",
	"In Progress": "05",
	"Awaiting Information": "06",
	"Under Review": "07",
	Resolved: "08",
	Closed: "09"
};
var STATUS_DESCRIPTIONS = {
	Received: "Raw grievance intake logged",
	Registered: "Official AICTE ID issued",
	"Under Triage": "Jurisdiction & priority classified",
	Assigned: "Desk officer assigned in bureau",
	"In Progress": "Active inquiry & evidence collection",
	"Awaiting Information": "Documentary clarification pending",
	"Under Review": "Supervisory order review",
	Resolved: "Administrative order issued",
	Closed: "Permanently sealed ledger archive"
};
function StateGraph({ selectedStatus, onSelectStatus, caseCountsByStatus = {} }) {
	const allowedNext = ALLOWED_TRANSITIONS[selectedStatus] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white/85 dark:bg-[#0B0813]/90 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[12px] p-6 space-y-6 shadow-[0_4px_24px_rgba(112,82,200,0.03)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#ECE6F4] dark:border-[#201533]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)] flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Interactive state topology" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-sans font-medium px-2 py-0.5 rounded-full bg-[#FAF8FE] dark:bg-[#05040A] border border-[#ECE6F4] dark:border-[#201533] text-[var(--color-action)] shadow-xs",
							children: "9 Stages"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-muted)] mt-0.5",
						children: "Click any stage to simulate transition paths and evaluate statutory gate rules."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 text-xs text-[var(--color-text-secondary)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-[2px] bg-[var(--color-action)] shadow-[0_0_6px_rgba(112,82,200,0.35)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-[var(--color-ink)]",
									children: "Selected stage"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-[2px] bg-[var(--sla-ontrack-text)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Allowed transition" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-[2px] bg-[var(--color-text-muted)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Locked / Terminal" })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 bg-white/70 dark:bg-[#0B0813]/80 backdrop-blur-sm border border-[#ECE6F4] dark:border-[#201533] rounded-[8px] flex flex-wrap items-center justify-between gap-4 text-xs shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 h-8 rounded-[6px] bg-[var(--color-action)] text-white flex items-center justify-center font-mono font-bold text-xs shadow-[0_0_8px_rgba(112,82,200,0.35)]",
							children: STAGE_NUMBERS[selectedStatus]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-wider font-semibold text-[var(--color-text-muted)]",
							children: "Current stage focus"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-semibold text-sm text-[var(--color-ink)] flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: selectedStatus }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[11px] font-normal text-[var(--color-text-secondary)]",
								children: [
									"(",
									caseCountsByStatus[selectedStatus] ?? 0,
									" active cases)"
								]
							})]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-medium text-[var(--color-text-secondary)]",
							children: "Permitted forward paths:"
						}), allowedNext.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: allowedNext.map((next) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onSelectStatus(next),
								className: "px-2.5 py-1 bg-[#F0F9F4] dark:bg-[#163824]/40 border border-[#257D4E]/30 dark:border-[#34D399]/40 text-[#257D4E] dark:text-[#34D399] rounded-[4px] text-xs font-semibold hover:bg-[#E6F5EC] dark:hover:bg-[#163824]/70 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs",
								title: `Click to inspect transition to ${next}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									STAGE_NUMBERS[next],
									". ",
									next
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3" })]
							}, next))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-[var(--color-text-muted)] italic px-2 py-0.5 bg-[var(--color-page)] rounded border border-[var(--color-rule)]",
							children: "Terminal immutable archive"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-semibold uppercase tracking-wider text-[var(--color-text-muted)] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-[var(--color-action)] shadow-[0_0_6px_rgba(112,82,200,0.4)]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[var(--color-ink)] font-bold",
											children: "Phase 1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Intake & Jurisdictional Triage" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-[var(--color-text-muted)]",
									children: "Linear Registration Flow"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-4",
								children: [
									"Received",
									"Registered",
									"Under Triage"
								].map((status, idx) => {
									const Icon = STATUS_ICONS[status];
									const isSelected = selectedStatus === status;
									const isNext = allowedNext.includes(status);
									const count = caseCountsByStatus[status] ?? 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelectStatus(status),
										className: `relative text-left p-4.5 rounded-[8px] border transition-all cursor-pointer flex flex-col justify-between min-h-[112px] group ${isSelected ? "bg-gradient-to-br from-[#7052C8] to-[#5939A7] text-white border-[#7052C8] shadow-[0_4px_16px_rgba(112,82,200,0.25)] ring-2 ring-[#7052C8]/30" : isNext ? "bg-[#F0F9F4] dark:bg-[#143322]/40 border-[#257D4E]/30 dark:border-[#34D399]/40 shadow-xs hover:bg-[#E6F5EC] dark:hover:bg-[#143322]/70 text-[#257D4E] dark:text-[#34D399]" : "bg-white/60 dark:bg-[#0B0813]/90 border-[#ECE6F4] dark:border-[#201533] hover:border-[#7052C8]/40 dark:hover:border-[#9333EA]/50 hover:bg-white/90 dark:hover:bg-[#120D20] shadow-xs"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2 w-full",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-8 h-8 rounded-[6px] flex items-center justify-center shrink-0 transition-colors ${isSelected ? "bg-white/20 text-white" : isNext ? "bg-[#F0F9F4] text-[#257D4E] border border-[#257D4E]/30" : "bg-[var(--color-page)] dark:bg-[#05040A] text-[var(--color-text-secondary)] dark:text-[#A396BE] border border-[var(--color-rule)] dark:border-[#201533] group-hover:text-[var(--color-action)] dark:group-hover:text-[#C084FC]"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `font-mono text-[10px] font-bold ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
														children: STAGE_NUMBERS[status]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `text-xs font-semibold ${isSelected ? "text-white" : isNext ? "text-[#257D4E]" : "text-[var(--color-text-primary)]"}`,
														children: status
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] block mt-0.5 ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
													children: STATUS_DESCRIPTIONS[status]
												})] })]
											}), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-mono text-[10px] px-2 py-0.5 rounded tabular-nums font-medium ${isSelected ? "bg-white/20 text-white border border-white/20" : "bg-[var(--color-page)] dark:bg-[#05040A] border border-[var(--color-rule)] dark:border-[#201533] text-[var(--color-text-secondary)] dark:text-[#A396BE]"}`,
												title: `${count} active cases`,
												children: count
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-3 border-t border-black/5 mt-2",
											children: isNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[11px] text-[#257D4E] font-semibold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Permitted next stage" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] opacity-75",
													children: "Click to inspect"
												})]
											}) : isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-[11px] text-white font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 text-white/90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inspecting guard rules" })]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[10px] text-[var(--color-text-muted)]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: idx < 2 ? "Advances to step 0" + (idx + 2) : "Ready for bureau dispatch" }), idx < 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3 opacity-50" })]
											})
										})]
									}, status);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-semibold uppercase tracking-wider text-[var(--color-text-muted)] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-[var(--color-action)]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[var(--color-ink)] font-bold",
											children: "Phase 2"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Assignment & Active Investigation" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-[11px] text-[var(--color-action)] font-medium bg-[var(--color-page)] dark:bg-[#0B0813] px-2 py-0.5 rounded border border-[var(--color-rule)] dark:border-[#201533] dark:text-[#C084FC]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat2, { className: "h-3 w-3" }), "Evidence Clarification Loop"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4",
								children: [
									"Assigned",
									"In Progress",
									"Awaiting Information",
									"Under Review"
								].map((status) => {
									const Icon = STATUS_ICONS[status];
									const isSelected = selectedStatus === status;
									const isNext = allowedNext.includes(status);
									const count = caseCountsByStatus[status] ?? 0;
									const isLoop = status === "Awaiting Information";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelectStatus(status),
										className: `relative text-left p-4.5 rounded-[8px] border transition-all cursor-pointer flex flex-col justify-between min-h-[112px] group ${isSelected ? "bg-gradient-to-br from-[#7052C8] to-[#5939A7] text-white border-[#7052C8] shadow-[0_4px_16px_rgba(112,82,200,0.25)] ring-2 ring-[#7052C8]/30" : isNext ? "bg-[#F0F9F4] dark:bg-[#143322]/40 border-[#257D4E]/30 dark:border-[#34D399]/40 shadow-xs hover:bg-[#E6F5EC] dark:hover:bg-[#143322]/70 text-[#257D4E] dark:text-[#34D399]" : "bg-white/60 dark:bg-[#0B0813]/90 border-[#ECE6F4] dark:border-[#201533] hover:border-[#7052C8]/40 dark:hover:border-[#9333EA]/50 hover:bg-white/90 dark:hover:bg-[#120D20] shadow-xs"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2 w-full",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-8 h-8 rounded-[6px] flex items-center justify-center shrink-0 transition-colors ${isSelected ? "bg-white/20 text-white" : isNext ? "bg-[#F0F9F4] text-[#257D4E] border border-[#257D4E]/30" : "bg-[var(--color-page)] dark:bg-[#05040A] text-[var(--color-text-secondary)] dark:text-[#A396BE] border border-[var(--color-rule)] dark:border-[#201533] group-hover:text-[var(--color-action)] dark:group-hover:text-[#C084FC]"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `font-mono text-[10px] font-bold ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
														children: STAGE_NUMBERS[status]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `text-xs font-semibold ${isSelected ? "text-white" : isNext ? "text-[#257D4E]" : "text-[var(--color-text-primary)]"}`,
														children: status
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] block mt-0.5 ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
													children: STATUS_DESCRIPTIONS[status]
												})] })]
											}), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-mono text-[10px] px-2 py-0.5 rounded tabular-nums font-medium ${isSelected ? "bg-white/20 text-white border border-white/20" : "bg-[var(--color-page)] dark:bg-[#05040A] border border-[var(--color-rule)] dark:border-[#201533] text-[var(--color-text-secondary)] dark:text-[#A396BE]"}`,
												title: `${count} active cases`,
												children: count
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-3 border-t border-black/5 mt-2",
											children: isNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[11px] text-[#257D4E] font-semibold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Permitted next stage" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] opacity-75",
													children: "Click"
												})]
											}) : isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-[11px] text-white font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 text-white/90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inspecting guard rules" })]
											}) : isLoop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1 text-[10px] text-[var(--sla-approaching-text)] font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat2, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inquiry pause cycle" })]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-[var(--color-text-muted)]",
												children: status === "Assigned" ? "Desk allocation" : status === "In Progress" ? "Primary investigation" : "Supervisory gate"
											})
										})]
									}, status);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-semibold uppercase tracking-wider text-[var(--color-text-muted)] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-[var(--color-action)]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[var(--color-ink)] font-bold",
											children: "Phase 3"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Administrative Determination & Archive" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-[11px] text-[var(--color-text-muted)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-3 w-3 text-[var(--color-action)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reopening allowed from Resolved to In Progress" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: ["Resolved", "Closed"].map((status) => {
									const Icon = STATUS_ICONS[status];
									const isSelected = selectedStatus === status;
									const isNext = allowedNext.includes(status);
									const count = caseCountsByStatus[status] ?? 0;
									const isTerminal = status === "Closed";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onSelectStatus(status),
										className: `relative text-left p-4.5 rounded-[8px] border transition-all cursor-pointer flex flex-col justify-between min-h-[112px] group ${isSelected ? "bg-gradient-to-br from-[#7052C8] to-[#5939A7] text-white border-[#7052C8] shadow-[0_4px_16px_rgba(112,82,200,0.25)] ring-2 ring-[#7052C8]/30" : isNext ? "bg-[#F0F9F4] dark:bg-[#143322]/40 border-[#257D4E]/30 dark:border-[#34D399]/40 shadow-xs hover:bg-[#E6F5EC] dark:hover:bg-[#143322]/70 text-[#257D4E] dark:text-[#34D399]" : "bg-white/60 dark:bg-[#0B0813]/90 border-[#ECE6F4] dark:border-[#201533] hover:border-[#7052C8]/40 dark:hover:border-[#9333EA]/50 hover:bg-white/90 dark:hover:bg-[#120D20] shadow-xs"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2 w-full",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-8 h-8 rounded-[6px] flex items-center justify-center shrink-0 transition-colors ${isSelected ? "bg-white/20 text-white" : isNext ? "bg-[#F0F9F4] text-[#257D4E] border border-[#257D4E]/30" : isTerminal ? "bg-[var(--color-page)] text-[var(--color-text-muted)] border border-[var(--color-rule)]" : "bg-[var(--color-page)] text-[var(--sla-ontrack-text)] border border-[var(--color-rule)]"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `font-mono text-[10px] font-bold ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
														children: STAGE_NUMBERS[status]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `text-xs font-semibold ${isSelected ? "text-white" : isNext ? "text-[#257D4E]" : "text-[var(--color-text-primary)]"}`,
														children: status
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[11px] block mt-0.5 ${isSelected ? "text-white/80" : "text-[var(--color-text-muted)]"}`,
													children: STATUS_DESCRIPTIONS[status]
												})] })]
											}), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-mono text-[10px] px-2 py-0.5 rounded tabular-nums font-medium ${isSelected ? "bg-white/20 text-white border border-white/20" : "bg-[var(--color-page)] dark:bg-[#05040A] border border-[var(--color-rule)] dark:border-[#201533] text-[var(--color-text-secondary)] dark:text-[#A396BE]"}`,
												title: `${count} cases`,
												children: count
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-3 border-t border-black/5 mt-2",
											children: isNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[11px] text-[#257D4E] font-semibold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Permitted next stage" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] opacity-75",
													children: "Click"
												})]
											}) : isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-[11px] text-white font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 text-white/90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inspecting guard rules" })]
											}) : isTerminal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-[var(--color-text-muted)] flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Permanent terminal ledger (locked)" })]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-[var(--sla-ontrack-text)] flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Resolution order dispatched" })]
											})
										})]
									}, status);
								})
							})]
						})
					]
				})
			]
		})
	});
}
var EXTENDED_STATUS_DESCRIPTIONS = {
	Received: "Initial grievance intake received through portal or bulk CSV ingestion. Complaint text is logged and awaiting formal registration into the AICTE case repository.",
	Registered: "Assigned an official permanent AICTE Case Reference ID (AICTE-2026-XXXXX). Acknowledgment receipt generated for complainant.",
	"Under Triage": "Reviewed by the classification desk. Categorized into jurisdictional bureau (APPR, STU, FDC, FIN), category, and normative SLA priority.",
	Assigned: "Jurisdiction confirmed and assigned to a designated desk officer within the responsible bureau for procedural investigation.",
	"In Progress": "Desk officer is actively reviewing institutional evidence, conducting document verification, and communicating with college authorities.",
	"Awaiting Information": "Formal inquiry or documentary clarification notice issued to complainant or institution. SLA clock paused/tracked pending response.",
	"Under Review": "Investigation findings and draft recommendation submitted to the Competent Supervisory Authority for executive review.",
	Resolved: "Formal administrative resolution order issued. Prescribed remedies, warnings, or compliance directives communicated to the institution.",
	Closed: "Case formally concluded and sealed in the AICTE grievance ledger. Immutable terminal state with permanent audit trail."
};
function StateDetailsPanel({ status, onSelectStatus, caseCount = 0 }) {
	const allowedNext = ALLOWED_TRANSITIONS[status] ?? [];
	const guardRules = TRANSITION_GUARD_RULES[status] ?? [];
	const terminal = isTerminal(status);
	const active = isActive(status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-surface border border-[var(--color-rule)] rounded-[6px] p-6 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between border-b border-[var(--color-rule)] pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-serif text-sm font-semibold text-[var(--color-ink)]",
					children: "Stage inspector"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusMark, { status })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-[var(--color-text-primary)] text-sm",
						children: status
					}), terminal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-[var(--color-text-muted)] border border-[var(--color-rule)] px-1.5 py-0.5 rounded",
						children: "Terminal"
					}) : active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-[var(--color-action)] font-semibold bg-[var(--color-page)] px-2 py-0.5 rounded border border-[var(--color-rule)]",
						children: "Active Stage"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-[var(--sla-ontrack-text)] font-semibold bg-[var(--sla-ontrack-bg)] px-2 py-0.5 rounded",
						children: "Determined"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[var(--color-text-secondary)] leading-relaxed",
					children: EXTENDED_STATUS_DESCRIPTIONS[status]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-2.5 px-3 bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[4px] flex items-center justify-between text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[var(--color-text-muted)]",
					children: "Cases in register:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono font-semibold text-[var(--color-text-primary)] tabular-nums",
						children: caseCount
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "ghost",
						className: "h-6 text-[11px] px-1.5 text-[var(--color-action)] hover:underline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cases",
							search: { status },
							children: "View"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 pt-1 border-t border-[var(--color-rule)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-[var(--color-text-primary)]",
						children: "Permitted transitions"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[10px] text-[var(--color-text-muted)] tabular-nums",
						children: [allowedNext.length, " valid"]
					})]
				}), terminal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 bg-[var(--color-page)] rounded-[4px] border border-[var(--color-rule)] text-xs text-[var(--color-text-secondary)] space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 font-medium text-[var(--color-text-primary)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3.5 w-3.5 text-[var(--color-text-muted)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Immutable terminal stage" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] leading-relaxed text-[var(--color-text-muted)]",
						children: "Cases in Closed status are permanently sealed. No outgoing transitions are permitted."
					})]
				}) : allowedNext.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-[var(--color-text-muted)] italic",
					children: "No outgoing transitions available."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: allowedNext.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelectStatus(target),
						className: "w-full text-left p-2.5 rounded-[4px] border border-[var(--color-rule)] hover:border-[var(--color-action)] bg-surface hover:bg-[var(--color-page)] text-xs flex items-center justify-between transition-none cursor-pointer group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 text-[var(--sla-on-track-text)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-[var(--color-text-primary)]",
								children: target
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-[var(--color-text-muted)] group-hover:text-[var(--color-action)]",
							children: "Inspect →"
						})]
					}, target))
				})]
			}),
			guardRules.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 pt-2 border-t border-[var(--color-rule)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-[var(--color-text-primary)] block",
					children: "Entry guard rules"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-1.5 text-xs text-[var(--color-text-secondary)]",
					children: guardRules.map((rule, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[var(--color-text-muted)]",
							children: "•"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] leading-relaxed",
							children: rule
						})]
					}, idx))
				})]
			})
		]
	});
}
function StateMachineView() {
	const [selectedStatus, setSelectedStatus] = (0, import_react.useState)("In Progress");
	const [fromStatus, setFromStatus] = (0, import_react.useState)("Received");
	const [toStatus, setToStatus] = (0, import_react.useState)("In Progress");
	const [checkedResult, setCheckedResult] = (0, import_react.useState)(null);
	const { data: casesData } = useQuery({
		queryKey: ["cases", {
			page: 1,
			limit: 100
		}],
		queryFn: () => listCases({ page_size: 100 }),
		staleTime: 6e4
	});
	const caseCountsByStatus = (casesData?.items ?? []).reduce((acc, c) => {
		acc[c.status] = (acc[c.status] ?? 0) + 1;
		return acc;
	}, {});
	const handleCheckTransition = (e) => {
		if (e) e.preventDefault();
		const isLegal = canTransition(fromStatus, toStatus);
		const allowed = getAllowedTransitions(fromStatus);
		const rules = TRANSITION_GUARD_RULES[toStatus] || [];
		if (isLegal) setCheckedResult({
			isLegal: true,
			from: fromStatus,
			to: toStatus,
			message: `Permitted transition: '${fromStatus}' to '${toStatus}' complies with AICTE statutory state machine guards.`,
			rules
		});
		else setCheckedResult({
			isLegal: false,
			from: fromStatus,
			to: toStatus,
			message: `Transition blocked: cannot move directly from '${fromStatus}' to '${toStatus}'. Allowed next stages: [${allowed.length > 0 ? allowed.join(", ") : "None (Terminal State)"}].`,
			rules
		});
	};
	const handleTryItAnyway = () => {
		toast.error(`Transition blocked: cannot move directly from ${fromStatus} to ${toStatus}`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "State machine",
				description: "The 9 complaint lifecycle stages and permitted transitions."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-8 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-2 space-y-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateGraph, {
						selectedStatus,
						onSelectStatus: setSelectedStatus,
						caseCountsByStatus
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-1 lg:sticky lg:top-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateDetailsPanel, {
						status: selectedStatus,
						onSelectStatus: setSelectedStatus,
						caseCount: caseCountsByStatus[selectedStatus] ?? 0
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4 max-w-3xl pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-[var(--color-rule)] pb-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)]",
						children: "Test an illegal transition"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-secondary)]",
						children: "Verify lifecycle guard rule validation by testing arbitrary stage transitions."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCheckTransition,
					className: "p-6 bg-surface border border-[var(--color-rule)] rounded-[6px] space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-medium text-[var(--color-text-primary)]",
									children: "From status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: fromStatus,
									onValueChange: (val) => {
										setFromStatus(val);
										setCheckedResult(null);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-8 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ALL_STATUSES.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: st,
										className: "text-xs",
										children: st
									}, st)) })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-medium text-[var(--color-text-primary)]",
									children: "To status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: toStatus,
									onValueChange: (val) => {
										setToStatus(val);
										setCheckedResult(null);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-8 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ALL_STATUSES.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: st,
										className: "text-xs",
										children: st
									}, st)) })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "h-8 px-4 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
								children: "Check transition"
							})
						}),
						checkedResult && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 pt-2",
							children: checkedResult.isLegal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 bg-[var(--sla-ontrack-bg)] dark:bg-[#102B1D]/50 border border-[var(--sla-ontrack-text)]/30 dark:border-[#34D399]/35 rounded-[6px] text-xs text-[var(--sla-ontrack-text)] dark:text-[#34D399] space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Permitted transition" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[var(--color-text-primary)] leading-relaxed",
										children: checkedResult.message
									}),
									checkedResult.rules.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 pt-1.5 border-t border-[var(--sla-ontrack-text)]/20 text-[11px] text-[var(--color-text-secondary)]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-[var(--color-text-primary)] block",
											children: "Condition rules:"
										}), checkedResult.rules.map((rule, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• ", rule] }, idx))]
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 bg-[var(--sla-overdue-bg)] dark:bg-[#2B1015]/50 border border-[var(--sla-overdue-text)]/30 dark:border-[#F87171]/35 rounded-[6px] text-xs text-[var(--sla-overdue-text)] dark:text-[#F87171] space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Transition blocked" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[var(--color-text-primary)] leading-relaxed",
										children: checkedResult.message
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2 border-t border-[var(--sla-overdue-text)]/20 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] text-[var(--color-text-secondary)]",
											children: "Simulate backend HTTP 400 enforcement:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: handleTryItAnyway,
											className: "h-7 text-xs border-[var(--sla-overdue-text)]/40 dark:border-[#F87171]/40 text-[var(--sla-overdue-text)] dark:text-[#F87171] hover:bg-[var(--sla-overdue-bg)] dark:hover:bg-rose-950/30 rounded-[6px]",
											children: "Try it anyway"
										})]
									})
								]
							})
						})
					]
				})]
			})
		]
	});
}
var SplitComponent = StateMachineView;
//#endregion
export { SplitComponent as component };
