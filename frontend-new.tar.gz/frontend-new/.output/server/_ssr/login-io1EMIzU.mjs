import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as Button } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Input } from "./input-BlWpASKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-io1EMIzU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const navigate = useNavigate();
	const { changeRole, role } = useRole();
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const handleSubmit = (e) => {
		e.preventDefault();
		setError(null);
		if (!identifier.trim()) {
			setError("Enter your officer ID or registered email address.");
			return;
		}
		if (!password.trim()) {
			setError("Enter your password.");
			return;
		}
		setIsSubmitting(true);
		setTimeout(() => {
			setIsSubmitting(false);
			navigate({ to: "/dashboard" });
		}, 400);
	};
	const handleQuickRole = (r) => {
		changeRole(r);
		navigate({ to: "/dashboard" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-[calc(100vh-3rem)] flex flex-col items-center justify-center py-12 px-4 bg-gradient-to-br from-[#FCFBFE] via-[#FAF8FD] to-[#F5F2FA] dark:from-[#05040A] dark:via-[#07050E] dark:to-[#0A0714]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-2.5 select-none",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "h-3 w-3 rounded-[3px] bg-[#7052C8] shrink-0 shadow-[0_0_8px_rgba(112,82,200,0.4)]",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-serif text-xl font-semibold text-ink tracking-tight",
					children: "AICTE Case Monitor"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white/85 dark:bg-[#0B0813]/90 backdrop-blur-xl border border-[#ECE6F4] dark:border-[#201533] p-8 rounded-[12px] space-y-5 shadow-[0_8px_32px_rgba(112,82,200,0.06)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold text-ink",
							children: "Sign in to your account"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-text-secondary leading-normal",
							children: "Enter your official credentials to access grievance case records."
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-3 bg-sla-overdue-bg border border-[#ECE6F4] rounded-[6px] text-xs text-sla-overdue",
						role: "alert",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "identifier",
									className: "text-xs font-medium text-ink block",
									children: "Officer ID or email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "identifier",
									type: "text",
									autoComplete: "username",
									value: identifier,
									onChange: (e) => setIdentifier(e.target.value),
									placeholder: "officer@aicte-india.org",
									className: "h-9 text-xs bg-white/70 dark:bg-[#05040A] border-[#ECE6F4] dark:border-[#201533] text-ink dark:text-[#F2EEFA] rounded-[6px] focus:border-[#7052C8] dark:focus:border-[#9333EA] focus:ring-1 focus:ring-[#7052C8]/30 dark:focus:ring-[#9333EA]/30"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "password",
									className: "text-xs font-medium text-ink block",
									children: "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "password",
									type: "password",
									autoComplete: "current-password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									placeholder: "••••••••",
									className: "h-9 text-xs bg-white/70 dark:bg-[#05040A] border-[#ECE6F4] dark:border-[#201533] text-ink dark:text-[#F2EEFA] rounded-[6px] focus:border-[#7052C8] dark:focus:border-[#9333EA] focus:ring-1 focus:ring-[#7052C8]/30 dark:focus:ring-[#9333EA]/30"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting,
								className: "w-full h-9 bg-[#7052C8] hover:bg-[#5E3EA8] text-white text-xs font-medium rounded-[6px] shadow-[0_2px_10px_rgba(112,82,200,0.25)] cursor-pointer transition-all",
								children: isSubmitting ? "Signing in..." : "Sign in"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 border-t border-[#ECE6F4] dark:border-[#201533] space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-text-muted block",
							children: "Quick access demo roles:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-1.5 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleQuickRole("ADMIN"),
									className: "py-1.5 px-2 border border-[#ECE6F4] dark:border-[#201533] rounded-[6px] bg-white/60 dark:bg-[#05040A] hover:bg-white dark:hover:bg-[#120D20] hover:border-[#7052C8]/30 dark:hover:border-[#9333EA]/40 text-ink dark:text-[#F2EEFA] text-left text-[11px] cursor-pointer transition-colors",
									children: "Admin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleQuickRole("SUPERVISOR"),
									className: "py-1.5 px-2 border border-[#ECE6F4] dark:border-[#201533] rounded-[6px] bg-white/60 dark:bg-[#05040A] hover:bg-white dark:hover:bg-[#120D20] hover:border-[#7052C8]/30 dark:hover:border-[#9333EA]/40 text-ink dark:text-[#F2EEFA] text-left text-[11px] cursor-pointer transition-colors",
									children: "Supervisor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleQuickRole("OFFICER"),
									className: "py-1.5 px-2 border border-[#ECE6F4] dark:border-[#201533] rounded-[6px] bg-white/60 dark:bg-[#05040A] hover:bg-white dark:hover:bg-[#120D20] hover:border-[#7052C8]/30 dark:hover:border-[#9333EA]/40 text-ink dark:text-[#F2EEFA] text-left text-[11px] cursor-pointer transition-colors",
									children: "Officer (Approval)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleQuickRole("AUDITOR"),
									className: "py-1.5 px-2 border border-[#ECE6F4] dark:border-[#201533] rounded-[6px] bg-white/60 dark:bg-[#05040A] hover:bg-white dark:hover:bg-[#120D20] hover:border-[#7052C8]/30 dark:hover:border-[#9333EA]/40 text-ink dark:text-[#F2EEFA] text-left text-[11px] cursor-pointer transition-colors",
									children: "Auditor"
								})
							]
						})]
					})
				]
			})]
		})
	});
}
//#endregion
export { LoginPage as component };
