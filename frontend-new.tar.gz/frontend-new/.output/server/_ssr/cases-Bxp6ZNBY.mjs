import { v as lazyRouteComponent, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cases-Bxp6ZNBY.js
var $$splitComponentImporter = () => import("./cases-CJJxHDdp.mjs");
var Route = createFileRoute("/cases/")({
	validateSearch: (search) => {
		return {
			bureau_id: typeof search.bureau_id === "string" ? search.bureau_id : void 0,
			preview: typeof search.preview === "string" ? search.preview : void 0
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
