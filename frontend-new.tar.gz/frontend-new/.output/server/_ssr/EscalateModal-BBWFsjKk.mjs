import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn, i as Button, p as escalateCase } from "./button-1CfnPKN-.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Textarea } from "./textarea-BhA-x7XG.mjs";
import { t as Label } from "./label-DOLtOnoa.mjs";
import { i as useQueryClient, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EscalateModal-BBWFsjKk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function EscalateModal({ caseItem, open, onOpenChange }) {
	const queryClient = useQueryClient();
	const currentTier = caseItem.escalation_level ?? 0;
	const isMaxTier = currentTier >= 2;
	const nextTier = Math.min(currentTier + 1, 2);
	const [reason, setReason] = (0, import_react.useState)("");
	const [validationError, setValidationError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (open) {
			setReason("");
			setValidationError(null);
		}
	}, [open]);
	const mutation = useMutation({
		mutationFn: escalateCase,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["case", caseItem.case_reference_id] });
			queryClient.invalidateQueries({ queryKey: ["cases"] });
			queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
			queryClient.invalidateQueries({ queryKey: ["timeline", caseItem.case_reference_id] });
			queryClient.invalidateQueries({ queryKey: ["slaRadar"] });
			toast.success("Case escalated");
			setReason("");
			onOpenChange(false);
		},
		onError: (err) => {
			setValidationError(err?.message || "Failed to escalate case.");
		}
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		if (isMaxTier) {
			setValidationError("This case is already at maximum escalation level 2.");
			return;
		}
		if (!reason.trim() || reason.trim().length < 3) {
			setValidationError("Remarks must be at least 3 characters.");
			return;
		}
		setValidationError(null);
		mutation.mutate({
			case_ref: caseItem.case_reference_id,
			reason: reason.trim()
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "sm:max-w-md bg-[var(--color-surface)] border border-[var(--color-rule)] rounded-[8px] p-6 shadow-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
						className: "p-0 text-left space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "font-serif text-base font-semibold text-[var(--color-ink)]",
							children: ["Escalate case to level ", nextTier]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-xs text-[var(--color-text-secondary)]",
							children: [
								"Case ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[var(--color-text-primary)]",
									children: caseItem.case_reference_id
								}),
								" is currently at escalation level ",
								currentTier,
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "escalate-reason",
									className: "text-xs font-medium text-[var(--color-text-primary)]",
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-[var(--color-text-muted)]",
									children: "Required for the audit trail"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "escalate-reason",
								placeholder: "State the justification for elevating supervisory surveillance...",
								value: reason,
								onChange: (e) => {
									setReason(e.target.value);
									if (validationError) setValidationError(null);
								},
								rows: 3,
								className: "text-xs bg-surface border-[var(--color-rule)] rounded-[6px]"
							}),
							validationError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-[var(--sla-overdue-text)]",
								children: validationError
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "pt-2 border-t border-[var(--color-rule)] gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => onOpenChange(false),
							className: "h-8 text-xs border-[var(--color-rule)] rounded-[6px]",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							disabled: mutation.isPending || isMaxTier,
							className: "h-8 text-xs font-medium bg-[var(--sla-overdue-text)] text-white hover:bg-[var(--sla-overdue-text)]/90 rounded-[6px]",
							children: mutation.isPending ? "Escalating..." : "Escalate case"
						})]
					})
				]
			})
		})
	});
}
//#endregion
export { DialogHeader as a, DialogFooter as i, DialogContent as n, DialogTitle as o, DialogDescription as r, EscalateModal as s, Dialog as t };
