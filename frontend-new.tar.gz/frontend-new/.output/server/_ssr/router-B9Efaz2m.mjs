import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn, i as Button } from "./button-1CfnPKN-.mjs";
import { n as useRole, t as RoleProvider } from "./RoleContext-C-ODmO0l.mjs";
import { _ as LayoutDashboard, a as Timer, d as PanelLeft, f as PanelLeftClose, g as LoaderCircle, j as ChevronRight, m as Menu, o as Sun, p as Moon, r as Upload, s as Sparkles, t as X, x as FolderOpen, y as GitBranch } from "../_libs/lucide-react.mjs";
import { i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-f_2O8qQw.mjs";
import { C as useRouter, K as redirect, _ as Outlet, b as createRootRouteWithContext, d as Scripts, f as HeadContent, g as useMatchRoute, h as createRouter, p as useLocation, v as lazyRouteComponent, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$8 } from "../_id-VuBbPgMI.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$9 } from "./cases-Bxp6ZNBY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B9Efaz2m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BQvUtNXq.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
var NAV_ITEMS = [
	{
		to: "/dashboard",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		to: "/cases",
		label: "Case register",
		icon: FolderOpen
	},
	{
		to: "/sla-radar",
		label: "SLA radar",
		icon: Timer
	},
	{
		to: "/ai-triage",
		label: "Smart triage",
		icon: Sparkles
	},
	{
		to: "/ingest",
		label: "CSV ingestion",
		icon: Upload,
		permission: "cases:import"
	},
	{
		to: "/state-machine",
		label: "State machine",
		icon: GitBranch
	}
];
function Sidebar({ onClose, collapsed = false, onToggleCollapse }) {
	const matchRoute = useMatchRoute();
	const { user } = useRole();
	const visibleItems = NAV_ITEMS.filter((item) => !item.permission || user?.permissions.includes(item.permission));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("flex flex-col h-full bg-white/85 dark:bg-[#07050E]/95 backdrop-blur-xl border-r border-[#ECE6F4] dark:border-[#201533] text-[var(--color-ink)] transition-[width] duration-200 select-none shadow-[2px_0_24px_rgba(112,82,200,0.03)]", collapsed ? "w-16" : "w-60"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-12 border-b border-[#ECE6F4]/80 dark:border-[#201533]/80 flex items-center px-4 shrink-0 bg-white/40 dark:bg-[#07050E]/60", collapsed ? "justify-center" : "justify-between"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dashboard",
					onClick: onClose,
					className: "flex items-center gap-2.5 overflow-hidden",
					title: "AICTE Case Monitor",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "h-2.5 w-2.5 rounded-[2px] bg-[#7052C8] shrink-0 shadow-[0_0_8px_rgba(112,82,200,0.5)]",
						"aria-hidden": "true"
					}), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold tracking-tight text-[var(--color-ink)] whitespace-nowrap",
						children: "AICTE Case Monitor"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 py-3 px-2 space-y-1 overflow-y-auto overflow-x-hidden",
				children: visibleItems.map((item) => {
					const isActive = !!matchRoute({
						to: item.to,
						fuzzy: item.to === "/cases"
					});
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						onClick: onClose,
						title: collapsed ? item.label : void 0,
						className: cn("relative flex items-center text-xs font-medium rounded-[6px] transition-all duration-150", collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2", isActive ? "text-[#5A38A8] dark:text-[#E9D5FF] bg-[#7052C8]/10 dark:bg-[#9333EA]/20 font-semibold border border-[#7052C8]/15 dark:border-[#9333EA]/35 shadow-[0_2px_8px_rgba(112,82,200,0.06)] dark:shadow-[0_0_12px_rgba(147,51,234,0.18)] shadow-[0_2px_8px_rgba(112,82,200,0.06)] before:absolute before:left-0 before:top-1.5 before:bottom-1.5 before:w-[3px] before:rounded-r before:bg-[#7052C8]" : "text-[var(--color-text-secondary)] dark:text-[#A396BE] hover:text-[var(--color-ink)] dark:hover:text-[#F2EEFA] hover:bg-[#7052C8]/5 dark:hover:bg-[#9333EA]/12 border border-transparent"),
						"aria-current": isActive ? "page" : void 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("h-4 w-4 shrink-0 transition-colors", isActive ? "text-[#7052C8]" : "text-[var(--color-text-muted)]") }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: item.label
						})]
					}, item.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-2 border-t border-[#ECE6F4]/80 dark:border-[#201533]/80 flex items-center justify-between text-xs text-[var(--color-text-muted)] dark:text-[#6E6185] bg-white/40 dark:bg-[#07050E]/60",
				children: [!collapsed && onToggleCollapse && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onToggleCollapse,
					className: "flex items-center gap-2 px-2 py-1.5 text-xs text-[var(--color-text-secondary)] dark:text-[#9B91AF] hover:text-[var(--color-ink)] dark:hover:text-[#EDE8F5] hover:bg-[#7052C8]/6 dark:hover:bg-[#9333EA]/15 rounded-[6px] w-full cursor-pointer transition-colors",
					title: "Collapse sidebar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Collapse" })]
				}), collapsed && onToggleCollapse && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onToggleCollapse,
					className: "flex items-center justify-center p-2 text-[var(--color-text-secondary)] dark:text-[#9B91AF] hover:text-[var(--color-ink)] dark:hover:text-[#EDE8F5] hover:bg-[#7052C8]/6 dark:hover:bg-[#9333EA]/15 rounded-[6px] w-full cursor-pointer transition-colors",
					title: "Expand sidebar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, { className: "h-4 w-4 shrink-0" })
				})]
			})
		]
	});
}
/**
* Role Switcher for the Top Bar.
* Displays "Viewing as", user name, role, bureau, and "Demo mode" label.
*/
var ROLES = [
	{
		value: "ADMIN",
		label: "Admin",
		bureau: "Central Administration"
	},
	{
		value: "SUPERVISOR",
		label: "Supervisor",
		bureau: "Grievance Oversight"
	},
	{
		value: "OFFICER",
		label: "Officer",
		bureau: "Approval Bureau"
	},
	{
		value: "AUDITOR",
		label: "Auditor",
		bureau: "Independent Compliance"
	}
];
function RoleSwitcher() {
	const { role, user, isLoading, changeRole } = useRole();
	const current = ROLES.find((r) => r.value === role) ?? ROLES[1];
	const bureauDisplay = role === "OFFICER" && user?.bureau_name ? user.bureau_name : current.bureau;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] px-2 py-0.5 rounded border border-rule bg-page text-text-muted select-none",
			children: "Demo mode"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-text-secondary hidden sm:inline",
				children: "Viewing as"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: role,
				onValueChange: (v) => changeRole(v),
				disabled: isLoading,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-8 w-auto gap-2 border-rule bg-surface text-xs font-medium px-2.5 shadow-none hover:bg-page transition-none",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-3 w-3 animate-spin text-text-muted" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-ink",
								children: current.label
							}),
							user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-text-secondary hidden md:inline",
								children: ["· ", user.full_name]
							}),
							bureauDisplay && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-text-muted hidden lg:inline",
								children: [
									"(",
									bureauDisplay,
									")"
								]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
					align: "end",
					className: "text-xs bg-surface border-rule shadow-md",
					children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: r.value,
						className: "text-xs py-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-ink",
								children: r.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-text-secondary",
								children: r.bureau
							})]
						})
					}, r.value))
				})]
			})]
		})]
	});
}
var ThemeContext = (0, import_react.createContext)(void 0);
function ThemeProvider({ children }) {
	const [theme, setThemeState] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") try {
			const saved = localStorage.getItem("aicte_theme");
			if (saved && (saved === "light" || saved === "dark" || saved === "system")) return saved;
		} catch {}
		return "light";
	});
	const [resolvedTheme, setResolvedTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const root = document.documentElement;
		const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
		const computeResolved = (t) => {
			if (t === "system") return mediaQuery.matches ? "dark" : "light";
			return t;
		};
		const applyTheme = (r) => {
			setResolvedTheme(r);
			if (r === "dark") root.classList.add("dark");
			else root.classList.remove("dark");
		};
		applyTheme(computeResolved(theme));
		const listener = () => {
			if (theme === "system") applyTheme(computeResolved("system"));
		};
		mediaQuery.addEventListener("change", listener);
		return () => mediaQuery.removeEventListener("change", listener);
	}, [theme]);
	const setTheme = (t) => {
		setThemeState(t);
		try {
			localStorage.setItem("aicte_theme", t);
		} catch {}
	};
	const toggleTheme = () => {
		setTheme(resolvedTheme === "dark" ? "light" : "dark");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, {
		value: {
			theme,
			resolvedTheme,
			setTheme,
			toggleTheme
		},
		children
	});
}
function useTheme() {
	const context = (0, import_react.useContext)(ThemeContext);
	if (!context) throw new Error("useTheme must be used within a ThemeProvider");
	return context;
}
function ThemeToggle({ className }) {
	const { resolvedTheme, toggleTheme } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		size: "sm",
		onClick: toggleTheme,
		className: `h-8 w-8 px-0 rounded-lg border-[#ECE6F4] dark:border-[#201533] bg-white/70 dark:bg-[#0B0813]/80 hover:bg-[#7052C8]/10 dark:hover:bg-[#9333EA]/20 text-[var(--color-ink)] transition-colors ${className ?? ""}`,
		title: resolvedTheme === "dark" ? "Switch to light theme" : "Switch to dark theme",
		"aria-label": "Toggle theme",
		children: resolvedTheme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4 text-[#C084FC] transition-transform rotate-0 scale-100" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4 text-[#54329E] transition-transform rotate-0 scale-100" })
	});
}
/**
* Very soft, spread-out ambient glow that follows the cursor across the viewport.
* Pointer-events are completely disabled so it never interferes with clicks or selections.
*/
function CursorSpotlight() {
	const [coords, setCoords] = (0, import_react.useState)(null);
	const [visible, setVisible] = (0, import_react.useState)(false);
	const { resolvedTheme } = useTheme();
	(0, import_react.useEffect)(() => {
		let animationFrameId;
		const handleMouseMove = (e) => {
			animationFrameId = requestAnimationFrame(() => {
				setCoords({
					x: e.clientX,
					y: e.clientY
				});
				if (!visible) setVisible(true);
			});
		};
		const handleMouseLeave = () => {
			setVisible(false);
		};
		window.addEventListener("mousemove", handleMouseMove, { passive: true });
		document.addEventListener("mouseleave", handleMouseLeave);
		return () => {
			window.removeEventListener("mousemove", handleMouseMove);
			document.removeEventListener("mouseleave", handleMouseLeave);
			if (animationFrameId) cancelAnimationFrame(animationFrameId);
		};
	}, [visible]);
	if (!coords || !visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-hidden": "true",
		className: "pointer-events-none fixed inset-0 z-30 transition-opacity duration-300 select-none",
		style: {
			opacity: visible ? 1 : 0,
			background: resolvedTheme === "dark" ? `radial-gradient(700px circle at ${coords.x}px ${coords.y}px, rgba(147, 51, 234, 0.09), rgba(126, 34, 206, 0.035) 45%, transparent 75%)` : `radial-gradient(600px circle at ${coords.x}px ${coords.y}px, rgba(112, 82, 200, 0.04), rgba(112, 82, 200, 0.012) 40%, transparent 70%)`
		}
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
/**
* App shell — official case register layout.
* Ruled, calm, dense structure.
* Ink sidebar on left, surface top bar with breadcrumbs and role switcher.
*/
function Breadcrumbs() {
	const path = useLocation().pathname;
	const parts = [];
	if (path === "/dashboard" || path === "/") parts.push({ label: "Dashboard" });
	else if (path === "/cases") parts.push({ label: "Case register" });
	else if (path.startsWith("/cases/")) {
		const caseId = path.replace("/cases/", "");
		parts.push({
			label: "Case register",
			to: "/cases"
		});
		parts.push({ label: caseId });
	} else if (path === "/sla-radar") parts.push({ label: "SLA radar" });
	else if (path === "/ai-triage") parts.push({ label: "Smart triage" });
	else if (path === "/ingest") parts.push({ label: "CSV ingestion" });
	else if (path === "/state-machine") parts.push({ label: "State machine" });
	else if (path === "/login") parts.push({ label: "Sign in" });
	else parts.push({ label: "Portal" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex items-center gap-1.5 text-xs text-text-secondary select-none",
		"aria-label": "Breadcrumb",
		children: parts.map((p, idx) => {
			const isLast = idx === parts.length - 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5",
				children: [idx > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "h-3 w-3 text-rule shrink-0",
					"aria-hidden": "true"
				}), p.to && !isLast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: p.to,
					className: "hover:text-ink transition-none",
					children: p.label
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: isLast ? "font-medium text-ink" : "",
					children: p.label
				})]
			}, idx);
		})
	});
}
function AppShell() {
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RoleProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-screen bg-gradient-to-br from-[#FCFBFE] via-[#FAF8FD] to-[#F5F2FA] dark:from-[#05040A] dark:via-[#07050E] dark:to-[#0A0714] text-ink overflow-hidden relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CursorSpotlight, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:flex shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
					collapsed,
					onToggleCollapse: () => setCollapsed((c) => !c)
				})
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				onClick: () => setMobileOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[#1B1233]/25 backdrop-blur-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-y-0 left-0 z-50 w-60",
					onClick: (e) => e.stopPropagation(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, { onClose: () => setMobileOpen(false) })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col flex-1 min-w-0 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between h-12 px-6 lg:px-8 border-b border-[#ECE6F4] dark:border-[#201533] bg-white/75 dark:bg-[#07050E]/90 dark:border-[#201533] backdrop-blur-md shadow-[0_1px_12px_rgba(112,82,200,0.02)] shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "md:hidden h-8 w-8 text-text-secondary hover:text-ink",
							onClick: () => setMobileOpen((o) => !o),
							"aria-label": mobileOpen ? "Close menu" : "Open menu",
							children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breadcrumbs, {})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleSwitcher, {})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 overflow-y-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
		position: "top-right",
		richColors: true
	})] });
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$7 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "AICTE Integrated Complaint Case Monitoring Dashboard" },
			{
				name: "description",
				content: "Role-based monitoring and lifecycle tracking for AICTE bureaus"
			},
			{
				name: "author",
				content: "AICTE Smart India Hackathon"
			},
			{
				property: "og:title",
				content: "AICTE Integrated Complaint Case Monitoring Dashboard"
			},
			{
				property: "og:description",
				content: "Role-based monitoring and lifecycle tracking for AICTE bureaus"
			},
			{
				property: "og:type",
				content: "website"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$7.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) })
	});
}
var Route$6 = createFileRoute("/")({ beforeLoad: () => {
	throw redirect({ to: "/dashboard" });
} });
var $$splitComponentImporter$5 = () => import("./ai-triage-4bUEPAbn.mjs");
var Route$5 = createFileRoute("/ai-triage")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./dashboard-CECVhyvY.mjs");
var Route$4 = createFileRoute("/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./ingest-CWK3oJih.mjs");
var Route$3 = createFileRoute("/ingest")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./login-io1EMIzU.mjs");
var Route$2 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./sla-radar-DtoStxrU.mjs");
var Route$1 = createFileRoute("/sla-radar")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./state-machine-Z5zzSheC.mjs");
var Route = createFileRoute("/state-machine")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var AiTriageRoute = Route$5.update({
	id: "/ai-triage",
	path: "/ai-triage",
	getParentRoute: () => Route$7
});
var DashboardRoute = Route$4.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$7
});
var IngestRoute = Route$3.update({
	id: "/ingest",
	path: "/ingest",
	getParentRoute: () => Route$7
});
var LoginRoute = Route$2.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$7
});
var SlaRadarRoute = Route$1.update({
	id: "/sla-radar",
	path: "/sla-radar",
	getParentRoute: () => Route$7
});
var StateMachineRoute = Route.update({
	id: "/state-machine",
	path: "/state-machine",
	getParentRoute: () => Route$7
});
var CasesIndexRoute = Route$9.update({
	id: "/cases/",
	path: "/cases/",
	getParentRoute: () => Route$7
});
var rootRouteChildren = {
	IndexRoute,
	AiTriageRoute,
	DashboardRoute,
	IngestRoute,
	LoginRoute,
	SlaRadarRoute,
	StateMachineRoute,
	CasesIdRoute: Route$8.update({
		id: "/cases/$id",
		path: "/cases/$id",
		getParentRoute: () => Route$7
	}),
	CasesIndexRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
