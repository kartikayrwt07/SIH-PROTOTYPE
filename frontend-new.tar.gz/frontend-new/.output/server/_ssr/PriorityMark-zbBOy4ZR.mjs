import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn } from "./button-1CfnPKN-.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var BARS_COUNT = {
	LOW: 1,
	MEDIUM: 2,
	HIGH: 3,
	URGENT: 4
};
function PriorityMark({ priority, className, showBars = true }) {
	const bars = BARS_COUNT[priority] ?? 2;
	const isUrgent = priority === "URGENT";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap", isUrgent ? "text-sla-overdue" : "text-text-secondary", className),
		children: [showBars && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex items-end gap-0.5 h-3 w-2.5",
			"aria-hidden": "true",
			children: [
				1,
				2,
				3,
				4
			].map((i) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("w-[2px] rounded-[0.5px] transition-colors", i <= bars ? isUrgent ? "bg-sla-overdue" : "bg-ink" : "bg-rule"),
					style: { height: `${i * 25}%` }
				}, i);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: priority })]
	});
}
//#endregion
export { PriorityMark as t };
