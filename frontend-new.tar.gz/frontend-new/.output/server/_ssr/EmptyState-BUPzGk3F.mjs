import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn, i as Button } from "./button-1CfnPKN-.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function EmptyState({ message, instruction, actionText, onAction, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("py-12 px-6 text-center max-w-md mx-auto space-y-2", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium text-ink text-sm",
				children: message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-text-secondary leading-normal",
				children: instruction
			}),
			actionText && onAction && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: onAction,
					className: "text-xs h-8 border-rule text-ink hover:bg-page",
					children: actionText
				})
			})
		]
	});
}
//#endregion
export { EmptyState as t };
