import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime, u as Slot } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-1CfnPKN-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MOCK_BUREAUS = [
	{
		id: "bureau-appr",
		code: "APPR",
		name: "Approval Bureau",
		description: "Monitors institutional compliance with AICTE approval norms, land, building, and faculty ratios.",
		is_active: true
	},
	{
		id: "bureau-stu",
		code: "STU",
		name: "Student Welfare Cell",
		description: "Addresses grievances regarding ragging, student safety, mental health, and hostel amenities.",
		is_active: true
	},
	{
		id: "bureau-fdc",
		code: "FDC",
		name: "Faculty Grievance Cell",
		description: "Reviews faculty complaints regarding salary arrears, 7th CPC non-implementation, and termination.",
		is_active: true
	},
	{
		id: "bureau-fin",
		code: "FIN",
		name: "Finance & Fee Regulatory Bureau",
		description: "Oversees capitation fee complaints, excess tuition demands, and security deposit withholding.",
		is_active: true
	}
];
var MOCK_OFFICERS = [
	{
		id: "officer-appr-1",
		email: "officer.appr@aicte-demo.gov.in",
		full_name: "Shri Arvind Verma",
		role: "OFFICER"
	},
	{
		id: "officer-stu-1",
		email: "officer.stu@aicte-demo.gov.in",
		full_name: "Dr. Priya Nair",
		role: "OFFICER"
	},
	{
		id: "officer-fdc-1",
		email: "officer.fdc@aicte-demo.gov.in",
		full_name: "Prof. Manoj Joshi",
		role: "OFFICER"
	},
	{
		id: "officer-fin-1",
		email: "officer.fin@aicte-demo.gov.in",
		full_name: "Shri Deepesh Goyal",
		role: "OFFICER"
	}
];
var BUREAU_OFFICERS = {
	"bureau-appr": [MOCK_OFFICERS[0]],
	"bureau-stu": [MOCK_OFFICERS[1]],
	"bureau-fdc": [MOCK_OFFICERS[2]],
	"bureau-fin": [MOCK_OFFICERS[3]]
};
var INSTITUTIONS = [
	{
		id: "inst-01",
		aicte_id: "1-3324561",
		name: "Rajasthan Technical University",
		state: "Rajasthan",
		district: "Kota"
	},
	{
		id: "inst-02",
		aicte_id: "1-4521890",
		name: "Symbiosis Institute of Technology",
		state: "Maharashtra",
		district: "Pune"
	},
	{
		id: "inst-03",
		aicte_id: "1-2893421",
		name: "Amity University Noida",
		state: "Uttar Pradesh",
		district: "Noida"
	},
	{
		id: "inst-04",
		aicte_id: "2-7654321",
		name: "Chandigarh University",
		state: "Punjab",
		district: "Mohali"
	},
	{
		id: "inst-05",
		aicte_id: "1-5643210",
		name: "VIT University Chennai",
		state: "Tamil Nadu",
		district: "Chennai"
	},
	{
		id: "inst-06",
		aicte_id: "1-8765432",
		name: "NMIMS Mumbai School of Engineering",
		state: "Maharashtra",
		district: "Mumbai"
	},
	{
		id: "inst-07",
		aicte_id: "2-3456789",
		name: "Manipal Institute of Technology",
		state: "Karnataka",
		district: "Udupi"
	},
	{
		id: "inst-08",
		aicte_id: "1-6789012",
		name: "Lovely Professional University",
		state: "Punjab",
		district: "Phagwara"
	},
	{
		id: "inst-09",
		aicte_id: "1-9876543",
		name: "SRM Institute of Science and Technology",
		state: "Tamil Nadu",
		district: "Kancheepuram"
	},
	{
		id: "inst-10",
		aicte_id: "2-1234567",
		name: "Dayananda Sagar University",
		state: "Karnataka",
		district: "Bengaluru"
	},
	{
		id: "inst-11",
		aicte_id: "1-7654321",
		name: "PSG College of Technology",
		state: "Tamil Nadu",
		district: "Coimbatore"
	},
	{
		id: "inst-12",
		aicte_id: "1-4567890",
		name: "Kalinga Institute of Industrial Technology",
		state: "Odisha",
		district: "Bhubaneswar"
	},
	{
		id: "inst-13",
		aicte_id: "2-8901234",
		name: "BMS College of Engineering",
		state: "Karnataka",
		district: "Bengaluru"
	},
	{
		id: "inst-14",
		aicte_id: "2-2345678",
		name: "RNS Institute of Technology",
		state: "Karnataka",
		district: "Bengaluru"
	},
	{
		id: "inst-15",
		aicte_id: "1-5678901",
		name: "KLE Technological University",
		state: "Karnataka",
		district: "Hubballi"
	}
];
var TEMPLATES = {
	APPR: [
		{
			subject: "Faculty shortage below AICTE prescribed ratio",
			category: "Faculty Compliance",
			priority: "HIGH",
			description: "Institution has 43 faculty against required 62 for enrolled strength of 1240 students. Faculty-student ratio of 1:29 violates AICTE norms."
		},
		{
			subject: "Land ownership documents not submitted for approval renewal",
			category: "Approval Documentation",
			priority: "MEDIUM",
			description: "Renewal application submitted without land mutation certificate. Required for approval of Phase 3 expansion of campus."
		},
		{
			subject: "NBA accreditation lapse — courses running without valid accreditation",
			category: "NBA Accreditation",
			priority: "URGENT",
			description: "B.Tech CSE and ECE programmes running post-accreditation expiry date without renewal application filed."
		},
		{
			subject: "Excess intake against sanctioned strength in B.Tech programme",
			category: "Intake Violation",
			priority: "HIGH",
			description: "Institution admitted 180 students against sanctioned intake of 120 in B.Tech Mechanical Engineering 2025-26."
		},
		{
			subject: "Building plan deviation from approved layout",
			category: "Infrastructure Compliance",
			priority: "MEDIUM",
			description: "New academic block constructed without approved building plan. Deviation of 2400 sq ft from approved FAR."
		},
		{
			subject: "Non-submission of annual compliance report",
			category: "Approval Documentation",
			priority: "LOW",
			description: "Annual compliance report for 2024-25 not submitted within stipulated date of 30 September 2025."
		},
		{
			subject: "Inadequate laboratory infrastructure for engineering programmes",
			category: "Infrastructure Compliance",
			priority: "MEDIUM",
			description: "Laboratory space per student below 2.5 sq m norm for Chemical Engineering department. Inspection report attached."
		}
	],
	STU: [
		{
			subject: "Ragging complaint by first-year B.Tech students",
			category: "Ragging",
			priority: "URGENT",
			description: "Three first-year students report ragging by seniors in hostel Block C. Incident occurred on 12 October 2026. Formal complaint filed with anti-ragging committee."
		},
		{
			subject: "Hostel food quality and hygiene standards not maintained",
			category: "Hostel Facilities",
			priority: "HIGH",
			description: "Students report repeated supply of stale food in mess. Water supply disrupted for 3 consecutive days. Photographic evidence submitted."
		},
		{
			subject: "Mental health counsellor post vacant for 8 months",
			category: "Mental Health",
			priority: "HIGH",
			description: "AICTE mandated counsellor post vacant since February 2026. Students unable to access mental health support services on campus."
		},
		{
			subject: "Scholarship disbursement delayed by 6 months",
			category: "Scholarship",
			priority: "MEDIUM",
			description: "Post-Matric scholarship amounts for 2025-26 not disbursed to 240 eligible students despite successful verification by state nodal officer."
		},
		{
			subject: "Student safety concerns — boundary wall collapsed",
			category: "Student Safety",
			priority: "URGENT",
			description: "Boundary wall of girls hostel partially collapsed after heavy rainfall. Structural safety report not shared with students or guardians."
		}
	],
	FDC: [
		{
			subject: "Salary arrears pending for 14 months",
			category: "Salary Grievance",
			priority: "URGENT",
			description: "Faculty member reports salary dues of Rs 4.2 lakh pending since August 2025. PF deductions made but not deposited with EPFO."
		},
		{
			subject: "7th CPC pay revision not implemented",
			category: "Pay Revision",
			priority: "HIGH",
			description: "Institution refuses to implement 7th Central Pay Commission recommendations for teaching staff. Arrears since January 2016 not paid."
		},
		{
			subject: "Arbitrary termination without due process",
			category: "Service Matter",
			priority: "HIGH",
			description: "Associate Professor terminated via letter on 1 October 2026 without show-cause notice, departmental inquiry, or compensation as per UGC regulations."
		},
		{
			subject: "PF contributions deducted but not deposited",
			category: "PF Compliance",
			priority: "URGENT",
			description: "Employee Provident Fund deducted from salaries of 45 faculty for 18 months but not remitted to EPFO. EPFO passbook shows zero balance."
		},
		{
			subject: "Medical leave denied despite doctor certificate",
			category: "Leave Entitlement",
			priority: "MEDIUM",
			description: "Faculty member denied 10 days medical leave despite submission of registered medical practitioner certificate and AICTE entitlement of 8 days."
		}
	],
	FIN: [
		{
			subject: "Capitation fee collected at time of admission",
			category: "Capitation Fee",
			priority: "URGENT",
			description: "Institution collected Rs 1.5 lakh as 'development fee' at admission in addition to approved tuition fee. Receipts not issued for collection."
		},
		{
			subject: "Excess tuition fee charged beyond approved fee structure",
			category: "Fee Overcharge",
			priority: "HIGH",
			description: "Approved annual fee: Rs 85,000. Collected: Rs 1,12,000. Difference of Rs 27,000 per student charged as 'miscellaneous head' without approval."
		},
		{
			subject: "Security deposit withheld after course completion",
			category: "Refund Non-compliance",
			priority: "HIGH",
			description: "Security deposit of Rs 25,000 not refunded to 89 graduated students despite repeated requests and 6 months post-graduation."
		},
		{
			subject: "Online fee payment portal charging additional processing fee",
			category: "Fee Regulation",
			priority: "MEDIUM",
			description: "Institution's online payment portal charges 2.5% processing fee not mentioned in fee structure approved by state fee committee."
		},
		{
			subject: "Duplicate admission receipt fraud",
			category: "Fee Fraud",
			priority: "URGENT",
			description: "Students report being given handwritten receipts instead of official system-generated ones. Cash collected not entered into accounts."
		}
	]
};
var NOW = /* @__PURE__ */ new Date("2026-10-24T10:00:00Z");
function iso(d) {
	return d.toISOString();
}
function hoursAgo(h) {
	return /* @__PURE__ */ new Date(NOW.getTime() - h * 3600 * 1e3);
}
function hoursFromNow(h) {
	return new Date(NOW.getTime() + h * 3600 * 1e3);
}
function daysAgo(d) {
	return hoursAgo(d * 24);
}
function buildSpecs() {
	const specs = [];
	const bureaus = [
		{
			id: "bureau-appr",
			code: "APPR",
			count: 22,
			templates: 7
		},
		{
			id: "bureau-stu",
			code: "STU",
			count: 14,
			templates: 5
		},
		{
			id: "bureau-fdc",
			code: "FDC",
			count: 11,
			templates: 5
		},
		{
			id: "bureau-fin",
			code: "FIN",
			count: 11,
			templates: 5
		}
	];
	const slaBuckets = [
		...Array(8).fill("overdue"),
		...Array(9).fill("approaching"),
		...Array(27).fill("on_track"),
		...Array(10).fill("resolved"),
		...Array(4).fill("closed")
	];
	const STATUS_FOR_SLA = {
		overdue: [
			"In Progress",
			"Awaiting Information",
			"Under Review",
			"Assigned"
		],
		approaching: [
			"In Progress",
			"Assigned",
			"Under Triage",
			"Awaiting Information"
		],
		on_track: [
			"Received",
			"Registered",
			"Under Triage",
			"Assigned",
			"In Progress",
			"Under Review"
		],
		resolved: ["Resolved"],
		closed: ["Closed"]
	};
	let caseIndex = 0;
	for (const bureau of bureaus) for (let i = 0; i < bureau.count; i++) {
		const sla = slaBuckets[caseIndex % slaBuckets.length];
		const statusOptions = STATUS_FOR_SLA[sla];
		const status = statusOptions[i % statusOptions.length];
		specs.push({
			bureauId: bureau.id,
			bureauCode: bureau.code,
			instIdx: (caseIndex * 3 + 7) % 15,
			templateIdx: i % TEMPLATES[bureau.code].length,
			status,
			sla
		});
		caseIndex++;
	}
	return specs;
}
var OFFICER_FOR_BUREAU = {
	"bureau-appr": {
		id: "officer-appr-1",
		name: "Shri Arvind Verma"
	},
	"bureau-stu": {
		id: "officer-stu-1",
		name: "Dr. Priya Nair"
	},
	"bureau-fdc": {
		id: "officer-fdc-1",
		name: "Prof. Manoj Joshi"
	},
	"bureau-fin": {
		id: "officer-fin-1",
		name: "Shri Deepesh Goyal"
	}
};
var UNASSIGNED_STATUSES = ["Received", "Registered"];
function generateMockCases() {
	const specs = buildSpecs();
	const cases = [];
	for (let i = 0; i < specs.length; i++) {
		const spec = specs[i];
		const inst = INSTITUTIONS[spec.instIdx];
		const tmpl = TEMPLATES[spec.bureauCode][spec.templateIdx];
		const officer = OFFICER_FOR_BUREAU[spec.bureauId];
		const ref = `AICTE-2026-${String(i + 1).padStart(5, "0")}`;
		const caseId = `case-${String(i + 1).padStart(4, "0")}`;
		const isAssigned = !UNASSIGNED_STATUSES.includes(spec.status);
		const isResolved = spec.status === "Resolved" || spec.status === "Closed";
		let createdAt;
		let dueDate;
		let escalationLevel;
		let resolvedAt = null;
		let closedAt = null;
		switch (spec.sla) {
			case "overdue":
				createdAt = daysAgo(12);
				dueDate = hoursAgo(24 + i % 72);
				escalationLevel = 2;
				break;
			case "approaching":
				createdAt = daysAgo(4);
				dueDate = hoursFromNow(4 + i % 44);
				escalationLevel = 1;
				break;
			case "on_track":
				createdAt = daysAgo(2 + i % 8);
				dueDate = hoursFromNow(72 + i % 120);
				escalationLevel = 0;
				break;
			case "resolved":
				createdAt = daysAgo(15 + i % 10);
				dueDate = hoursFromNow(48);
				escalationLevel = 0;
				resolvedAt = daysAgo(2);
				break;
			default:
				createdAt = daysAgo(20 + i % 15);
				dueDate = hoursFromNow(48);
				escalationLevel = 0;
				resolvedAt = daysAgo(5);
				closedAt = daysAgo(4);
		}
		cases.push({
			id: caseId,
			case_reference_id: ref,
			institution_id: inst.id,
			institution_name: inst.name,
			aicte_permanent_id: inst.aicte_id,
			bureau_id: spec.bureauId,
			bureau_code: spec.bureauCode,
			bureau_name: MOCK_BUREAUS.find((b) => b.id === spec.bureauId).name,
			assigned_officer_id: isAssigned ? officer.id : void 0,
			assigned_officer_name: isAssigned ? officer.name : void 0,
			subject: tmpl.subject,
			description_redacted: tmpl.description,
			description_confidential: `[CONFIDENTIAL]: Complainant identity protected. Statement filed against administration of ${inst.name}.`,
			category: tmpl.category,
			priority: tmpl.priority,
			status: spec.status,
			due_date: iso(dueDate),
			escalation_level: escalationLevel,
			created_at: iso(createdAt),
			updated_at: iso(new Date(createdAt.getTime() + 72e5)),
			resolved_at: resolvedAt ? iso(resolvedAt) : null,
			closed_at: closedAt ? iso(closedAt) : null,
			closure_remarks: isResolved ? "Grievance resolved following institutional compliance and confirmation of corrective action." : null
		});
	}
	return cases;
}
var _store = {
	cases: [...generateMockCases()],
	timeline: {},
	notes: {},
	history: {}
};
/** Seed initial timeline and notes for the first 5 cases to demo those screens. */
function seedExtras() {
	const seedCases = _store.cases.slice(0, 5);
	for (const c of seedCases) {
		const now = new Date(c.created_at).getTime();
		_store.timeline[c.case_reference_id] = [{
			id: `tl-${c.case_reference_id}-1`,
			case_id: c.id,
			actor_id: "user-admin",
			actor_role: "ADMIN",
			actor_name: "Smt. Sunita Sharma",
			event_type: "REGISTERED",
			previous_state: null,
			new_state: "Received",
			remark: "Case registered via web portal.",
			metadata: {
				channel: "Web Portal",
				batch_id: "INIT-2026"
			},
			timestamp: new Date(now).toISOString()
		}, {
			id: `tl-${c.case_reference_id}-2`,
			case_id: c.id,
			actor_id: "user-supervisor",
			actor_role: "SUPERVISOR",
			actor_name: "Dr. Ramesh Chandra",
			event_type: "STATUS_CHANGE",
			previous_state: "Received",
			new_state: c.status,
			remark: `Transitioned to ${c.status} during grievance review.`,
			metadata: {
				remarks: `Transitioned to ${c.status} during grievance review.`,
				action: "execute_transition"
			},
			timestamp: new Date(now + 216e5).toISOString()
		}];
		if (c.status === "In Progress" || c.status === "Under Review") {
			_store.notes[c.case_reference_id] = [{
				id: `note-${c.case_reference_id}-1`,
				case_id: c.id,
				author_id: c.assigned_officer_id ?? "user-admin",
				author_name: c.assigned_officer_name ?? "System Admin",
				author_role: "OFFICER",
				content: `Formal inquiry notice dispatched to Registrar of ${c.institution_name}. Response pending within 7 working days.`,
				is_confidential: false,
				created_at: new Date(now + 432e5).toISOString()
			}, {
				id: `note-${c.case_reference_id}-2`,
				case_id: c.id,
				author_id: c.assigned_officer_id ?? "user-admin",
				author_name: c.assigned_officer_name ?? "System Admin",
				author_role: "OFFICER",
				content: `Confidential: Complainant has requested anonymity. Internal tracking only.`,
				is_confidential: true,
				created_at: new Date(now + 648e5).toISOString()
			}];
			_store.history[c.case_reference_id] = [{
				id: `hist-${c.case_reference_id}-1`,
				case_id: c.id,
				from_bureau_id: null,
				from_bureau_name: null,
				to_bureau_id: c.bureau_id,
				to_bureau_name: c.bureau_name,
				assigned_by_id: "user-supervisor",
				assigned_by_name: "Dr. Ramesh Chandra",
				transfer_reason: `Jurisdiction assigned to ${c.bureau_name} based on complaint category ${c.category}.`,
				created_at: new Date(now + 144e5).toISOString()
			}];
		}
	}
}
seedExtras();
function getCases() {
	return _store.cases;
}
function getCaseByRef(ref) {
	return _store.cases.find((c) => c.case_reference_id === ref || c.id === ref);
}
function updateCase(ref, patch) {
	const idx = _store.cases.findIndex((c) => c.case_reference_id === ref || c.id === ref);
	if (idx === -1) throw new Error(`Case ${ref} not found`);
	_store.cases[idx] = {
		..._store.cases[idx],
		...patch
	};
	return _store.cases[idx];
}
function resolveRef(ref) {
	const c = _store.cases.find((c) => c.case_reference_id === ref || c.id === ref);
	return c ? c.case_reference_id : ref;
}
function getTimeline$1(caseRef) {
	return _store.timeline[resolveRef(caseRef)] ?? [];
}
function addTimelineEvent(caseRef, event) {
	const ref = resolveRef(caseRef);
	if (!_store.timeline[ref]) _store.timeline[ref] = [];
	_store.timeline[ref].push(event);
}
function getNotes$1(caseRef) {
	return _store.notes[resolveRef(caseRef)] ?? [];
}
function addNote$1(caseRef, note) {
	const ref = resolveRef(caseRef);
	if (!_store.notes[ref]) _store.notes[ref] = [];
	_store.notes[ref].push(note);
}
function getHistory(caseRef) {
	return _store.history[resolveRef(caseRef)] ?? [];
}
function addHistory(caseRef, entry) {
	const ref = resolveRef(caseRef);
	if (!_store.history[ref]) _store.history[ref] = [];
	_store.history[ref].push(entry);
}
function appendCase(c) {
	_store.cases.push(c);
}
var ALLOWED_TRANSITIONS = {
	Received: ["Registered"],
	Registered: ["Under Triage"],
	"Under Triage": ["Assigned"],
	Assigned: ["In Progress"],
	"In Progress": ["Awaiting Information", "Under Review"],
	"Awaiting Information": ["In Progress"],
	"Under Review": ["In Progress", "Resolved"],
	Resolved: ["Closed", "In Progress"],
	Closed: []
};
/** All 9 lifecycle states in display order. */
var ALL_STATUSES = [
	"Received",
	"Registered",
	"Under Triage",
	"Assigned",
	"In Progress",
	"Awaiting Information",
	"Under Review",
	"Resolved",
	"Closed"
];
/** Returns valid next states for a given current state. */
function getAllowedTransitions(from) {
	return ALLOWED_TRANSITIONS[from] ?? [];
}
/** Returns true if the transition from → to is legal. */
function canTransition(from, to) {
	return getAllowedTransitions(from).includes(to);
}
/** Returns true if status is terminal (no further transitions possible). */
function isTerminal(status) {
	return ALLOWED_TRANSITIONS[status].length === 0;
}
/** Returns true if the case is considered "active" (not Resolved or Closed). */
function isActive(status) {
	return status !== "Resolved" && status !== "Closed";
}
/** Guard rules displayed in the State Machine screen and dossier modal. */
var TRANSITION_GUARD_RULES = {
	Received: ["Mandatory remarks required"],
	Registered: ["Mandatory remarks required"],
	"Under Triage": ["Bureau must be confirmed before assigning", "Mandatory remarks required"],
	Assigned: ["Officer must be assigned", "Mandatory remarks required"],
	"In Progress": ["Mandatory remarks required"],
	"Awaiting Information": ["Mandatory remarks required"],
	"Under Review": ["Mandatory remarks required"],
	Resolved: ["Closure remarks become the permanent record", "Mandatory remarks required"],
	Closed: ["Terminal state — no further transitions allowed"]
};
/** Human-readable labels for audit event types. */
var AUDIT_EVENT_LABELS = {
	REGISTERED: "Case Registered",
	STATUS_CHANGE: "Status Changed",
	REASSIGNED: "Case Reassigned",
	NOTE_ADDED: "Note Added",
	ESCALATED: "Case Escalated",
	RESOLVED: "Case Resolved",
	CLOSED: "Case Closed",
	REOPENED: "Case Reopened",
	TRIAGE_APPLIED: "Triage Classification Applied"
};
var KEYWORD_RULES = [
	{
		keywords: [
			"approval",
			"compliance",
			"land",
			"building",
			"faculty ratio",
			"faculty-student ratio",
			"nba",
			"noc",
			"affiliation",
			"infrastructure",
			"laboratory",
			"intake capacity",
			"unapproved course"
		],
		bureau: "APPR",
		category: "Approval Compliance",
		priority: "HIGH",
		weight: .9
	},
	{
		keywords: [
			"ragging",
			"hostel",
			"student",
			"mental health",
			"safety",
			"scholarship",
			"fee refund",
			"mess",
			"harassment",
			"student welfare",
			"counseling",
			"amenities"
		],
		bureau: "STU",
		category: "Student Grievance",
		priority: "URGENT",
		weight: .95
	},
	{
		keywords: [
			"salary",
			"faculty",
			"teacher",
			"arrear",
			"7th cpc",
			"termination",
			"pf",
			"provident fund",
			"leave",
			"pay commission",
			"unpaid wages",
			"gratuity"
		],
		bureau: "FDC",
		category: "Faculty Grievance",
		priority: "HIGH",
		weight: .88
	},
	{
		keywords: [
			"capitation",
			"tuition",
			"fee",
			"deposit",
			"refund",
			"excess charge",
			"finance",
			"overcharging",
			"caution deposit",
			"withholding certificate",
			"mandatory donation"
		],
		bureau: "FIN",
		category: "Fee Regulation",
		priority: "MEDIUM",
		weight: .85
	}
];
var BUREAU_NAMES = {
	APPR: "Approval Bureau",
	STU: "Student Welfare Cell",
	FDC: "Faculty Grievance Cell",
	FIN: "Finance & Fee Regulatory Bureau"
};
/**
* Rule-based explainable triage: matches grievance text against keyword rules
* and returns recommended bureau, category, priority, confidence score,
* and an explainable list of matched keyword weights that sum to 100%.
*/
function runTriageRule(text) {
	const lower = text.toLowerCase();
	let bestRule = null;
	let bestScore = 0;
	const rawMatches = [];
	for (const rule of KEYWORD_RULES) {
		const hits = rule.keywords.filter((kw) => lower.includes(kw));
		if (hits.length === 0) continue;
		const score = hits.length / Math.min(rule.keywords.length, 5) * rule.weight;
		hits.forEach((kw) => {
			rawMatches.push({
				keyword: kw,
				weight: rule.weight,
				resulting_route: `${rule.bureau} · ${BUREAU_NAMES[rule.bureau]}`
			});
		});
		if (score > bestScore) {
			bestScore = score;
			bestRule = rule;
		}
	}
	if (!bestRule || rawMatches.length === 0) return {
		recommended_bureau_code: "APPR",
		recommended_bureau_name: "Approval Bureau",
		recommended_category: "General Complaint",
		recommended_priority: "MEDIUM",
		confidence: .25,
		matched_keywords: [],
		rationale: "No statutory keywords matched. Routed to Approval Bureau for manual assessment."
	};
	const totalRawWeight = rawMatches.reduce((sum, item) => sum + item.weight, 0);
	const normalisedKeywords = rawMatches.map((item) => ({
		keyword: item.keyword,
		weight: parseFloat((item.weight / (totalRawWeight || 1)).toFixed(2)),
		resulting_route: item.resulting_route
	}));
	if (normalisedKeywords.length > 0) {
		const currentSum = normalisedKeywords.reduce((sum, item) => sum + item.weight, 0);
		const diff = parseFloat((1 - currentSum).toFixed(2));
		if (diff !== 0) normalisedKeywords[0].weight = parseFloat((normalisedKeywords[0].weight + diff).toFixed(2));
	}
	const confidence = parseFloat(Math.min(.6 + bestScore * .4, .98).toFixed(2));
	return {
		recommended_bureau_code: bestRule.bureau,
		recommended_bureau_name: BUREAU_NAMES[bestRule.bureau],
		recommended_category: bestRule.category,
		recommended_priority: bestRule.priority,
		confidence,
		matched_keywords: normalisedKeywords,
		rationale: `Matched ${rawMatches.length} statutory keyword(s) with highest correlation to ${BUREAU_NAMES[bestRule.bureau]}.`
	};
}
/** Tokenise text into lowercase alphanumeric words, filtering standard English stop words. */
function tokenise(text) {
	const STOP = /* @__PURE__ */ new Set([
		"the",
		"a",
		"an",
		"is",
		"in",
		"of",
		"and",
		"or",
		"to",
		"for",
		"with",
		"at",
		"by",
		"from",
		"on",
		"it",
		"this",
		"that",
		"be",
		"as",
		"are",
		"has",
		"have",
		"had"
	]);
	return text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w));
}
/** Jaccard similarity between two token sets. */
function jaccard(a, b) {
	const setA = new Set(a);
	const setB = new Set(b);
	const intersection = [...setA].filter((t) => setB.has(t));
	const union = /* @__PURE__ */ new Set([...setA, ...setB]);
	return union.size === 0 ? 0 : intersection.length / union.size;
}
/**
* Check for duplicate or highly similar cases against the repository.
* Employs tokenised Jaccard overlap + institution affinity boost.
*/
function checkDuplicatesRule(query, cases, threshold = .2) {
	const queryTokens = tokenise(`${query.subject} ${query.description}`);
	if (queryTokens.length === 0) return [];
	const matches = [];
	for (const c of cases) {
		const caseTokens = tokenise(`${c.subject} ${c.description_redacted}`);
		let score = jaccard(queryTokens, caseTokens);
		if (query.institution_name && c.institution_name && (c.institution_name.toLowerCase().includes(query.institution_name.toLowerCase()) || query.institution_name.toLowerCase().includes(c.institution_name.toLowerCase()))) score = Math.min(score + .15, .96);
		if (score < threshold) continue;
		const intersection = caseTokens.filter((t) => new Set(queryTokens).has(t));
		const uniqueKeywords = [...new Set(intersection)].slice(0, 5);
		matches.push({
			case_reference_id: c.case_reference_id,
			subject: c.subject,
			institution_name: c.institution_name,
			status: c.status,
			similarity_score: parseFloat(score.toFixed(2)),
			matched_keywords: uniqueKeywords.length > 0 ? uniqueKeywords : queryTokens.slice(0, 3)
		});
	}
	return matches.sort((a, b) => b.similarity_score - a.similarity_score).slice(0, 6);
}
var latency = () => new Promise((r) => setTimeout(r, 300 + Math.random() * 300));
function makeId(prefix) {
	return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}
function apiErr(code, message, status = 422) {
	throw {
		code,
		message,
		status
	};
}
function slaStatus(c) {
	if (!isActive(c.status) || !c.due_date) return "ON_TRACK";
	const now = Date.now();
	const hoursLeft = (new Date(c.due_date).getTime() - now) / 36e5;
	if (hoursLeft < 0) return "OVERDUE";
	if (hoursLeft < 48) return "APPROACHING";
	return "ON_TRACK";
}
var DEMO_USERS = {
	ADMIN: {
		id: "user-admin",
		email: "admin@aicte-demo.gov.in",
		full_name: "Smt. Sunita Sharma",
		role: "ADMIN",
		bureau_id: null,
		bureau_name: null,
		bureau_code: null,
		permissions: [
			"cases:read:all",
			"cases:create",
			"cases:update:status",
			"cases:assign",
			"cases:notes:create",
			"cases:notes:read:confidential",
			"cases:export",
			"cases:import",
			"dashboard:read:all",
			"settings:manage",
			"audit:read:all"
		]
	},
	SUPERVISOR: {
		id: "user-supervisor",
		email: "supervisor@aicte-demo.gov.in",
		full_name: "Dr. Ramesh Chandra",
		role: "SUPERVISOR",
		bureau_id: null,
		bureau_name: null,
		bureau_code: null,
		permissions: [
			"cases:read:all",
			"cases:assign",
			"cases:notes:create",
			"cases:notes:read:confidential",
			"cases:export",
			"dashboard:read:all",
			"audit:read:all"
		]
	},
	OFFICER: {
		id: "officer-appr-1",
		email: "officer.appr@aicte-demo.gov.in",
		full_name: "Shri Arvind Verma",
		role: "OFFICER",
		bureau_id: "bureau-appr",
		bureau_name: "Approval Bureau",
		bureau_code: "APPR",
		permissions: [
			"cases:read:bureau",
			"cases:update:status",
			"cases:notes:create",
			"cases:notes:read:confidential",
			"dashboard:read:bureau",
			"audit:read:bureau"
		]
	},
	AUDITOR: {
		id: "user-auditor",
		email: "auditor@aicte-demo.gov.in",
		full_name: "CA Ananya Iyer",
		role: "AUDITOR",
		bureau_id: null,
		bureau_name: null,
		bureau_code: null,
		permissions: [
			"cases:read:all:redacted",
			"cases:export:redacted",
			"dashboard:read:all",
			"audit:read:all"
		]
	}
};
async function mockSwitchRole(role) {
	await latency();
	const user = DEMO_USERS[role.toUpperCase()];
	if (!user) apiErr("INVALID_ROLE", `Invalid role: ${role}. Valid: ADMIN, SUPERVISOR, OFFICER, AUDITOR`, 400);
	return user;
}
async function mockListBureaus() {
	await latency();
	return MOCK_BUREAUS;
}
async function mockListOfficers(bureauId) {
	await latency();
	return BUREAU_OFFICERS[bureauId] ?? [];
}
async function mockListCases(params, currentRole, currentBureauId) {
	await latency();
	let cases = getCases();
	if (currentRole === "OFFICER" && currentBureauId) cases = cases.filter((c) => c.bureau_id === currentBureauId);
	if (currentRole === "AUDITOR") cases = cases.map((c) => ({
		...c,
		description_confidential: void 0
	}));
	if (params.bureau_id) cases = cases.filter((c) => c.bureau_id === params.bureau_id);
	if (params.status) cases = cases.filter((c) => c.status === params.status);
	if (params.priority) cases = cases.filter((c) => c.priority === params.priority);
	if (params.search) {
		const q = params.search.toLowerCase();
		cases = cases.filter((c) => c.case_reference_id.toLowerCase().includes(q) || c.subject.toLowerCase().includes(q) || c.category.toLowerCase().includes(q) || c.institution_name.toLowerCase().includes(q));
	}
	const sortBy = params.sort_by ?? "created_at";
	const sortDir = params.sort_dir ?? "desc";
	cases = [...cases].sort((a, b) => {
		let av = a[sortBy] ?? "";
		let bv = b[sortBy] ?? "";
		if (sortBy === "priority") {
			const order = {
				LOW: 0,
				MEDIUM: 1,
				HIGH: 2,
				URGENT: 3
			};
			av = order[a.priority] ?? 0;
			bv = order[b.priority] ?? 0;
		}
		return sortDir === "desc" ? av > bv ? -1 : 1 : av < bv ? -1 : 1;
	});
	const total = cases.length;
	const page = params.page ?? 1;
	const pageSize = params.page_size ?? 20;
	const start = (page - 1) * pageSize;
	return {
		items: cases.slice(start, start + pageSize),
		total,
		page,
		page_size: pageSize,
		total_pages: Math.ceil(total / pageSize) || 1
	};
}
async function mockGetCase(caseRef, currentRole) {
	await latency();
	const c = getCaseByRef(caseRef);
	if (!c) apiErr("NOT_FOUND", `Case ${caseRef} not found.`, 404);
	if (currentRole === "AUDITOR") return {
		...c,
		description_confidential: void 0
	};
	return c;
}
async function mockTransitionCase(params, currentRole, currentBureauId) {
	await latency();
	const c = getCaseByRef(params.case_ref);
	if (!c) apiErr("NOT_FOUND", `Case ${params.case_ref} not found.`, 404);
	if (currentRole === "AUDITOR") apiErr("INSUFFICIENT_ROLE_PERMISSIONS", "AUDITOR role cannot change case status.", 403);
	if (currentRole === "OFFICER" && currentBureauId && c.bureau_id !== currentBureauId) apiErr("INSUFFICIENT_BUREAU_PERMISSIONS", "Case belongs to another bureau.", 403);
	if (c.status === "Closed") apiErr("CASE_IS_CLOSED", `Case ${params.case_ref} is Closed and cannot transition.`);
	if (!canTransition(c.status, params.to_status)) apiErr("INVALID_STATE_TRANSITION", `Cannot transition from '${c.status}' to '${params.to_status}'.`);
	if (!params.remarks || params.remarks.trim().length < 3) apiErr("MISSING_REMARKS", "Remarks are required (min 3 characters).");
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const prev = c.status;
	const patch = {
		status: params.to_status,
		updated_at: now
	};
	if (params.to_status === "Resolved") {
		patch.resolved_at = now;
		patch.closure_remarks = params.remarks;
	}
	if (params.to_status === "Closed") patch.closed_at = now;
	if (params.to_status === "In Progress" && c.status === "Resolved") patch.resolved_at = null;
	const updated = updateCase(params.case_ref, patch);
	addTimelineEvent(params.case_ref, {
		id: makeId("tl"),
		case_id: c.id,
		actor_id: "current-user",
		actor_role: currentRole,
		actor_name: null,
		event_type: params.to_status === "Resolved" ? "RESOLVED" : params.to_status === "Closed" ? "CLOSED" : "STATUS_CHANGE",
		previous_state: prev,
		new_state: params.to_status,
		remark: params.remarks,
		metadata: {
			remarks: params.remarks,
			action: "execute_transition"
		},
		timestamp: now
	});
	return updated;
}
async function mockAssignCase(params, currentRole) {
	await latency();
	if (!["ADMIN", "SUPERVISOR"].includes(currentRole)) apiErr("INSUFFICIENT_ROLE_PERMISSIONS", "Only ADMIN or SUPERVISOR can assign cases.", 403);
	const c = getCaseByRef(params.case_ref);
	if (!c) apiErr("NOT_FOUND", `Case ${params.case_ref} not found.`, 404);
	const bureau = MOCK_BUREAUS.find((b) => b.id === params.to_bureau_id);
	if (!bureau) apiErr("INVALID_BUREAU", `Bureau ${params.to_bureau_id} not found.`, 404);
	const officerList = BUREAU_OFFICERS[params.to_bureau_id] ?? [];
	const officer = params.to_officer_id ? officerList.find((o) => o.id === params.to_officer_id) : officerList[0];
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const fromBureauName = c.bureau_name;
	const updated = updateCase(params.case_ref, {
		bureau_id: params.to_bureau_id,
		bureau_code: bureau.code,
		bureau_name: bureau.name,
		assigned_officer_id: officer?.id,
		assigned_officer_name: officer?.full_name,
		updated_at: now
	});
	addTimelineEvent(params.case_ref, {
		id: makeId("tl"),
		case_id: c.id,
		actor_id: "current-user",
		actor_role: currentRole,
		actor_name: null,
		event_type: "REASSIGNED",
		previous_state: c.status,
		new_state: c.status,
		remark: params.reason,
		metadata: {
			transfer_reason: params.reason,
			from_bureau: fromBureauName,
			to_bureau: bureau.name
		},
		timestamp: now
	});
	addHistory(params.case_ref, {
		id: makeId("hist"),
		case_id: c.id,
		from_bureau_id: c.bureau_id,
		from_bureau_name: fromBureauName,
		to_bureau_id: params.to_bureau_id,
		to_bureau_name: bureau.name,
		assigned_by_id: "current-user",
		assigned_by_name: null,
		transfer_reason: params.reason,
		created_at: now
	});
	return updated;
}
async function mockEscalateCase(params, currentRole) {
	await latency();
	const c = getCaseByRef(params.case_ref);
	if (!c) apiErr("NOT_FOUND", `Case ${params.case_ref} not found.`, 404);
	if (currentRole !== "ADMIN" && currentRole !== "SUPERVISOR") apiErr("INSUFFICIENT_ROLE_PERMISSIONS", `${currentRole} cannot escalate cases. Escalations are restricted to ADMIN and SUPERVISOR.`, 403);
	const newLevel = Math.min(c.escalation_level + 1, 2);
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const updated = updateCase(params.case_ref, {
		escalation_level: newLevel,
		updated_at: now
	});
	addTimelineEvent(params.case_ref, {
		id: makeId("tl"),
		case_id: c.id,
		actor_id: "current-user",
		actor_role: currentRole,
		actor_name: null,
		event_type: "ESCALATED",
		previous_state: c.status,
		new_state: c.status,
		remark: params.reason,
		metadata: {
			reason: params.reason,
			level: newLevel
		},
		timestamp: now
	});
	return updated;
}
async function mockAddNote(params, currentRole) {
	await latency();
	if (currentRole === "AUDITOR") apiErr("INSUFFICIENT_ROLE_PERMISSIONS", "AUDITOR cannot add notes.", 403);
	const c = getCaseByRef(params.case_ref);
	if (!c) apiErr("NOT_FOUND", `Case ${params.case_ref} not found.`, 404);
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const note = {
		id: makeId("note"),
		case_id: c.id,
		author_id: "current-user",
		author_name: null,
		author_role: currentRole,
		content: params.content,
		is_confidential: params.is_confidential,
		created_at: now
	};
	addNote$1(params.case_ref, note);
	addTimelineEvent(params.case_ref, {
		id: makeId("tl"),
		case_id: c.id,
		actor_id: "current-user",
		actor_role: currentRole,
		actor_name: null,
		event_type: "NOTE_ADDED",
		previous_state: c.status,
		new_state: c.status,
		remark: params.is_confidential ? "[Confidential note added]" : "Note added.",
		metadata: {
			note_id: note.id,
			is_confidential: params.is_confidential
		},
		timestamp: now
	});
	return note;
}
async function mockGetNotes(caseRef, currentRole) {
	await latency();
	const notes = getNotes$1(caseRef);
	if (currentRole === "AUDITOR") return notes.map((n) => n.is_confidential ? {
		...n,
		content: "[Confidential — not visible to Auditor]"
	} : n);
	return notes;
}
async function mockGetTimeline(caseRef) {
	await latency();
	return getTimeline$1(caseRef);
}
async function mockGetAssignmentHistory(caseRef) {
	await latency();
	return getHistory(caseRef);
}
async function mockGetDashboardStats(currentRole, bureauId) {
	await latency();
	let cases = getCases();
	if (currentRole === "OFFICER" && bureauId) cases = cases.filter((c) => c.bureau_id === bureauId);
	const total = cases.length;
	const resolved = cases.filter((c) => c.status === "Resolved").length;
	const closed = cases.filter((c) => c.status === "Closed").length;
	const active = total - resolved - closed;
	const overdue = cases.filter((c) => slaStatus(c) === "OVERDUE").length;
	const approaching = cases.filter((c) => slaStatus(c) === "APPROACHING").length;
	const onTrack = cases.filter((c) => slaStatus(c) === "ON_TRACK" && isActive(c.status)).length;
	const bureauBreakdown = MOCK_BUREAUS.map((b) => {
		const bc = cases.filter((c) => c.bureau_id === b.id);
		return {
			bureau_id: b.id,
			bureau_code: b.code,
			bureau_name: b.name,
			total: bc.length,
			active: bc.filter((c) => isActive(c.status)).length,
			overdue: bc.filter((c) => slaStatus(c) === "OVERDUE").length,
			resolved: bc.filter((c) => c.status === "Resolved" || c.status === "Closed").length
		};
	});
	const statusCounts = {};
	for (const c of cases) statusCounts[c.status] = (statusCounts[c.status] ?? 0) + 1;
	const priorityCounts = {};
	for (const c of cases) priorityCounts[c.priority] = (priorityCounts[c.priority] ?? 0) + 1;
	return {
		total_cases: total,
		active_cases: active,
		resolved_cases: resolved,
		closed_cases: closed,
		overdue_cases: overdue,
		approaching_cases: approaching,
		on_track_cases: onTrack,
		resolution_rate: total > 0 ? (resolved + closed) / total : 0,
		bureau_breakdown: bureauBreakdown,
		status_breakdown: Object.entries(statusCounts).map(([status, count]) => ({
			status,
			count: count ?? 0
		})),
		priority_breakdown: Object.entries(priorityCounts).map(([priority, count]) => ({
			priority,
			count: count ?? 0
		}))
	};
}
async function mockGetSlaRadar(currentRole, bureauId) {
	await latency();
	let cases = getCases();
	if (currentRole === "OFFICER" && bureauId) cases = cases.filter((c) => c.bureau_id === bureauId || c.bureau_code === bureauId);
	else if (bureauId && bureauId !== "ALL") cases = cases.filter((c) => c.bureau_id === bureauId || c.bureau_code === bureauId);
	const active = cases.filter((c) => isActive(c.status));
	const completed = cases.filter((c) => !isActive(c.status));
	const now = Date.now();
	function toItem(c) {
		const due = c.due_date ? new Date(c.due_date).getTime() : null;
		const hoursLeft = due !== null ? (due - now) / 36e5 : null;
		const sl = slaStatus(c);
		return {
			case_reference_id: c.case_reference_id,
			subject: c.subject,
			category: c.category,
			priority: c.priority,
			status: c.status,
			bureau_code: c.bureau_code,
			bureau_name: c.bureau_name,
			institution_name: c.institution_name,
			due_date: c.due_date,
			escalation_level: c.escalation_level,
			sla_status: sl,
			hours_remaining: hoursLeft !== null ? parseFloat(hoursLeft.toFixed(1)) : null,
			is_overdue: sl === "OVERDUE"
		};
	}
	const overdueItems = active.filter((c) => slaStatus(c) === "OVERDUE").map(toItem);
	const approachingItems = active.filter((c) => slaStatus(c) === "APPROACHING").map(toItem);
	const onTrack = active.filter((c) => slaStatus(c) === "ON_TRACK").length;
	overdueItems.sort((a, b) => (a.hours_remaining ?? 0) - (b.hours_remaining ?? 0));
	approachingItems.sort((a, b) => (a.hours_remaining ?? 9999) - (b.hours_remaining ?? 9999));
	return {
		total_active_cases: active.length,
		overdue_count: overdueItems.length,
		approaching_count: approachingItems.length,
		on_track_count: onTrack,
		completed_count: completed.length,
		overdue_cases: overdueItems,
		approaching_cases: approachingItems
	};
}
async function mockRunTriage(text) {
	await latency();
	return runTriageRule(text);
}
async function mockCheckDuplicates(query) {
	await latency();
	return checkDuplicatesRule(query, getCases());
}
async function mockApplyTriage(caseRef, result, currentRole) {
	await latency();
	const c = getCaseByRef(caseRef);
	if (!c) apiErr("NOT_FOUND", `Case ${caseRef} not found.`, 404);
	if (!["ADMIN", "SUPERVISOR"].includes(currentRole)) apiErr("INSUFFICIENT_ROLE_PERMISSIONS", "Only ADMIN or SUPERVISOR can apply triage.", 403);
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const updated = updateCase(caseRef, {
		bureau_code: result.recommended_bureau_code,
		category: result.recommended_category,
		priority: result.recommended_priority,
		updated_at: now
	});
	addTimelineEvent(caseRef, {
		id: makeId("tl"),
		case_id: c.id,
		actor_id: "current-user",
		actor_role: currentRole,
		actor_name: null,
		event_type: "TRIAGE_APPLIED",
		previous_state: c.status,
		new_state: c.status,
		remark: `Triage applied: recommended ${result.recommended_bureau_name} (${Math.round(result.confidence * 100)}% confidence).`,
		metadata: {
			action: "apply_triage",
			confidence: result.confidence
		},
		timestamp: now
	});
	return updated;
}
var VALID_BUREAU_CODES = [
	"APPR",
	"STU",
	"FDC",
	"FIN"
];
var VALID_PRIORITIES = [
	"LOW",
	"MEDIUM",
	"HIGH",
	"URGENT"
];
var AICTE_ID_PATTERN = /^\d-\d{7}$/;
var MOCK_AICTE_IDS = [
	"1-3324561",
	"1-4521890",
	"1-2893421",
	"2-7654321",
	"1-5643210",
	"1-8765432",
	"2-3456789",
	"1-6789012",
	"1-9876543",
	"2-1234567",
	"1-7654321",
	"1-4567890",
	"2-8901234",
	"2-2345678",
	"1-5678901"
];
async function mockPreviewCsv(csvContent) {
	await latency();
	const lines = csvContent.trim().split(/\r?\n/);
	if (lines.length < 2) return {
		total_rows: 0,
		valid_rows: 0,
		invalid_rows: 0,
		can_commit: false,
		rows: []
	};
	const rows = lines.slice(1).map((line, idx) => {
		const [aicte_id = "", bureau_code = "", subject = "", category = "", priority = "MEDIUM", description = "", is_confidential_str = "false"] = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
		const errors = [];
		const rowNum = idx + 2;
		if (!AICTE_ID_PATTERN.test(aicte_id)) errors.push({
			row_number: rowNum,
			field: "institution_aicte_id",
			message: `Invalid AICTE ID format '${aicte_id}'. Expected: \\d-\\d{7}`
		});
		else if (!MOCK_AICTE_IDS.includes(aicte_id)) errors.push({
			row_number: rowNum,
			field: "institution_aicte_id",
			message: `AICTE ID '${aicte_id}' not found in institution registry.`
		});
		if (!VALID_BUREAU_CODES.includes(bureau_code.toUpperCase())) errors.push({
			row_number: rowNum,
			field: "bureau_code",
			message: `Unknown bureau code '${bureau_code}'. Valid: ${VALID_BUREAU_CODES.join(", ")}`
		});
		if (!subject.trim()) errors.push({
			row_number: rowNum,
			field: "subject",
			message: "Subject is required."
		});
		const normalPriority = priority.toUpperCase();
		if (normalPriority && !VALID_PRIORITIES.includes(normalPriority)) errors.push({
			row_number: rowNum,
			field: "priority",
			message: `Invalid priority '${priority}'. Valid: ${VALID_PRIORITIES.join(", ")}`
		});
		const bureau = MOCK_BUREAUS.find((b) => b.code === bureau_code.toUpperCase());
		const is_confidential = [
			"true",
			"1",
			"yes"
		].includes(is_confidential_str.toLowerCase());
		return {
			row_number: rowNum,
			is_valid: errors.length === 0,
			institution_aicte_id: aicte_id,
			institution_name: MOCK_AICTE_IDS.includes(aicte_id) ? "Known Institution" : null,
			bureau_code: bureau_code.toUpperCase(),
			bureau_name: bureau?.name ?? null,
			subject,
			category: category || "General",
			priority: normalPriority || "MEDIUM",
			is_confidential,
			description,
			errors,
			warnings: [],
			duplicate_case_ref: null
		};
	});
	const valid = rows.filter((r) => r.is_valid).length;
	return {
		total_rows: rows.length,
		valid_rows: valid,
		invalid_rows: rows.length - valid,
		can_commit: valid > 0,
		rows
	};
}
async function mockCommitCsv(rows, currentRole) {
	await latency();
	if (!["ADMIN"].includes(currentRole)) apiErr("INSUFFICIENT_ROLE_PERMISSIONS", "Only ADMIN can import CSV cases.", 403);
	const validRows = rows.filter((r) => r.is_valid);
	const refs = [];
	const existingCount = getCases().length;
	for (let i = 0; i < validRows.length; i++) {
		const row = validRows[i];
		const bureau = MOCK_BUREAUS.find((b) => b.code === row.bureau_code);
		if (!bureau) continue;
		const ref = `AICTE-2026-${existingCount + i + 1001}`;
		refs.push(ref);
		appendCase({
			id: makeId("case"),
			case_reference_id: ref,
			institution_id: `inst-csv-${i}`,
			institution_name: row.institution_name ?? row.institution_aicte_id,
			aicte_permanent_id: row.institution_aicte_id,
			bureau_id: bureau.id,
			bureau_code: bureau.code,
			bureau_name: bureau.name,
			subject: row.subject,
			description_redacted: row.description,
			description_confidential: row.is_confidential ? row.description : void 0,
			category: row.category,
			priority: row.priority || "MEDIUM",
			status: "Received",
			due_date: new Date(Date.now() + 6048e5).toISOString(),
			escalation_level: 0,
			created_at: (/* @__PURE__ */ new Date()).toISOString(),
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			resolved_at: null,
			closed_at: null,
			closure_remarks: null
		});
	}
	return {
		imported_count: validRows.length,
		skipped_count: rows.length - validRows.length,
		failed_count: 0,
		created_case_references: refs
	};
}
var _mockRole = "SUPERVISOR";
var _mockBureauId = null;
function setMockRole(role, bureauId) {
	_mockRole = role;
	_mockBureauId = bureauId ?? null;
}
/** Switch demo role. In live mode this calls switch-demo-role and stores the JWT. */
async function switchRole(role) {
	{
		const user = await mockSwitchRole(role);
		setMockRole(role, user.bureau_id);
		return user;
	}
}
async function listBureaus() {
	return mockListBureaus();
}
var getBureaus = listBureaus;
async function listOfficers(bureauId) {
	return mockListOfficers(bureauId);
}
async function listCases(params = {}) {
	return mockListCases(params, _mockRole, _mockBureauId);
}
async function getCase(caseRef) {
	return mockGetCase(caseRef, _mockRole);
}
async function transitionCase(params) {
	return mockTransitionCase(params, _mockRole, _mockBureauId);
}
async function assignCase(params) {
	return mockAssignCase(params, _mockRole);
}
async function escalateCase(params) {
	return mockEscalateCase(params, _mockRole);
}
async function getTimeline(caseRef) {
	return mockGetTimeline(caseRef);
}
async function getNotes(caseRef) {
	return mockGetNotes(caseRef, _mockRole);
}
async function addNote(params) {
	return mockAddNote(params, _mockRole);
}
async function getAssignmentHistory(caseRef) {
	return mockGetAssignmentHistory(caseRef);
}
async function getDashboardStats() {
	return mockGetDashboardStats(_mockRole, _mockBureauId);
}
async function getSlaRadar(bureauId) {
	return mockGetSlaRadar(_mockRole, _mockRole === "OFFICER" ? _mockBureauId : bureauId === "ALL" ? void 0 : bureauId);
}
async function runTriage(text) {
	return mockRunTriage(text);
}
async function checkDuplicates(query) {
	return mockCheckDuplicates(query);
}
async function applyTriage(caseRef, result) {
	return mockApplyTriage(caseRef, result, _mockRole);
}
async function previewCsv(csvContent) {
	return mockPreviewCsv(csvContent);
}
async function commitCsv(rows) {
	return mockCommitCsv(rows, _mockRole);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
export { switchRole as A, isTerminal as C, previewCsv as D, listOfficers as E, runTriage as O, isActive as S, listCases as T, getCase as _, TRANSITION_GUARD_RULES as a, getSlaRadar as b, assignCase as c, cn as d, commitCsv as f, getBureaus as g, getAssignmentHistory as h, Button as i, transitionCase as j, setMockRole as k, canTransition as l, getAllowedTransitions as m, ALL_STATUSES as n, addNote as o, escalateCase as p, AUDIT_EVENT_LABELS as r, applyTriage as s, ALLOWED_TRANSITIONS as t, checkDuplicates as u, getDashboardStats as v, listBureaus as w, getTimeline as x, getNotes as y };
