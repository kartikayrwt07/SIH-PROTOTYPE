import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as getSlaRadar, g as getBureaus, i as Button } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { h as Lock, k as CircleAlert, l as Search } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-f_2O8qQw.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SlaPill, t as LifecycleStrip } from "./SlaPill-C7x6Ry1j.mjs";
import { t as PriorityMark } from "./PriorityMark-zbBOy4ZR.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as EscalateModal } from "./EscalateModal-BBWFsjKk.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
import { t as DataTable } from "./DataTable-BiBJ9Tiy.mjs";
import { t as Input } from "./input-BlWpASKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sla-radar-DtoStxrU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SlaRadarView() {
	const navigate = useNavigate();
	const { role, user } = useRole();
	const [selectedBureau, setSelectedBureau] = (0, import_react.useState)("ALL");
	const [search, setSearch] = (0, import_react.useState)("");
	const [escalatingItem, setEscalatingItem] = (0, import_react.useState)(null);
	const isOfficer = role === "OFFICER";
	const canEscalate = role === "ADMIN" || role === "SUPERVISOR";
	const effectiveBureau = isOfficer ? user?.bureau_id ?? "bureau-appr" : selectedBureau;
	const { data: bureaus = [] } = useQuery({
		queryKey: ["bureaus"],
		queryFn: getBureaus,
		staleTime: 3e5
	});
	const { data: summary, isLoading, isError, error, refetch } = useQuery({
		queryKey: ["slaRadar", effectiveBureau],
		queryFn: () => getSlaRadar(effectiveBureau === "ALL" ? void 0 : effectiveBureau),
		staleTime: 3e4
	});
	const rankedItems = (0, import_react.useMemo)(() => {
		if (!summary) return [];
		const combined = [...summary.overdue_cases ?? [], ...summary.approaching_cases ?? []];
		if (!search.trim()) return combined;
		const q = search.toLowerCase().trim();
		return combined.filter((c) => c.case_reference_id.toLowerCase().includes(q) || c.institution_name && c.institution_name.toLowerCase().includes(q) || c.subject.toLowerCase().includes(q));
	}, [summary, search]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
					title: "SLA radar",
					description: "Cases ranked by urgency across bureaus."
				}), summary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-[var(--color-text-secondary)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--sla-overdue-text)] tabular-nums",
							children: summary.overdue_count
						}),
						" ",
						"overdue,",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--sla-approaching-text)] tabular-nums",
							children: summary.approaching_count
						}),
						" ",
						"approaching the 48-hour threshold,",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--sla-on-track-text)] tabular-nums",
							children: summary.on_track_count
						}),
						" ",
						"on track."
					]
				})]
			}),
			isError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between p-3.5 text-xs bg-[var(--sla-overdue-bg)] dark:bg-[#2B1015]/50 text-[var(--sla-overdue-text)] dark:text-[#F87171] border border-[var(--sla-overdue-text)]/20 dark:border-[#F87171]/35 rounded-[6px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Failed to load SLA radar data: ", error?.message || "Unknown error"] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => refetch(),
					className: "h-7 text-xs border-[var(--sla-overdue-text)]/30",
					children: "Try again"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4 py-3 border-y border-[var(--color-rule)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-[var(--color-text-secondary)]",
						children: "Bureau jurisdiction:"
					}), isOfficer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-xs font-semibold text-[var(--color-ink)] bg-surface px-2.5 py-1 border border-[var(--color-rule)] rounded-[6px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: user?.bureau_name || "Approval Bureau" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[10px] text-[var(--color-text-muted)]",
								children: [
									"(",
									user?.bureau_code || "APPR",
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3 w-3 text-[var(--color-text-muted)] ml-1" })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: selectedBureau,
						onValueChange: (val) => setSelectedBureau(val),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8.5 w-[200px] text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All bureaus" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "ALL",
							children: "All bureaus"
						}), bureaus.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: b.id,
							children: [
								b.name,
								" (",
								b.code,
								")"
							]
						}, b.id))] })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:w-64",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--color-text-muted)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "text",
						placeholder: "Search radar...",
						value: search,
						onChange: (e) => setSearch(e.target.value),
						className: "pl-8 text-xs h-8.5 bg-surface border-[var(--color-rule)] rounded-[6px]"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				columns: [
					{
						key: "case_reference_id",
						header: "Case",
						width: "140px",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-[var(--color-text-secondary)]",
							children: item.case_reference_id
						})
					},
					{
						key: "institution_name",
						header: "Institution",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium text-[var(--color-text-primary)] text-xs line-clamp-1",
							children: item.institution_name || "Institution Name Pending"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-[var(--color-text-muted)] line-clamp-1",
							children: item.subject
						})] })
					},
					{
						key: "bureau",
						header: "Bureau",
						width: "90px",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-[var(--color-text-secondary)]",
							title: item.bureau_name || "",
							children: item.bureau_code
						})
					},
					{
						key: "stage",
						header: "Stage",
						width: "220px",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifecycleStrip, {
								currentStatus: item.status,
								variant: "compact"
							})
						})
					},
					{
						key: "priority",
						header: "Priority",
						width: "110px",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: item.priority })
					},
					{
						key: "remaining_time",
						header: "Remaining time",
						width: "150px",
						align: "right",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlaPill, {
							dueDate: item.due_date,
							hoursRemaining: item.hours_remaining,
							status: item.sla_status,
							isResolved: false
						})
					},
					{
						key: "escalation_level",
						header: "Escalation",
						width: "100px",
						cell: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-[var(--color-text-secondary)] tabular-nums",
							children: item.escalation_level > 0 ? `Level ${item.escalation_level}` : "—"
						})
					},
					{
						key: "actions",
						header: "",
						width: "90px",
						align: "right",
						cell: (item) => {
							if (!canEscalate) return null;
							const isMax = (item.escalation_level ?? 0) >= 2;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								disabled: isMax,
								onClick: (e) => {
									e.stopPropagation();
									setEscalatingItem(item);
								},
								className: "h-7 px-2.5 text-xs font-normal border-[var(--color-rule)] rounded-[6px] text-[var(--sla-overdue-text)] hover:text-[var(--sla-overdue-text)] bg-surface",
								children: isMax ? "Max level" : "Escalate"
							});
						}
					}
				],
				data: rankedItems,
				keyField: (item) => item.case_reference_id,
				isLoading,
				skeletonRows: 8,
				onRowClick: (item) => navigate({
					to: "/cases/$id",
					params: { id: item.case_reference_id }
				}),
				emptyMessage: "No cases currently requiring urgency intervention.",
				emptyInstruction: "All open grievances within this bureau are operating on track."
			}),
			escalatingItem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EscalateModal, {
				caseItem: escalatingItem,
				open: !!escalatingItem,
				onOpenChange: (open) => !open && setEscalatingItem(null)
			})
		]
	});
}
var SplitComponent = SlaRadarView;
//#endregion
export { SplitComponent as component };
