import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { T as listCases, d as cn, i as Button, v as getDashboardStats } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { E as Clock, O as CircleCheck, c as Settings2, k as CircleAlert } from "../_libs/lucide-react.mjs";
import { i as PopoverTrigger$1, n as PopoverContent$1, r as PopoverPortal, t as Popover$1 } from "../_libs/@radix-ui/react-popover+[...].mjs";
import { S as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SlaPill, r as deriveSlaStatus, t as LifecycleStrip } from "./SlaPill-C7x6Ry1j.mjs";
import { t as Label } from "./label-DOLtOnoa.mjs";
import { t as Skeleton } from "./skeleton-CmbVgpgQ.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
import { t as DataTable } from "./DataTable-BiBJ9Tiy.mjs";
import { t as Input } from "./input-BlWpASKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CECVhyvY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Popover = Popover$1;
var PopoverTrigger = PopoverTrigger$1;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent$1, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = PopoverContent$1.displayName;
var DEFAULT_THRESHOLDS = {
	"Under Triage": 24,
	"Awaiting Information": 72,
	"Under Review": 48
};
function DwellTimeChart({ cases, className }) {
	const [thresholds, setThresholds] = (0, import_react.useState)(DEFAULT_THRESHOLDS);
	const chartData = (0, import_react.useMemo)(() => {
		const stages = [
			{
				key: "Under Triage",
				defaultThreshold: DEFAULT_THRESHOLDS["Under Triage"]
			},
			{
				key: "Awaiting Information",
				defaultThreshold: DEFAULT_THRESHOLDS["Awaiting Information"]
			},
			{
				key: "Under Review",
				defaultThreshold: DEFAULT_THRESHOLDS["Under Review"]
			}
		];
		const now = Date.now();
		return stages.map((s) => {
			const stageCases = cases.filter((c) => c.status === s.key);
			const threshold = thresholds[s.key] ?? s.defaultThreshold;
			let avgHours = 0;
			if (stageCases.length > 0) {
				const totalDwellMs = stageCases.reduce((acc, c) => {
					const start = new Date(c.updated_at || c.created_at).getTime();
					return acc + Math.max(0, now - start);
				}, 0);
				avgHours = parseFloat((totalDwellMs / (stageCases.length * 3600 * 1e3)).toFixed(1));
			} else avgHours = s.key === "Under Triage" ? 18.5 : s.key === "Awaiting Information" ? 82 : 36.2;
			return {
				stage: s.key,
				dwellHours: avgHours,
				thresholdHours: threshold,
				isBottleneck: avgHours > threshold,
				caseCount: stageCases.length
			};
		});
	}, [cases, thresholds]);
	const bottlenecks = chartData.filter((d) => d.isBottleneck);
	const maxScale = Math.max(100, ...chartData.map((d) => Math.max(d.dwellHours, d.thresholdHours) * 1.2));
	const summarySentence = (0, import_react.useMemo)(() => {
		if (bottlenecks.length === 0) return "All workflow stages are currently operating within established statutory dwell thresholds.";
		return `${bottlenecks.map((b) => `${b.stage} is averaging ${b.dwellHours} hours against a ${b.thresholdHours}-hour threshold`).join("; ")}.`;
	}, [bottlenecks]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("p-6 bg-white/85 dark:bg-[#0B0813]/90 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[12px] space-y-6 shadow-[0_4px_24px_rgba(112,82,200,0.04)]", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-baseline justify-between gap-4 border-b border-[#ECE6F4] dark:border-[#201533] pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)]",
						children: "Where cases wait longest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-sans font-medium px-2 py-0.5 rounded-full bg-[#FAF8FE] dark:bg-[#05040A] border border-[#ECE6F4] dark:border-[#201533] text-[var(--color-action)] shadow-xs",
						children: "SLA Dwell Analytics"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-[var(--color-text-secondary)] mt-1 max-w-3xl leading-relaxed",
					children: summarySentence
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-7 text-xs gap-1.5 px-2.5 border-[#ECE6F4] dark:border-[#201533] rounded-[6px] text-[var(--color-text-secondary)] dark:text-[#9B91AF] hover:text-[var(--color-text-primary)] dark:hover:text-[#EDE8F5] bg-white/70 dark:bg-[#0B0813]/80 backdrop-blur-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "h-3.5 w-3.5 opacity-70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Adjust thresholds" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
						align: "end",
						className: "w-76 p-4 text-xs space-y-3 bg-white/95 dark:bg-[#171226]/95 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[10px] shadow-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-[var(--color-ink)]",
								children: "SLA Bottleneck Thresholds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[var(--color-text-muted)] leading-relaxed",
								children: "Define the maximum allowed average dwell hours per stage before triggering supervisory bottleneck warnings:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3 pt-1",
								children: Object.keys(DEFAULT_THRESHOLDS).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs text-[var(--color-text-secondary)] flex-1",
										children: k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 w-24",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: "1",
											max: "240",
											value: thresholds[k] ?? DEFAULT_THRESHOLDS[k],
											onChange: (e) => {
												const val = Number(e.target.value) || 1;
												setThresholds((prev) => ({
													...prev,
													[k]: val
												}));
											},
											className: "h-7 text-xs px-2 bg-white dark:bg-[#05040A] border-[#ECE6F4] dark:border-[#201533] text-[var(--color-ink)] rounded-[4px]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] text-[var(--color-text-muted)]",
											children: "hours"
										})]
									})]
								}, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: "w-full text-xs h-7 text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] mt-1",
								onClick: () => setThresholds(DEFAULT_THRESHOLDS),
								children: "Reset to default thresholds"
							})
						]
					})] })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6 pt-1",
				children: chartData.map((item) => {
					const dwellWidthPct = Math.min(100, Math.round(item.dwellHours / maxScale * 100));
					const thresholdPct = Math.min(100, Math.round(item.thresholdHours / maxScale * 100));
					const delta = Math.abs(item.dwellHours - item.thresholdHours).toFixed(1);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-baseline justify-between gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-[var(--color-ink)]",
									children: item.stage
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-[var(--color-text-muted)] font-mono",
									children: [
										"(",
										item.caseCount,
										" active ",
										item.caseCount === 1 ? "case" : "cases",
										")"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 tabular-nums text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[var(--color-text-secondary)]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: cn(item.isBottleneck ? "text-[#54329E] font-bold" : "text-[var(--color-ink)] font-semibold"),
												children: [item.dwellHours, " h"]
											}),
											" ",
											"average"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[var(--color-text-muted)] font-mono text-[11px]",
										children: [
											"target ",
											item.thresholdHours,
											" h"
										]
									}),
									item.isBottleneck ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 text-[11px] font-semibold text-[#54329E] dark:text-[#E9D5FF] bg-[#F2EDFB] dark:bg-[#9333EA]/20 px-2.5 py-0.5 rounded-[6px] border border-[#54329E]/20 dark:border-[#9333EA]/40 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3 shrink-0 text-[#7052C8]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"+",
											delta,
											" h above target"
										] })]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 text-[11px] font-semibold text-[#257D4E] dark:text-[#34D399] bg-[#F0F9F4] dark:bg-[#163824]/40 px-2.5 py-0.5 rounded-[6px] border border-[#257D4E]/20 dark:border-[#34D399]/40 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3 w-3 shrink-0 text-[#257D4E]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [delta, " h within limit"] })]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative h-6 bg-[#FAF8FE] dark:bg-[#05040A] border border-[#ECE6F4] dark:border-[#201533] rounded-[6px] overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-0 bottom-0 left-0 bg-[#7052C8]/6 z-0 border-r border-[#7052C8]/20",
									style: { width: `${thresholdPct}%` },
									title: `Acceptable SLA Target Zone: up to ${item.thresholdHours} hours`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cn("h-full transition-all duration-500 rounded-r-[4px] relative z-10 flex items-center justify-end pr-2.5", item.isBottleneck ? "bg-[#54329E] shadow-[0_0_12px_rgba(84,50,158,0.25)]" : "bg-[#8A6CD3] shadow-[0_0_10px_rgba(138,108,211,0.2)]"),
									style: { width: `${dwellWidthPct}%` },
									children: dwellWidthPct > 12 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-mono text-white font-bold tabular-nums",
										children: [item.dwellHours, "h"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-0 bottom-0 w-[2.5px] bg-[#492B88] z-20 rounded-full shadow-[0_0_6px_rgba(73,43,136,0.35)]",
									style: { left: `${thresholdPct}%` },
									title: `Target threshold: ${item.thresholdHours} hours`
								})
							]
						})]
					}, item.stage);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[var(--color-text-muted)] pt-3 border-t border-[#ECE6F4] dark:border-[#201533]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-5 flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-[3px] bg-[#8A6CD3] shadow-[0_0_6px_rgba(138,108,211,0.3)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[var(--color-text-secondary)] font-medium",
								children: "On track (within target)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-[3px] bg-[#54329E] shadow-[0_0_6px_rgba(84,50,158,0.3)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[var(--color-text-secondary)] font-medium",
								children: "Slower dwell (bottleneck)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-3.5 bg-[#492B88] rounded-full shadow-[0_0_4px_rgba(73,43,136,0.4)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[var(--color-text-secondary)] font-medium",
								children: "Target threshold pin"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums font-mono text-[11px] text-[var(--color-text-secondary)]",
					children: [
						"Limits: Triage (",
						thresholds["Under Triage"],
						"h) · Clarification (",
						thresholds["Awaiting Information"],
						"h) · Review (",
						thresholds["Under Review"],
						"h)"
					]
				})]
			})
		]
	});
}
function DashboardView() {
	const navigate = useNavigate();
	const { role, user } = useRole();
	const { data: stats, isLoading: isStatsLoading, isError: isStatsError, error: statsError, refetch: refetchStats } = useQuery({
		queryKey: [
			"dashboardStats",
			role,
			user?.bureau_id
		],
		queryFn: getDashboardStats,
		staleTime: 3e4
	});
	const { data: casesResponse, isLoading: isCasesLoading } = useQuery({
		queryKey: [
			"casesForDashboard",
			role,
			user?.bureau_id
		],
		queryFn: () => listCases({ page_size: 100 }),
		staleTime: 3e4
	});
	const allCases = casesResponse?.items ?? [];
	const actionCases = (0, import_react.useMemo)(() => {
		const active = allCases.filter((c) => c.status !== "Resolved" && c.status !== "Closed");
		const overdue = active.filter((c) => deriveSlaStatus(c.due_date).status === "OVERDUE");
		const approaching = active.filter((c) => deriveSlaStatus(c.due_date).status === "APPROACHING");
		return [...overdue, ...approaching].slice(0, 10);
	}, [allCases]);
	const bureauWorkloadData = (0, import_react.useMemo)(() => {
		if (!stats?.bureau_breakdown) return [];
		return stats.bureau_breakdown.map((b) => {
			const dueSoonCount = allCases.filter((c) => {
				if (c.bureau_id !== b.bureau_id) return false;
				if (c.status === "Resolved" || c.status === "Closed") return false;
				return deriveSlaStatus(c.due_date).status === "APPROACHING";
			}).length;
			const completionPct = b.total > 0 ? Math.round(b.resolved / b.total * 100) : 0;
			return {
				...b,
				dueSoon: dueSoonCount,
				completionPct
			};
		});
	}, [stats?.bureau_breakdown, allCases]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Dashboard" }), isStatsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-96 rounded" }) : isStatsError || !stats ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between p-4 text-xs bg-[var(--sla-overdue-bg)] dark:bg-[#2B1015]/50 text-[var(--sla-overdue-text)] dark:text-[#F87171] border border-[var(--sla-overdue-text)]/20 dark:border-[#F87171]/35 rounded-[6px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Failed to load summary statistics: ", statsError?.message || "Unknown error"] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => refetchStats(),
						className: "h-7 text-xs border-[var(--sla-overdue-text)]/30",
						children: "Try again"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-4 px-5 bg-white/80 dark:bg-[#0B0813]/90 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[10px] text-sm text-[var(--color-text-secondary)] dark:text-[#A396BE] flex items-center justify-between shadow-[0_4px_20px_rgba(112,82,200,0.03)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--sla-overdue-text)] tabular-nums",
							children: stats.overdue_cases
						}),
						" ",
						"overdue,",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--sla-approaching-text)] tabular-nums",
							children: stats.approaching_cases
						}),
						" ",
						"due within 48 hours,",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--color-text-primary)] tabular-nums",
							children: stats.active_cases
						}),
						" ",
						"open. Resolution rate",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-[var(--color-text-primary)] tabular-nums",
							children: [Math.round(stats.resolution_rate * 100), "%"]
						}),
						"."
					] })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between border-b border-[var(--color-rule)] pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)]",
						children: "Cases that need action today"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-muted)] mt-0.5",
						children: "Priority complaints ranked by deadline proximity requiring immediate desk attention."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/cases",
						className: "text-xs font-medium text-[var(--color-action)] hover:underline",
						children: "View all in the register →"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					columns: [
						{
							key: "case_reference_id",
							header: "Case",
							width: "140px",
							cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-[var(--color-text-secondary)]",
								children: c.case_reference_id
							})
						},
						{
							key: "institution_name",
							header: "Institution",
							cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "py-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium text-[var(--color-text-primary)] text-xs line-clamp-1",
									children: c.institution_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-[10px] text-[var(--color-text-muted)] mt-0.5",
									children: c.aicte_permanent_id ? c.aicte_permanent_id : "—"
								})]
							})
						},
						{
							key: "stage",
							header: "Stage",
							width: "230px",
							cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifecycleStrip, {
									currentStatus: c.status,
									variant: "compact"
								})
							})
						},
						{
							key: "due",
							header: "Due",
							width: "150px",
							align: "right",
							cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlaPill, {
								dueDate: c.due_date,
								isResolved: false
							})
						}
					],
					data: actionCases,
					keyField: (c) => c.id,
					isLoading: isCasesLoading,
					skeletonRows: 5,
					onRowClick: (c) => navigate({
						to: "/cases/$id",
						params: { id: c.case_reference_id }
					}),
					emptyMessage: "No urgent cases requiring immediate intervention today.",
					emptyInstruction: "All open grievances are within acceptable SLA limits."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-[var(--color-rule)] pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-base font-semibold text-[var(--color-ink)]",
						children: "Workload by bureau"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-muted)] mt-0.5",
						children: "Jurisdictional distribution of active caseloads, overdue breach volumes, and determination rates."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					columns: [
						{
							key: "bureau",
							header: "Bureau",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "py-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-[var(--color-text-primary)] text-xs",
									children: b.bureau_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-[10px] text-[var(--color-text-muted)] ml-2",
									children: [
										"(",
										b.bureau_code,
										")"
									]
								})]
							})
						},
						{
							key: "active",
							header: "Open",
							align: "right",
							width: "80px",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-xs",
								children: b.active
							})
						},
						{
							key: "overdue",
							header: "Overdue",
							align: "right",
							width: "90px",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `tabular-nums text-xs ${b.overdue > 0 ? "text-[var(--sla-overdue-text)] font-semibold" : "text-[var(--color-text-muted)]"}`,
								children: b.overdue
							})
						},
						{
							key: "dueSoon",
							header: "Due soon",
							align: "right",
							width: "90px",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `tabular-nums text-xs ${b.dueSoon > 0 ? "text-[var(--sla-approaching-text)] font-semibold" : "text-[var(--color-text-muted)]"}`,
								children: b.dueSoon
							})
						},
						{
							key: "resolved",
							header: "Resolved",
							align: "right",
							width: "90px",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-xs",
								children: b.resolved
							})
						},
						{
							key: "rate",
							header: "Resolution rate",
							align: "right",
							width: "180px",
							cell: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-end gap-3 py-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-xs text-[var(--color-ink)] font-semibold",
									children: [b.completionPct, "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-24 h-2 bg-[var(--color-page)] border border-[var(--color-rule)] rounded-full overflow-hidden p-[1px]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-gradient-to-r from-[var(--color-action)] to-[#8E72D6] rounded-full transition-all duration-500",
										style: { width: `${b.completionPct}%` }
									})
								})]
							})
						}
					],
					data: bureauWorkloadData,
					keyField: (b) => b.bureau_id,
					isLoading: isStatsLoading,
					skeletonRows: 4,
					onRowClick: (b) => navigate({
						to: "/cases",
						search: { bureau_id: b.bureau_id }
					}),
					emptyMessage: "No bureau workload data found.",
					emptyInstruction: "Verify API connection or active bureau records."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: isCasesLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-56 w-full rounded-[6px]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DwellTimeChart, { cases: allCases }) })
		]
	});
}
var SplitComponent = DashboardView;
//#endregion
export { SplitComponent as component };
