import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { A as switchRole, k as setMockRole } from "./button-1CfnPKN-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RoleContext-C-ODmO0l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Role context — tracks the current demo user role across the app.
* Stored in React state (in-memory, resets on page refresh intentionally).
*/
var RoleContext = (0, import_react.createContext)(null);
var DEFAULT_ROLE = "SUPERVISOR";
var DEFAULT_USER = {
	id: "user-supervisor",
	email: "supervisor@aicte-demo.gov.in",
	full_name: "Dr. Ramesh Chandra",
	role: DEFAULT_ROLE,
	bureau_id: null,
	bureau_name: null,
	bureau_code: null,
	permissions: [
		"cases:read:all",
		"cases:assign",
		"cases:notes:create",
		"cases:notes:read:confidential",
		"cases:export",
		"dashboard:read:all",
		"audit:read:all"
	]
};
function RoleProvider({ children }) {
	const [role, setRole] = (0, import_react.useState)(DEFAULT_ROLE);
	const [user, setUser] = (0, import_react.useState)(DEFAULT_USER);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const useMocks = true;
	const changeRole = (0, import_react.useCallback)(async (newRole) => {
		setIsLoading(true);
		try {
			const newUser = await switchRole(newRole);
			setRole(newRole);
			setUser(newUser);
			setMockRole(newRole, newUser.bureau_id);
		} catch (err) {
			console.error("Failed to switch role:", err);
		} finally {
			setIsLoading(false);
		}
	}, [useMocks]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleContext.Provider, {
		value: {
			role,
			user,
			isLoading,
			changeRole,
			useMocks
		},
		children
	});
}
function useRole() {
	const ctx = (0, import_react.useContext)(RoleContext);
	if (!ctx) throw new Error("useRole must be used inside RoleProvider");
	return ctx;
}
//#endregion
export { useRole as n, RoleProvider as t };
