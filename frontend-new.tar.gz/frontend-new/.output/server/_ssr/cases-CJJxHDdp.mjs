import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { T as listCases, d as cn, i as Button, n as ALL_STATUSES, w as listBureaus } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { M as ChevronLeft, j as ChevronRight, l as Search, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-f_2O8qQw.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SlaPill, r as deriveSlaStatus, t as LifecycleStrip } from "./SlaPill-C7x6Ry1j.mjs";
import { t as StatusMark } from "./StatusMark-DJcf1lip.mjs";
import { t as PriorityMark } from "./PriorityMark-zbBOy4ZR.mjs";
import { t as formatIST } from "./dateUtils-C5EiSnMV.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
import { t as Route } from "./cases-Bxp6ZNBY.mjs";
import { t as DataTable } from "./DataTable-BiBJ9Tiy.mjs";
import { t as Input } from "./input-BlWpASKt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cases-CJJxHDdp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function CasePreviewDrawer({ caseItem, open, onOpenChange }) {
	if (!caseItem) return null;
	const isResolvedOrClosed = caseItem.status === "Resolved" || caseItem.status === "Closed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full sm:max-w-md bg-white/95 dark:bg-[#07050E]/95 backdrop-blur-xl border-l border-[#ECE6F4] dark:border-[#201533] rounded-l-[12px] shadow-[0_8px_32px_rgba(112,82,200,0.12)] p-6 flex flex-col justify-between overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
						className: "space-y-2 text-left p-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-[var(--color-text-secondary)]",
									children: caseItem.case_reference_id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: caseItem.priority }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusMark, { status: caseItem.status })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
								className: "font-serif text-lg font-semibold text-[var(--color-ink)] leading-snug pt-1",
								children: caseItem.subject
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, {
								className: "sr-only",
								children: ["Quick preview of case ", caseItem.case_reference_id]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlaPill, {
									dueDate: caseItem.due_date,
									isResolved: isResolvedOrClosed
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-[var(--color-rule)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "space-y-3.5 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[var(--color-text-muted)] text-[11px] mb-0.5",
									children: "Institution"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium text-[var(--color-text-primary)]",
									children: caseItem.institution_name
								}),
								caseItem.aicte_permanent_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-mono text-[10px] text-[var(--color-text-muted)]",
									children: ["Permanent ID: ", caseItem.aicte_permanent_id]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[var(--color-text-muted)] text-[11px] mb-0.5",
								children: "Bureau"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-[var(--color-text-primary)] font-medium",
								children: [
									caseItem.bureau_name,
									" (",
									caseItem.bureau_code,
									")"
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[var(--color-text-muted)] text-[11px] mb-0.5",
								children: "Category"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-[var(--color-text-primary)]",
								children: caseItem.category || "General Grievance"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[var(--color-text-muted)] text-[11px] mb-0.5",
								children: "Created date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono text-[var(--color-text-secondary)] tabular-nums",
								children: formatIST(caseItem.created_at)
							})] }),
							caseItem.assigned_officer_name && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[var(--color-text-muted)] text-[11px] mb-0.5",
								children: "Assigned officer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-[var(--color-text-primary)]",
								children: caseItem.assigned_officer_name
							})] })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-6 border-t border-[var(--color-rule)] mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "w-full bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 h-9 text-xs font-medium rounded-[6px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/cases/$id",
						params: { id: caseItem.case_reference_id },
						onClick: () => onOpenChange(false),
						children: "Open case file"
					})
				})
			})]
		})
	});
}
function exportCasesClientCsv(cases, userRole) {
	const isAuditor = userRole === "AUDITOR";
	const headers = [
		"Case Reference ID",
		"Institution AICTE ID",
		"Institution Name",
		"Bureau Code",
		"Bureau Name",
		"Category",
		"Priority",
		"Status",
		"Due Date (IST)",
		"Escalation Tier",
		"Created Date (IST)",
		"Subject",
		"Description (Redacted)",
		...isAuditor ? [] : ["Confidential Statement"],
		"Closure Remarks"
	];
	const rows = cases.map((c) => {
		const dueIST = c.due_date ? new Date(c.due_date).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) : "N/A";
		const createdIST = new Date(c.created_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
		return [
			c.case_reference_id,
			c.aicte_permanent_id || "",
			`"${(c.institution_name || "").replace(/"/g, "\"\"")}"`,
			c.bureau_code,
			`"${(c.bureau_name || "").replace(/"/g, "\"\"")}"`,
			c.category,
			c.priority,
			c.status,
			`"${dueIST}"`,
			c.escalation_level.toString(),
			`"${createdIST}"`,
			`"${(c.subject || "").replace(/"/g, "\"\"")}"`,
			`"${(c.description_redacted || "").replace(/"/g, "\"\"")}"`,
			...isAuditor ? [] : [`"${(c.description_confidential || "").replace(/"/g, "\"\"")}"`],
			`"${(c.closure_remarks || "").replace(/"/g, "\"\"")}"`
		].join(",");
	});
	const csvContent = [headers.join(","), ...rows].join("\r\n");
	const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, 19);
	link.setAttribute("href", url);
	link.setAttribute("download", `aicte_cases_export_${timestamp}.csv`);
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
	URL.revokeObjectURL(url);
}
function CaseRegister({ initialBureauId }) {
	const { role, user } = useRole();
	const canImport = user?.permissions.includes("cases:import") || role === "ADMIN";
	const [search, setSearch] = (0, import_react.useState)("");
	const [bureauFilter, setBureauFilter] = (0, import_react.useState)(initialBureauId ?? "ALL");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("ALL");
	const [priorityFilter, setPriorityFilter] = (0, import_react.useState)("ALL");
	const [slaFilter, setSlaFilter] = (0, import_react.useState)("ALL");
	const [page, setPage] = (0, import_react.useState)(1);
	const [pageSize, setPageSize] = (0, import_react.useState)(25);
	const [previewCase, setPreviewCase] = (0, import_react.useState)(null);
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	const { data: bureaus = [] } = useQuery({
		queryKey: ["bureaus"],
		queryFn: listBureaus,
		staleTime: 3e5
	});
	const queryParams = (0, import_react.useMemo)(() => {
		const params = {
			page,
			page_size: pageSize,
			search: search.trim() || void 0
		};
		if (bureauFilter !== "ALL") params.bureau_id = bureauFilter;
		if (statusFilter !== "ALL") params.status = statusFilter;
		if (priorityFilter !== "ALL") params.priority = priorityFilter;
		return params;
	}, [
		page,
		pageSize,
		search,
		bureauFilter,
		statusFilter,
		priorityFilter
	]);
	const { data: casesResponse, isLoading, isError, error, refetch } = useQuery({
		queryKey: [
			"cases",
			queryParams,
			role,
			user?.bureau_id
		],
		queryFn: () => listCases(queryParams),
		staleTime: 3e4
	});
	const displayedCases = (0, import_react.useMemo)(() => {
		if (!casesResponse?.items) return [];
		if (slaFilter === "ALL") return casesResponse.items;
		return casesResponse.items.filter((c) => {
			const isResolved = c.status === "Resolved" || c.status === "Closed";
			return deriveSlaStatus(c.due_date, isResolved).status === slaFilter;
		});
	}, [casesResponse?.items, slaFilter]);
	const hasActiveFilters = search.trim() !== "" || bureauFilter !== "ALL" || statusFilter !== "ALL" || priorityFilter !== "ALL" || slaFilter !== "ALL";
	const handleResetFilters = () => {
		setSearch("");
		setBureauFilter("ALL");
		setStatusFilter("ALL");
		setPriorityFilter("ALL");
		setSlaFilter("ALL");
		setPage(1);
	};
	const handleRowClick = (caseItem) => {
		setPreviewCase(caseItem);
		setDrawerOpen(true);
	};
	const handleExportCsv = () => {
		if (displayedCases.length > 0) exportCasesClientCsv(displayedCases, role);
	};
	const totalPages = casesResponse?.total_pages ?? 1;
	const totalCount = casesResponse?.total ?? 0;
	const startIndex = totalCount === 0 ? 0 : (page - 1) * pageSize + 1;
	const endIndex = Math.min(page * pageSize, totalCount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Case register",
				description: "Search, filter and open any case you are allowed to see.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: handleExportCsv,
						disabled: isLoading || displayedCases.length === 0,
						className: "h-8 px-3 text-xs font-medium border-[var(--color-rule)] bg-surface text-[var(--color-text-primary)] rounded-[6px]",
						children: "Export CSV"
					}), canImport && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "h-8 px-3 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/ingest",
							children: "Ingest CSV"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 py-3.5 border-y border-[var(--color-rule)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[220px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[var(--color-text-muted)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "text",
							placeholder: "Search reference ID, institution, subject...",
							value: search,
							onChange: (e) => {
								setSearch(e.target.value);
								setPage(1);
							},
							className: "pl-8 text-xs h-8 bg-surface border-[var(--color-rule)] rounded-[6px]"
						})]
					}),
					role !== "OFFICER" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: bureauFilter,
						onValueChange: (v) => {
							setBureauFilter(v);
							setPage(1);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8 w-[140px] text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All bureaus" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "ALL",
							children: "All bureaus"
						}), bureaus.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: b.id,
							children: [
								b.code,
								" (",
								b.name.split(" ")[0],
								")"
							]
						}, b.id))] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: statusFilter,
						onValueChange: (v) => {
							setStatusFilter(v);
							setPage(1);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8 w-[140px] text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All statuses" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "ALL",
							children: "All statuses"
						}), ALL_STATUSES.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: st,
							children: st
						}, st))] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: priorityFilter,
						onValueChange: (v) => {
							setPriorityFilter(v);
							setPage(1);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8 w-[130px] text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All priorities" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "ALL",
								children: "All priorities"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "LOW",
								children: "Low"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "MEDIUM",
								children: "Medium"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "HIGH",
								children: "High"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "URGENT",
								children: "Urgent"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: slaFilter,
						onValueChange: (v) => {
							setSlaFilter(v);
							setPage(1);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-8 w-[130px] text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All SLA" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "ALL",
								children: "All SLA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "OVERDUE",
								children: "Overdue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "APPROACHING",
								children: "Approaching"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "ON_TRACK",
								children: "On track"
							})
						] })]
					}),
					hasActiveFilters && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: handleResetFilters,
						className: "h-8 px-2 text-xs text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] hover:bg-transparent",
						children: "Clear filters"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				columns: [
					{
						key: "case_reference_id",
						header: "Case",
						width: "140px",
						cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-[var(--color-text-secondary)]",
							children: c.case_reference_id
						})
					},
					{
						key: "institution_name",
						header: "Institution",
						cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium text-[var(--color-text-primary)] text-xs line-clamp-1",
							children: c.institution_name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-[10px] text-[var(--color-text-muted)]",
							children: c.aicte_permanent_id ? c.aicte_permanent_id : "—"
						})] })
					},
					{
						key: "bureau",
						header: "Bureau",
						width: "100px",
						cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-[var(--color-text-secondary)]",
							title: c.bureau_name,
							children: c.bureau_code
						})
					},
					{
						key: "stage",
						header: "Stage",
						width: "220px",
						cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifecycleStrip, {
								currentStatus: c.status,
								variant: "compact"
							})
						})
					},
					{
						key: "priority",
						header: "Priority",
						width: "110px",
						cell: (c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: c.priority })
					},
					{
						key: "due",
						header: "Due",
						width: "150px",
						align: "right",
						cell: (c) => {
							const isResolved = c.status === "Resolved" || c.status === "Closed";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlaPill, {
								dueDate: c.due_date,
								isResolved
							});
						}
					}
				],
				data: displayedCases,
				keyField: (c) => c.id,
				onRowClick: handleRowClick,
				isLoading,
				skeletonRows: pageSize > 10 ? 10 : pageSize,
				emptyMessage: "No complaint cases match your criteria.",
				emptyInstruction: "Try clearing filters or adjusting your search parameters.",
				emptyAction: hasActiveFilters ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: handleResetFilters,
					className: "h-7 text-xs border-[var(--color-rule)]",
					children: "Clear filters"
				}) : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-center justify-between gap-3 py-2 text-xs text-[var(--color-text-secondary)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[var(--color-text-muted)]",
							children: "Rows per page:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: String(pageSize),
							onValueChange: (val) => {
								setPageSize(Number(val));
								setPage(1);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-7 w-16 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "10",
									children: "10"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "25",
									children: "25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "50",
									children: "50"
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								"Showing ",
								startIndex,
								" to ",
								endIndex,
								" of ",
								totalCount
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-7 px-2.5 text-xs border-[var(--color-rule)] bg-surface rounded-[6px]",
							disabled: page <= 1 || isLoading,
							onClick: () => setPage((p) => Math.max(1, p - 1)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-3.5 w-3.5 mr-1" }), "Previous"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums px-1 text-[var(--color-text-muted)]",
							children: [
								"Page ",
								page,
								" of ",
								totalPages
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-7 px-2.5 text-xs border-[var(--color-rule)] bg-surface rounded-[6px]",
							disabled: page >= totalPages || isLoading,
							onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
							children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 ml-1" })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CasePreviewDrawer, {
				caseItem: previewCase,
				open: drawerOpen,
				onOpenChange: setDrawerOpen
			})
		]
	});
}
function CasesRoute() {
	const { bureau_id } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseRegister, { initialBureauId: bureau_id })
	});
}
//#endregion
export { CasesRoute as component };
