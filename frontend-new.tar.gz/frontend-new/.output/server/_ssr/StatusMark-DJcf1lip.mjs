import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn } from "./button-1CfnPKN-.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var STATUS_SQUARE_COLORS = {
	Received: "#727B8E",
	Registered: "#4972A8",
	"Under Triage": "#7A57C1",
	Assigned: "#368199",
	"In Progress": "#7052C8",
	"Awaiting Information": "#9E6E1D",
	"Under Review": "#974E79",
	Resolved: "#257D4E",
	Closed: "#625A70"
};
function StatusMark({ status, className }) {
	const squareColor = STATUS_SQUARE_COLORS[status] ?? "#727B8E";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 text-xs font-medium text-text-primary whitespace-nowrap", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "h-2 w-2 rounded-[2px] shrink-0 inline-block",
			style: { backgroundColor: squareColor },
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: status })]
	});
}
//#endregion
export { StatusMark as t };
