//#region node_modules/.nitro/vite/services/ssr/assets/dateUtils-C5EiSnMV.js
/**
* IST date formatting utilities.
* All user-facing timestamps in the dashboard must be in Indian Standard Time (IST, UTC+5:30).
*/
function formatIST(dateStr, options) {
	if (!dateStr) return "—";
	const date = new Date(dateStr);
	if (isNaN(date.getTime())) return "—";
	const includeTime = options?.includeTime ?? true;
	return new Intl.DateTimeFormat("en-IN", {
		timeZone: "Asia/Kolkata",
		day: "numeric",
		month: "short",
		year: "numeric",
		...includeTime ? {
			hour: "2-digit",
			minute: "2-digit",
			hour12: true
		} : {}
	}).format(date);
}
//#endregion
export { formatIST as t };
