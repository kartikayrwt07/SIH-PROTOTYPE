import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { D as previewCsv, f as commitCsv, i as Button } from "./button-1CfnPKN-.mjs";
import { n as useRole } from "./RoleContext-C-ODmO0l.mjs";
import { P as Check, T as CloudUpload } from "../_libs/lucide-react.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./PageHeader-CaCLLolb.mjs";
import { t as EmptyState } from "./EmptyState-BUPzGk3F.mjs";
import { t as DataTable } from "./DataTable-BiBJ9Tiy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ingest-CWK3oJih.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* 14-row dataset: 12 valid rows across APPR, STU, FDC, FIN + 2 invalid rows.
* Exactly matches SPEC §6: '12 valid, 2 invalid'.
*/
var SAMPLE_CSV_CONTENT = `institution_aicte_id,bureau_code,subject,category,priority,description,is_confidential
1-3324561,APPR,Shortage of accredited laboratories in Mechanical Dept,Approval Compliance,HIGH,Laboratories non-functional during current academic session,false
1-4521890,STU,Severe hostel ragging incident in boys wing,Student Grievance,URGENT,First-year students harassed by senior hostel residents without warden intervention,true
1-2893421,FDC,7th CPC pay commission arrears withheld for 8 months,Faculty Grievance,HIGH,Management refused revision of AICTE approved scales for assistant professors,false
2-7654321,FIN,Excess capitation fee demanded at time of counseling,Fee Regulation,MEDIUM,College collected 1.2 lakhs additional caution deposit with no receipt,false
1-5643210,APPR,Enrolled students exceed approved intake capacity,Approval Compliance,HIGH,Intake approved for 60 students but college admitted 110 students,false
1-8765432,STU,Substandard hostel food and contaminated drinking water,Student Grievance,MEDIUM,Mess facilities unhygienic with repeated food poisoning complaints,false
2-3456789,FDC,Unlawful termination of assistant professor without notice,Faculty Grievance,HIGH,Faculty terminated mid-semester without statutory inquiry committee,true
1-6789012,FIN,Withholding original 12th marksheets after withdrawal,Fee Regulation,HIGH,College refuses to return academic certificates after student took admission elsewhere,false
1-9876543,APPR,Deficient land and building built-up area for engineering college,Approval Compliance,MEDIUM,Physical infrastructure short by 2400 sq meters per AICTE handbook norms,false
2-1234567,STU,Lack of internal complaints committee for student safety,Student Grievance,HIGH,No mandatory POSH committee established on campus,true
1-7654321,FDC,Non-payment of provident fund contributions to EPFO,Faculty Grievance,MEDIUM,PF deductions made from faculty salary but not deposited for 11 months,false
1-4567890,FIN,Mandatory donation demand for hostel room allotment,Fee Regulation,LOW,Hostel warden requiring extra cash payment for single room allotment,false
INVALID-999,APPR,Invalid AICTE permanent ID format demonstration,Approval Compliance,HIGH,This row intentionally has an invalid AICTE ID format to test validation,false
2-8901234,UNKNOWN_BUR,Unknown bureau code demonstration,General,LOW,This row intentionally has an unknown bureau code to test error flagging,false`;
/** Download the sample CSV template directly to the user's browser */
function downloadSampleCsv() {
	const blob = new Blob([SAMPLE_CSV_CONTENT], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.setAttribute("href", url);
	link.setAttribute("download", "aicte_complaint_intake_template.csv");
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
	URL.revokeObjectURL(url);
}
function CsvIngestView() {
	const queryClient = useQueryClient();
	const { role } = useRole();
	const fileInputRef = (0, import_react.useRef)(null);
	const isAdmin = role === "ADMIN";
	const [step, setStep] = (0, import_react.useState)(1);
	const [csvContent, setCsvContent] = (0, import_react.useState)("");
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [previewData, setPreviewData] = (0, import_react.useState)(null);
	const [commitResult, setCommitResult] = (0, import_react.useState)(null);
	const previewMutation = useMutation({
		mutationFn: (content) => previewCsv(content),
		onSuccess: (data) => {
			setPreviewData(data);
			setStep(2);
		},
		onError: (err) => {
			toast.error(err?.message || "Failed to validate CSV file.");
		}
	});
	const commitMutation = useMutation({
		mutationFn: (rows) => commitCsv(rows),
		onSuccess: (data) => {
			setCommitResult(data);
			setStep(3);
			queryClient.invalidateQueries({ queryKey: ["cases"] });
			queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
			queryClient.invalidateQueries({ queryKey: ["slaRadar"] });
			toast.success("Cases registered");
		},
		onError: (err) => {
			toast.error(err?.message || "Failed to commit valid rows.");
		}
	});
	const handleFileChange = (file) => {
		setFileName(file.name);
		const reader = new FileReader();
		reader.onload = (e) => {
			const text = e.target?.result || "";
			setCsvContent(text);
			previewMutation.mutate(text);
		};
		reader.readAsText(file);
	};
	const handleDrop = (e) => {
		e.preventDefault();
		if (e.dataTransfer.files && e.dataTransfer.files.length > 0) handleFileChange(e.dataTransfer.files[0]);
	};
	const handleLoadSample = () => {
		setFileName("aicte_sample_demo_14rows.csv");
		setCsvContent(SAMPLE_CSV_CONTENT);
		previewMutation.mutate(SAMPLE_CSV_CONTENT);
	};
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-12 px-6 max-w-xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "CSV ingestion is restricted to administrators.",
			instruction: "Contact your supervisor for access."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "CSV ingestion",
				description: "Bulk upload complaint cases from institutional registers."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-6 py-2.5 border-b border-[var(--color-rule)] text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => step > 1 && setStep(1),
						className: `flex items-center gap-1.5 ${step === 1 ? "font-semibold text-[var(--color-ink)]" : step > 1 ? "text-[var(--color-text-secondary)] cursor-pointer" : "text-[var(--color-text-muted)]"}`,
						children: [step > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-[var(--sla-on-track-text)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1. Upload" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[var(--color-rule)]",
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => step > 2 && setStep(2),
						className: `flex items-center gap-1.5 ${step === 2 ? "font-semibold text-[var(--color-ink)]" : step > 2 ? "text-[var(--color-text-secondary)] cursor-pointer" : "text-[var(--color-text-muted)]"}`,
						children: [step > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5 text-[var(--sla-on-track-text)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2. Review" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[var(--color-rule)]",
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `flex items-center gap-1.5 ${step === 3 ? "font-semibold text-[var(--color-ink)]" : "text-[var(--color-text-muted)]"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "3. Commit" })
					})
				]
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 max-w-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onDragOver: (e) => e.preventDefault(),
					onDrop: handleDrop,
					onClick: () => fileInputRef.current?.click(),
					className: "border-2 border-dashed border-[var(--color-rule)] hover:border-[var(--color-action)] bg-surface rounded-[4px] p-10 text-center cursor-pointer transition-colors space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "h-8 w-8 text-[var(--color-text-muted)] mx-auto" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-sm font-semibold text-[var(--color-ink)]",
							children: "Drop a CSV file here or click to browse"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-[var(--color-text-muted)]",
							children: "Supports UTF-8 formatted CSV files up to 10MB"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileInputRef,
							type: "file",
							accept: ".csv,text/csv",
							onChange: (e) => {
								if (e.target.files && e.target.files[0]) handleFileChange(e.target.files[0]);
							},
							className: "hidden"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[var(--color-text-secondary)] border-t border-[var(--color-rule)] pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-[var(--color-text-primary)] block mb-0.5",
						children: "Expected columns:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-[11px] text-[var(--color-text-muted)]",
						children: "institution_aicte_id, institution_name, bureau_code, category, priority, subject, description"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: downloadSampleCsv,
							className: "text-xs text-[var(--color-action)] hover:underline",
							children: "Download template CSV"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: handleLoadSample,
							className: "text-xs text-[var(--color-text-primary)] hover:underline border border-[var(--color-rule)] px-2.5 py-1 rounded-[4px] bg-surface",
							children: "Load sample dataset"
						})]
					})]
				})]
			}),
			step === 2 && previewData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-[var(--color-text-secondary)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-[var(--sla-on-track-text)] tabular-nums",
								children: [previewData.valid_rows, " valid rows"]
							}),
							",",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-[var(--sla-overdue-text)] tabular-nums",
								children: [previewData.invalid_rows, " rows with errors"]
							}),
							"."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setStep(1),
							className: "h-8 text-xs border-[var(--color-rule)] rounded-[6px]",
							children: "Back to upload"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => commitMutation.mutate(previewData.rows),
							disabled: commitMutation.isPending || previewData.valid_rows === 0,
							className: "h-8 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
							children: commitMutation.isPending ? "Committing..." : "Commit valid rows"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					columns: [
						{
							key: "row_number",
							header: "Row #",
							width: "60px",
							align: "right",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-xs",
								children: r.row_number
							})
						},
						{
							key: "status",
							header: "Status",
							width: "180px",
							cell: (r) => r.is_valid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-[var(--sla-on-track-text)]",
								children: "Valid"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[var(--sla-overdue-text)]",
								children: r.errors.map((e) => e.message).join("; ")
							})
						},
						{
							key: "reference",
							header: "Reference",
							width: "120px",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-[var(--color-text-secondary)]",
								children: r.institution_aicte_id
							})
						},
						{
							key: "institution",
							header: "Institution",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-[var(--color-text-primary)] line-clamp-1",
								children: r.institution_name
							})
						},
						{
							key: "bureau",
							header: "Bureau",
							width: "80px",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[var(--color-text-secondary)]",
								children: r.bureau_code
							})
						},
						{
							key: "category",
							header: "Category",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[var(--color-text-secondary)] line-clamp-1",
								children: r.category
							})
						},
						{
							key: "priority",
							header: "Priority",
							width: "90px",
							cell: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[var(--color-text-secondary)]",
								children: r.priority
							})
						}
					],
					data: previewData.rows,
					keyField: (r) => r.row_number,
					rowClassName: (r) => !r.is_valid ? "!bg-[#FDECEC]" : ""
				})]
			}),
			step === 3 && commitResult && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6 max-w-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 bg-surface border border-[var(--color-rule)] rounded-[4px] space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-[var(--sla-on-track-text)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-serif text-base font-semibold text-[var(--color-ink)]",
								children: [commitResult.imported_count, " cases registered successfully"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-[var(--color-text-secondary)]",
							children: "Official reference IDs have been allocated and initialised at the Received stage."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-[var(--color-text-muted)] font-medium",
								children: "Allocated reference IDs:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-h-48 overflow-y-auto p-3 bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[4px] space-y-1",
								children: commitResult.created_case_references.map((ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs text-[var(--color-text-secondary)]",
									children: ref
								}, ref))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "h-8 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/cases",
									children: "Open case register"
								})
							})
						})
					]
				})
			})
		]
	});
}
var SplitComponent = CsvIngestView;
//#endregion
export { SplitComponent as component };
