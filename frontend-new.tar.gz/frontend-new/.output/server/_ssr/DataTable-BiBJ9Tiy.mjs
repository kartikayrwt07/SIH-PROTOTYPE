import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { d as cn } from "./button-1CfnPKN-.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function DataTable({ columns, data, keyField, onRowClick, isLoading = false, skeletonRows = 5, emptyMessage = "No records found.", emptyInstruction = "Try clearing filters or adjusting your search.", emptyAction, rowClassName, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("w-full bg-white/85 dark:bg-[#0B0813]/90 backdrop-blur-md border border-[#ECE6F4] dark:border-[#201533] rounded-[10px] overflow-hidden shadow-[0_4px_24px_rgba(112,82,200,0.03)]", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "sticky top-0 bg-white/90 dark:bg-[#07050E]/95 backdrop-blur-md border-b border-[#ECE6F4] dark:border-[#201533] z-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						style: { width: col.width },
						className: cn("h-10.5 px-4.5 py-2.5 text-xs font-semibold text-text-secondary select-none", col.align === "right" ? "text-right tabular-nums" : col.align === "center" ? "text-center" : "text-left", col.className),
						children: col.header
					}, col.key)) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y divide-[#ECE6F4] dark:divide-[#201533]",
					children: isLoading ? Array.from({ length: skeletonRows }).map((_, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "h-12 bg-surface",
						children: columns.map((col, cIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: cn("px-4.5 py-3.5", col.align === "right" ? "text-right" : "text-left"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-3.5 bg-rule/50 rounded-[2px] animate-pulse", col.align === "right" ? "ml-auto w-12" : "w-3/4") })
						}, `skel-c-${cIdx}`))
					}, `skel-${rIdx}`)) : data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: columns.length,
						className: "px-4 py-14 text-center text-sm text-text-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-sm mx-auto space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-serif text-base font-semibold text-ink",
									children: emptyMessage
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-text-muted",
									children: emptyInstruction
								}),
								emptyAction && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2",
									children: emptyAction
								})
							]
						})
					}) }) : data.map((item, idx) => {
						const isClickable = !!onRowClick;
						const customClasses = rowClassName ? rowClassName(item) : "";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							onClick: () => onRowClick?.(item),
							onKeyDown: (e) => {
								if (isClickable && (e.key === "Enter" || e.key === " ")) {
									e.preventDefault();
									onRowClick(item);
								}
							},
							tabIndex: isClickable ? 0 : void 0,
							role: isClickable ? "button" : void 0,
							className: cn("min-h-[46px] bg-surface dark:bg-[#0B0813] text-ink dark:text-[#F2EEFA] transition-colors", isClickable && "cursor-pointer hover:bg-[#FAF8FE] dark:hover:bg-[#9333EA]/10 focus:outline-none focus:bg-[#FAF8FE] dark:focus:bg-[#9333EA]/10 focus:ring-1 focus:ring-action", customClasses),
							children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: cn("px-4.5 py-3.5 text-xs", col.align === "right" ? "text-right tabular-nums" : col.align === "center" ? "text-center" : "text-left", col.className),
								children: col.cell(item, idx)
							}, col.key))
						}, keyField(item));
					})
				})]
			})
		})
	});
}
//#endregion
export { DataTable as t };
