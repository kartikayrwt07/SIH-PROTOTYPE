import { n as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { n as CheckboxIndicator, p as require_jsx_runtime, t as Checkbox$1 } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { E as listOfficers, _ as getCase, c as assignCase, d as cn, h as getAssignmentHistory, i as Button, j as transitionCase, m as getAllowedTransitions, o as addNote, r as AUDIT_EVENT_LABELS, w as listBureaus, x as getTimeline, y as getNotes } from "./_ssr/button-1CfnPKN-.mjs";
import { n as useRole } from "./_ssr/RoleContext-C-ODmO0l.mjs";
import { M as ChevronLeft, N as ChevronDown, P as Check, h as Lock, j as ChevronRight, k as CircleAlert } from "./_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-f_2O8qQw.mjs";
import { x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./_id-VuBbPgMI.mjs";
import { n as SlaPill, t as LifecycleStrip } from "./_ssr/SlaPill-C7x6Ry1j.mjs";
import { t as StatusMark } from "./_ssr/StatusMark-DJcf1lip.mjs";
import { t as PriorityMark } from "./_ssr/PriorityMark-zbBOy4ZR.mjs";
import { t as Textarea } from "./_ssr/textarea-BhA-x7XG.mjs";
import { t as Label } from "./_ssr/label-DOLtOnoa.mjs";
import { t as formatIST } from "./_ssr/dateUtils-C5EiSnMV.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CmbVgpgQ.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as EscalateModal, t as Dialog } from "./_ssr/EscalateModal-BBWFsjKk.mjs";
import { i as TabsTrigger$1, n as TabsContent$1, r as TabsList$1, t as Tabs$1 } from "./_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-CAXM5J0y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RedactionBar({ className, lines = 3 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("border border-rule bg-page p-4 rounded space-y-3 select-none", className),
		role: "region",
		"aria-label": "Redacted confidential content",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs font-medium text-text-secondary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
				className: "h-3.5 w-3.5 text-ink shrink-0",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confidential statement redacted under the data governance policy" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2 pt-1",
			"aria-hidden": "true",
			children: Array.from({ length: lines }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-3 bg-ink rounded-[1px]", i === lines - 1 ? "w-2/3" : "w-full") }, i))
		})]
	});
}
var STATUS_COLOR_VARS = {
	Received: "var(--status-received)",
	Registered: "var(--status-registered)",
	"Under Triage": "var(--status-under-triage)",
	Assigned: "var(--status-assigned)",
	"In Progress": "var(--status-in-progress)",
	"Awaiting Information": "var(--status-awaiting-information)",
	"Under Review": "var(--status-under-review)",
	Resolved: "var(--status-resolved)",
	Closed: "var(--status-closed)"
};
function AuditTimelineTab({ caseRef }) {
	const [expandedMeta, setExpandedMeta] = (0, import_react.useState)({});
	const { data: timeline = [], isLoading, isError, error, refetch } = useQuery({
		queryKey: ["timeline", caseRef],
		queryFn: () => getTimeline(caseRef),
		staleTime: 3e4
	});
	const toggleMeta = (id) => {
		setExpandedMeta((prev) => ({
			...prev,
			[id]: !prev[id]
		}));
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4 py-4",
		children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-3 rounded-[2px] mt-1 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-44" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-64" })]
			})]
		}, i))
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 text-xs text-[var(--sla-overdue-text)] space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Failed to retrieve audit trail: ", error?.message || "Unknown error"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => refetch(),
			className: "text-xs h-7 border-[var(--color-rule)]",
			children: "Try again"
		})]
	});
	if (timeline.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-8 text-xs text-[var(--color-text-secondary)] space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium text-[var(--color-text-primary)]",
			children: "No timeline records found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "State advancements, assignments, and audit events will appear here in chronological sequence." })]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-2 space-y-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative pl-7 space-y-7 before:absolute before:left-[5px] before:top-2 before:bottom-2 before:w-[1px] before:bg-[var(--color-rule)]",
			children: timeline.map((entry) => {
				const statusKey = entry.new_state || entry.previous_state;
				const markerColor = statusKey ? STATUS_COLOR_VARS[statusKey] || "var(--color-text-muted)" : "var(--color-text-muted)";
				const eventLabel = AUDIT_EVENT_LABELS[entry.event_type] || entry.event_type;
				const hasMeta = entry.metadata && Object.keys(entry.metadata).length > 0;
				const isMetaOpen = !!expandedMeta[entry.id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative group text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -left-[27px] top-1 w-2.5 h-2.5 rounded-[2px] ring-2 ring-[var(--color-surface)] shadow-xs",
						style: { backgroundColor: markerColor }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-[var(--color-ink)]",
										children: eventLabel
									}), entry.actor_role && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-[var(--color-text-muted)]",
										children: ["by ", entry.actor_name || entry.actor_role]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
									className: "font-mono text-[11px] text-[var(--color-text-muted)] tabular-nums",
									children: formatIST(entry.timestamp)
								})]
							}),
							(entry.previous_state || entry.new_state) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-[var(--color-text-secondary)]",
								children: [entry.previous_state && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [entry.previous_state, " → "] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-[var(--color-text-primary)]",
									children: entry.new_state
								})]
							}),
							entry.remark && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-[var(--color-text-secondary)] leading-relaxed max-w-3xl",
								children: entry.remark
							}),
							hasMeta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => toggleMeta(entry.id),
									className: "text-[10px] text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] inline-flex items-center gap-0.5",
									children: [isMetaOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isMetaOpen ? "Hide metadata" : "View metadata" })]
								}), isMetaOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "mt-1.5 p-3 bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[4px] font-mono text-[10px] text-[var(--color-text-secondary)] overflow-x-auto max-w-3xl",
									children: JSON.stringify(entry.metadata, null, 2)
								})]
							})
						]
					})]
				}, entry.id);
			})
		})
	});
}
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
function InternalNotesTab({ caseRef }) {
	const queryClient = useQueryClient();
	const { role } = useRole();
	const isAuditor = role === "AUDITOR";
	const [content, setContent] = (0, import_react.useState)("");
	const [isConfidential, setIsConfidential] = (0, import_react.useState)(false);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const { data: notes = [], isLoading, isError, error, refetch } = useQuery({
		queryKey: [
			"notes",
			caseRef,
			role
		],
		queryFn: () => getNotes(caseRef),
		staleTime: 3e4
	});
	const mutation = useMutation({
		mutationFn: addNote,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["notes", caseRef] });
			queryClient.invalidateQueries({ queryKey: ["timeline", caseRef] });
			toast.success("Note added");
			setContent("");
			setIsConfidential(false);
			setFormError(null);
		},
		onError: (err) => {
			setFormError(err?.message || "Failed to record case note.");
		}
	});
	const handleAddNote = (e) => {
		e.preventDefault();
		if (!content.trim() || content.trim().length < 2) {
			setFormError("Note content must be at least 2 characters.");
			return;
		}
		setFormError(null);
		mutation.mutate({
			case_ref: caseRef,
			content: content.trim(),
			is_confidential: isConfidential
		});
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 py-4",
		children: Array.from({ length: 2 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-32" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
		}, i))
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 text-xs text-[var(--sla-overdue-text)] space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Failed to retrieve notes: ", error?.message || "Unknown error"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => refetch(),
			className: "text-xs h-7 border-[var(--color-rule)]",
			children: "Try again"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-6 text-xs text-[var(--color-text-secondary)] space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-[var(--color-text-primary)]",
					children: "No notes recorded yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Internal case notes added by officers will appear here in chronological sequence." })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-[var(--color-rule)]",
				children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-4 first:pt-0 last:pb-1 space-y-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-[var(--color-ink)]",
								children: note.author_name || note.author_role || "Officer"
							}), note.is_confidential && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-[11px] text-[var(--color-text-muted)] font-normal bg-[var(--color-page)] px-1.5 py-0.5 rounded border border-[var(--color-rule)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3 w-3" }), " Confidential"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
							className: "font-mono text-[11px] text-[var(--color-text-muted)] tabular-nums",
							children: formatIST(note.created_at)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--color-text-primary)] leading-relaxed whitespace-pre-wrap max-w-3xl",
						children: note.content
					})]
				}, note.id))
			})
		}), !isAuditor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleAddNote,
			className: "pt-6 border-t border-[var(--color-rule)] space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "note-content",
						className: "text-xs font-semibold text-[var(--color-ink)] block",
						children: "Add note"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "note-content",
						placeholder: "Record inquiry findings, hearing notes, or case updates...",
						value: content,
						onChange: (e) => {
							setContent(e.target.value);
							if (formError) setFormError(null);
						},
						rows: 4,
						className: "text-xs bg-surface border-[var(--color-rule)] rounded-[6px] focus-visible:ring-1 focus-visible:ring-[var(--color-action)] leading-relaxed p-3 max-w-3xl"
					}),
					formError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-[var(--sla-overdue-text)] font-medium",
						children: formError
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4 pt-1 max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						id: "confidential",
						checked: isConfidential,
						onCheckedChange: (checked) => setIsConfidential(!!checked)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "confidential",
						className: "text-xs text-[var(--color-text-secondary)] font-normal cursor-pointer select-none",
						children: "Mark as confidential (hidden from Auditor)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "sm",
					disabled: mutation.isPending || !content.trim(),
					className: "h-8 px-4 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
					children: mutation.isPending ? "Saving..." : "Save note"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pt-6 border-t border-[var(--color-rule)] text-xs text-[var(--color-text-muted)]",
			children: "Note addition is disabled for the Auditor role."
		})]
	});
}
function AssignmentHistoryTab({ caseRef }) {
	const { data: history = [], isLoading, isError, error, refetch } = useQuery({
		queryKey: ["history", caseRef],
		queryFn: () => getAssignmentHistory(caseRef),
		staleTime: 3e4
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 py-4",
		children: Array.from({ length: 2 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full rounded-[4px]" }, i))
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 text-xs text-[var(--sla-overdue-text)] space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Failed to retrieve assignment history: ", error?.message || "Unknown error"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => refetch(),
			className: "text-xs h-7 border-[var(--color-rule)]",
			children: "Try again"
		})]
	});
	if (history.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-8 text-xs text-[var(--color-text-secondary)] space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium text-[var(--color-text-primary)]",
			children: "No jurisdiction transfers recorded"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Case remains assigned to its initial intake bureau allocation." })]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-2 overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-xs border-collapse",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-[var(--color-rule)] text-[var(--color-text-muted)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2.5 pr-4 font-medium",
						children: "From"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2.5 px-4 font-medium",
						children: "To"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2.5 px-4 font-medium",
						children: "Transfer justification"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2.5 px-4 font-medium",
						children: "Assigned by"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2.5 pl-4 text-right font-medium",
						children: "Date"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
				className: "divide-y divide-[var(--color-rule)]",
				children: history.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-[var(--color-text-primary)] hover:bg-[var(--color-page)] transition-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 pr-4 text-[var(--color-text-secondary)]",
							children: entry.from_bureau_name || "Initial Intake"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 px-4 font-medium",
							children: entry.to_bureau_name || entry.to_bureau_id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 px-4 text-[var(--color-text-secondary)] max-w-xs leading-relaxed",
							children: entry.transfer_reason
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 px-4 text-[var(--color-text-secondary)]",
							children: entry.assigned_by_name || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 pl-4 text-right font-mono text-[11px] text-[var(--color-text-muted)] tabular-nums whitespace-nowrap",
							children: formatIST(entry.created_at)
						})
					]
				}, entry.id))
			})]
		})
	});
}
function ChangeStatusModal({ caseItem, open, onOpenChange, initialTargetStatus }) {
	const queryClient = useQueryClient();
	const allowedNext = getAllowedTransitions(caseItem.status);
	const [toStatus, setToStatus] = (0, import_react.useState)(initialTargetStatus && allowedNext.includes(initialTargetStatus) ? initialTargetStatus : allowedNext.length > 0 ? allowedNext[0] : "");
	const [remarks, setRemarks] = (0, import_react.useState)("");
	const [validationError, setValidationError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (open) {
			const valid = getAllowedTransitions(caseItem.status);
			if (initialTargetStatus && valid.includes(initialTargetStatus)) setToStatus(initialTargetStatus);
			else if (valid.length > 0) setToStatus(valid[0]);
			else setToStatus("");
			setRemarks("");
			setValidationError(null);
		}
	}, [
		open,
		caseItem.status,
		initialTargetStatus
	]);
	const mutation = useMutation({
		mutationFn: transitionCase,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["case", caseItem.case_reference_id] });
			queryClient.invalidateQueries({ queryKey: ["cases"] });
			queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
			queryClient.invalidateQueries({ queryKey: ["timeline", caseItem.case_reference_id] });
			toast.success("Status changed");
			setRemarks("");
			setValidationError(null);
			onOpenChange(false);
		},
		onError: (err) => {
			setValidationError(err?.message || "Failed to change status.");
		}
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!toStatus) {
			setValidationError("Please select a target status.");
			return;
		}
		if (!remarks.trim() || remarks.trim().length < 3) {
			setValidationError("Remarks must be at least 3 characters.");
			return;
		}
		setValidationError(null);
		mutation.mutate({
			case_ref: caseItem.case_reference_id,
			to_status: toStatus,
			remarks: remarks.trim()
		});
	};
	const modalTitle = toStatus ? `Change status to ${toStatus}` : "Change status";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "sm:max-w-md bg-[var(--color-surface)] border border-[var(--color-rule)] rounded-[8px] p-6 shadow-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
						className: "p-0 text-left space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-serif text-base font-semibold text-[var(--color-ink)]",
							children: modalTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-xs text-[var(--color-text-secondary)]",
							children: [
								"Case ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[var(--color-text-primary)]",
									children: caseItem.case_reference_id
								}),
								" is currently at stage",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-[var(--color-text-primary)]",
									children: caseItem.status
								}),
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-medium text-[var(--color-text-primary)]",
							children: "Next stage"
						}), allowedNext.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-[var(--color-text-muted)]",
							children: [
								"No further valid stage transitions available from ",
								caseItem.status,
								"."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: toStatus,
							onValueChange: (val) => {
								setToStatus(val);
								setValidationError(null);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-8 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select target status" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: allowedNext.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: st,
								className: "text-xs",
								children: st
							}, st)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "status-remarks",
									className: "text-xs font-medium text-[var(--color-text-primary)]",
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-[var(--color-text-muted)]",
									children: "Required for the audit trail"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "status-remarks",
								placeholder: "State the justification or procedural basis for this status change...",
								value: remarks,
								onChange: (e) => {
									setRemarks(e.target.value);
									if (validationError) setValidationError(null);
								},
								rows: 3,
								className: "text-xs bg-surface border-[var(--color-rule)] rounded-[6px]"
							}),
							validationError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-[var(--sla-overdue-text)]",
								children: validationError
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "pt-2 border-t border-[var(--color-rule)] gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => onOpenChange(false),
							className: "h-8 text-xs border-[var(--color-rule)] rounded-[6px]",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							disabled: mutation.isPending || !toStatus || allowedNext.length === 0,
							className: "h-8 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
							children: mutation.isPending ? "Updating..." : "Change status"
						})]
					})
				]
			})
		})
	});
}
function ReassignModal({ caseItem, open, onOpenChange }) {
	const queryClient = useQueryClient();
	const [toBureauId, setToBureauId] = (0, import_react.useState)(caseItem.bureau_id);
	const [toOfficerId, setToOfficerId] = (0, import_react.useState)(caseItem.assigned_officer_id ?? "");
	const [reason, setReason] = (0, import_react.useState)("");
	const [validationError, setValidationError] = (0, import_react.useState)(null);
	const { data: bureaus = [] } = useQuery({
		queryKey: ["bureaus"],
		queryFn: listBureaus,
		staleTime: 3e5
	});
	const { data: officers = [], isLoading: isOfficersLoading } = useQuery({
		queryKey: ["officers", toBureauId],
		queryFn: () => listOfficers(toBureauId),
		enabled: !!toBureauId,
		staleTime: 6e4
	});
	(0, import_react.useEffect)(() => {
		if (caseItem && open) {
			setToBureauId(caseItem.bureau_id);
			setToOfficerId(caseItem.assigned_officer_id ?? "");
			setReason("");
			setValidationError(null);
		}
	}, [caseItem, open]);
	const mutation = useMutation({
		mutationFn: assignCase,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["case", caseItem.case_reference_id] });
			queryClient.invalidateQueries({ queryKey: ["cases"] });
			queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
			queryClient.invalidateQueries({ queryKey: ["history", caseItem.case_reference_id] });
			queryClient.invalidateQueries({ queryKey: ["timeline", caseItem.case_reference_id] });
			toast.success("Case reassigned");
			setReason("");
			onOpenChange(false);
		},
		onError: (err) => {
			setValidationError(err?.message || "Failed to reassign case.");
		}
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!toBureauId) {
			setValidationError("Please select a target bureau.");
			return;
		}
		if (!reason.trim() || reason.trim().length < 3) {
			setValidationError("Remarks must be at least 3 characters.");
			return;
		}
		setValidationError(null);
		mutation.mutate({
			case_ref: caseItem.case_reference_id,
			to_bureau_id: toBureauId,
			to_officer_id: toOfficerId || void 0,
			reason: reason.trim()
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "sm:max-w-md bg-[var(--color-surface)] border border-[var(--color-rule)] rounded-[8px] p-6 shadow-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
						className: "p-0 text-left space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-serif text-base font-semibold text-[var(--color-ink)]",
							children: "Reassign case"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-xs text-[var(--color-text-secondary)]",
							children: [
								"Reassign bureau jurisdiction or officer for case ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[var(--color-text-primary)]",
									children: caseItem.case_reference_id
								}),
								"."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-medium text-[var(--color-text-primary)]",
							children: "Target bureau"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: toBureauId,
							onValueChange: (val) => {
								setToBureauId(val);
								setToOfficerId("");
								if (validationError) setValidationError(null);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-8 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select target bureau" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: bureaus.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: b.id,
								className: "text-xs",
								children: [
									b.name,
									" (",
									b.code,
									")"
								]
							}, b.id)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-medium text-[var(--color-text-primary)]",
							children: "Assigned officer (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: toOfficerId,
							onValueChange: (val) => setToOfficerId(val),
							disabled: isOfficersLoading || officers.length === 0,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "h-8 text-xs bg-surface border-[var(--color-rule)] rounded-[6px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: isOfficersLoading ? "Loading officers..." : "Leave unassigned" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "",
								className: "text-xs",
								children: "Unassigned"
							}), officers.map((off) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: off.id,
								className: "text-xs",
								children: [
									off.full_name,
									" (",
									off.email,
									")"
								]
							}, off.id))] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "reassign-reason",
									className: "text-xs font-medium text-[var(--color-text-primary)]",
									children: "Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-[var(--color-text-muted)]",
									children: "Required for the audit trail"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "reassign-reason",
								placeholder: "State the jurisdictional justification for this transfer...",
								value: reason,
								onChange: (e) => {
									setReason(e.target.value);
									if (validationError) setValidationError(null);
								},
								rows: 3,
								className: "text-xs bg-surface border-[var(--color-rule)] rounded-[6px]"
							}),
							validationError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-[var(--sla-overdue-text)]",
								children: validationError
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
						className: "pt-2 border-t border-[var(--color-rule)] gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => onOpenChange(false),
							className: "h-8 text-xs border-[var(--color-rule)] rounded-[6px]",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							disabled: mutation.isPending || !toBureauId,
							className: "h-8 text-xs font-medium bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 rounded-[6px]",
							children: mutation.isPending ? "Reassigning..." : "Reassign case"
						})]
					})
				]
			})
		})
	});
}
var Tabs = Tabs$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList$1, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = TabsList$1.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger$1, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = TabsTrigger$1.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent$1, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = TabsContent$1.displayName;
var INSTITUTION_METADATA = {
	"inst-01": {
		state: "Rajasthan",
		district: "Kota",
		type: "State University"
	},
	"inst-02": {
		state: "Maharashtra",
		district: "Pune",
		type: "Deemed University"
	},
	"inst-03": {
		state: "Uttar Pradesh",
		district: "Noida",
		type: "Private University"
	},
	"inst-04": {
		state: "Punjab",
		district: "Mohali",
		type: "Private University"
	},
	"inst-05": {
		state: "Tamil Nadu",
		district: "Chennai",
		type: "Deemed University"
	},
	"inst-06": {
		state: "Maharashtra",
		district: "Mumbai",
		type: "Deemed University"
	},
	"inst-07": {
		state: "Karnataka",
		district: "Udupi",
		type: "Deemed University"
	},
	"inst-08": {
		state: "Punjab",
		district: "Phagwara",
		type: "Private University"
	},
	"inst-09": {
		state: "Tamil Nadu",
		district: "Kancheepuram",
		type: "Deemed University"
	},
	"inst-10": {
		state: "Karnataka",
		district: "Bengaluru",
		type: "Private University"
	},
	"inst-11": {
		state: "Tamil Nadu",
		district: "Coimbatore",
		type: "Government-Aided College"
	},
	"inst-12": {
		state: "Odisha",
		district: "Bhubaneswar",
		type: "Deemed University"
	},
	"inst-13": {
		state: "Karnataka",
		district: "Bengaluru",
		type: "Autonomous College"
	},
	"inst-14": {
		state: "Karnataka",
		district: "Bengaluru",
		type: "Affiliated Institute"
	},
	"inst-15": {
		state: "Karnataka",
		district: "Hubballi",
		type: "State Technological University"
	}
};
function CaseDossierView({ caseRef }) {
	const { role } = useRole();
	const isAuditor = role === "AUDITOR";
	const [changeStatusOpen, setChangeStatusOpen] = (0, import_react.useState)(false);
	const [targetStatusOverride, setTargetStatusOverride] = (0, import_react.useState)(void 0);
	const [reassignOpen, setReassignOpen] = (0, import_react.useState)(false);
	const [escalateOpen, setEscalateOpen] = (0, import_react.useState)(false);
	const { data: caseItem, isLoading, isError, error, refetch } = useQuery({
		queryKey: [
			"case",
			caseRef,
			role
		],
		queryFn: () => getCase(caseRef),
		staleTime: 3e4
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 px-6 lg:px-8 max-w-7xl mx-auto space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-32" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-3/4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-1/2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-[var(--color-rule)] pt-6 space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48 w-full" })
			})
		]
	});
	if (isError || !caseItem) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-12 px-6 max-w-xl mx-auto text-center space-y-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 bg-surface border border-[var(--color-rule)] rounded-[4px] space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-8 w-8 text-[var(--sla-overdue-text)] mx-auto" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-lg font-semibold text-[var(--color-ink)]",
					children: "Case record not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-[var(--color-text-secondary)]",
					children: error?.message || `Case file '${caseRef}' could not be retrieved.`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => refetch(),
						className: "text-xs h-8 border-[var(--color-rule)]",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "text-xs h-8 bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/cases",
							children: "Return to case register"
						})
					})]
				})
			]
		})
	});
	const isResolvedOrClosed = caseItem.status === "Resolved" || caseItem.status === "Closed";
	const isClosed = caseItem.status === "Closed";
	const isResolved = caseItem.status === "Resolved";
	const allowedTransitions = getAllowedTransitions(caseItem.status);
	const canChangeStatus = !isAuditor && !isClosed && allowedTransitions.length > 0;
	const canReassign = (role === "ADMIN" || role === "SUPERVISOR") && !isClosed;
	const canEscalate = (role === "ADMIN" || role === "SUPERVISOR") && !isClosed && (caseItem.escalation_level ?? 0) < 2;
	const canReopen = !isAuditor && isResolved && allowedTransitions.includes("In Progress");
	const instMeta = INSTITUTION_METADATA[caseItem.institution_id] || {
		state: "Karnataka",
		district: "Bengaluru",
		type: "Technical Institute"
	};
	const handleOpenStatusModal = (target) => {
		setTargetStatusOverride(target);
		setChangeStatusOpen(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-10 px-6 lg:px-8 max-w-7xl mx-auto space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/cases",
				className: "inline-flex items-center gap-1.5 text-xs font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-colors",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Case register" })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-xs text-[var(--color-text-secondary)] tracking-wider",
							children: caseItem.case_reference_id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-2xl lg:text-3xl font-semibold text-[var(--color-ink)] leading-snug max-w-4xl tracking-tight",
							children: caseItem.subject
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusMark, { status: caseItem.status }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityMark, { priority: caseItem.priority }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlaPill, {
								dueDate: caseItem.due_date,
								isResolved: isResolvedOrClosed
							}),
							caseItem.escalation_level > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-[var(--color-text-secondary)] font-medium bg-[var(--color-page)] px-2 py-0.5 border border-[var(--color-rule)] rounded-[4px]",
								children: ["Escalation level ", caseItem.escalation_level]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifecycleStrip, {
							currentStatus: caseItem.status,
							dueDate: caseItem.due_date,
							isResolved: isResolvedOrClosed,
							variant: "full"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse lg:grid lg:grid-cols-[1fr_340px] gap-10 items-start pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-base font-semibold text-[var(--color-ink)] tracking-tight",
								children: "Institution"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-4 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-medium text-[var(--color-text-primary)] mt-1 text-sm",
										children: caseItem.institution_name
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "AICTE ID"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono text-[var(--color-text-secondary)] mt-1",
										children: caseItem.aicte_permanent_id || "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "State"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-[var(--color-text-primary)] mt-1 font-medium",
										children: instMeta.state
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "District"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-[var(--color-text-primary)] mt-1 font-medium",
										children: instMeta.district
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-[var(--color-text-primary)] mt-1",
										children: instMeta.type
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "Bureau"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
										className: "text-[var(--color-text-primary)] mt-1",
										children: [
											caseItem.bureau_name,
											" (",
											caseItem.bureau_code,
											")"
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "Assigned officer"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-[var(--color-text-primary)] mt-1",
										children: caseItem.assigned_officer_name || "Unassigned"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-[11px] font-medium text-[var(--color-text-muted)] tracking-wider uppercase",
										children: "Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-[var(--color-text-primary)] mt-1",
										children: caseItem.category || "General Grievance"
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-[var(--color-rule)]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-serif text-base font-semibold text-[var(--color-ink)] tracking-tight",
									children: "Description"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-[var(--color-text-primary)] leading-relaxed max-w-3xl whitespace-pre-wrap",
									children: caseItem.description_redacted
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2.5 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-semibold text-[var(--color-ink)]",
										children: "Confidential statement"
									}), isAuditor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedactionBar, {}) : caseItem.description_confidential ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-[var(--color-text-secondary)] bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[6px] p-4 leading-relaxed max-w-3xl whitespace-pre-wrap",
										children: caseItem.description_confidential
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-[var(--color-text-muted)]",
										children: "No confidential complainant statement attached to this grievance."
									})]
								}),
								caseItem.closure_remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-semibold text-[var(--color-ink)]",
										children: "Closure remarks"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-[var(--color-text-secondary)] bg-[var(--color-page)] border border-[var(--color-rule)] rounded-[6px] p-4 leading-relaxed max-w-3xl",
										children: caseItem.closure_remarks
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-[var(--color-rule)]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "space-y-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
								defaultValue: "timeline",
								className: "w-full",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-b border-[var(--color-rule)]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
											className: "bg-transparent p-0 h-auto gap-8 border-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
													value: "timeline",
													className: "border-b-2 border-transparent data-[state=active]:border-[var(--color-action)] data-[state=active]:text-[var(--color-ink)] data-[state=active]:shadow-none rounded-none px-1 py-2.5 text-xs font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-none",
													children: "Timeline"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
													value: "notes",
													className: "border-b-2 border-transparent data-[state=active]:border-[var(--color-action)] data-[state=active]:text-[var(--color-ink)] data-[state=active]:shadow-none rounded-none px-1 py-2.5 text-xs font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-none",
													children: "Notes"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
													value: "history",
													className: "border-b-2 border-transparent data-[state=active]:border-[var(--color-action)] data-[state=active]:text-[var(--color-ink)] data-[state=active]:shadow-none rounded-none px-1 py-2.5 text-xs font-medium text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] transition-none",
													children: "Assignment history"
												})
											]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
										value: "timeline",
										className: "m-0 pt-6 focus-visible:outline-none",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditTimelineTab, { caseRef: caseItem.case_reference_id })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
										value: "notes",
										className: "m-0 pt-6 focus-visible:outline-none",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InternalNotesTab, { caseRef: caseItem.case_reference_id })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
										value: "history",
										className: "m-0 pt-6 focus-visible:outline-none",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentHistoryTab, { caseRef: caseItem.case_reference_id })
									})
								]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "w-full lg:sticky lg:top-8 lg:border-l border-[var(--color-rule)] lg:pl-8 space-y-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-b border-[var(--color-rule)] pb-2.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-sm font-semibold text-[var(--color-ink)] tracking-tight",
							children: "Actions"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => handleOpenStatusModal(),
								disabled: !canChangeStatus,
								className: "w-full bg-[var(--color-action)] text-white hover:bg-[var(--color-action)]/90 h-9 text-xs font-medium rounded-[6px]",
								children: "Change status"
							}),
							canReassign && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setReassignOpen(true),
								className: "w-full text-xs h-8.5 font-normal text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] border-[var(--color-rule)] bg-surface hover:bg-[var(--color-page)] rounded-[6px]",
								children: "Reassign case"
							}),
							canEscalate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setEscalateOpen(true),
								className: "w-full text-xs h-8.5 font-normal text-[var(--sla-overdue-text)] hover:text-[var(--sla-overdue-text)] border-[var(--color-rule)] bg-surface hover:bg-[var(--sla-overdue-bg)]/50 rounded-[6px]",
								children: "Escalate case"
							}),
							canReopen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => handleOpenStatusModal("In Progress"),
								className: "w-full text-xs h-8.5 font-normal text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] border-[var(--color-rule)] bg-surface hover:bg-[var(--color-page)] rounded-[6px]",
								children: "Reopen case"
							}),
							isAuditor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[var(--color-text-muted)] pt-3 leading-relaxed border-t border-[var(--color-rule)]",
								children: "Auditor access is strictly read-only. Status advancement, reassignment, and escalation controls are disabled."
							}),
							isClosed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[var(--color-text-muted)] pt-3 leading-relaxed border-t border-[var(--color-rule)]",
								children: "This case is closed. The lifecycle has terminated and further status transitions are locked."
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeStatusModal, {
				caseItem,
				open: changeStatusOpen,
				onOpenChange: setChangeStatusOpen,
				initialTargetStatus: targetStatusOverride
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReassignModal, {
				caseItem,
				open: reassignOpen,
				onOpenChange: setReassignOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EscalateModal, {
				caseItem,
				open: escalateOpen,
				onOpenChange: setEscalateOpen
			})
		]
	});
}
function CaseDossierRoute() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseDossierView, { caseRef: id });
}
//#endregion
export { CaseDossierRoute as component };
