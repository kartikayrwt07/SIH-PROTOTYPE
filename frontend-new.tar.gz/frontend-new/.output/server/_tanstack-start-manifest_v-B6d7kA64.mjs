//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B6d7kA64.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/__root.tsx",
		children: [
			"/",
			"/ai-triage",
			"/dashboard",
			"/ingest",
			"/login",
			"/sla-radar",
			"/state-machine",
			"/cases/$id",
			"/cases/"
		],
		preloads: [
			"/assets/index-QTNQmt59.js",
			"/assets/button-BOaZD2s5.js",
			"/assets/createLucideIcon-BePiNLCR.js",
			"/assets/preload-helper-m2fBcjh1.js",
			"/assets/link-CLLZqjS_.js",
			"/assets/useRouter-CKNHIGoA.js",
			"/assets/Combination-BF5UEky1.js",
			"/assets/mutation-DRFXSfck.js",
			"/assets/select-D5LBgnmw.js",
			"/assets/sparkles-Bs-x-cPW.js",
			"/assets/x-DhsGUK3I.js",
			"/assets/RoleContext-Dfbw2RMN.js",
			"/assets/dist-V7qNp5kR.js",
			"/assets/cases-Cz-IkvrJ.js",
			"/assets/_id-vSaOc2qX.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-QTNQmt59.js"
		} }]
	},
	"/ai-triage": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/ai-triage.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-triage-CAKFC73Q.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/useMutation-CnSjOY__.js",
			"/assets/PriorityMark-DSH7PoRK.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/EmptyState-BUmmLXlW.js",
			"/assets/textarea-DaDib1Wx.js",
			"/assets/label-CJU1AMAK.js"
		]
	},
	"/dashboard": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-uC3tYnG5.js",
			"/assets/useNavigate-lcMnJdZe.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/circle-alert-Bfn1iP-t.js",
			"/assets/circle-check-dvwT2aLC.js",
			"/assets/SlaPill-B9x2G6Ly.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/DataTable-BP19fd2_.js",
			"/assets/label-CJU1AMAK.js",
			"/assets/skeleton-BQ6XT510.js",
			"/assets/input-DFewJ89B.js"
		]
	},
	"/ingest": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/ingest.tsx",
		children: void 0,
		preloads: [
			"/assets/ingest-DfWxRVVN.js",
			"/assets/useMutation-CnSjOY__.js",
			"/assets/check-CDxrIGbY.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/DataTable-BP19fd2_.js",
			"/assets/EmptyState-BUmmLXlW.js"
		]
	},
	"/login": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DO4XLwOC.js",
			"/assets/useNavigate-lcMnJdZe.js",
			"/assets/input-DFewJ89B.js"
		]
	},
	"/sla-radar": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/sla-radar.tsx",
		children: void 0,
		preloads: [
			"/assets/sla-radar-DZ2S2jBM.js",
			"/assets/useNavigate-lcMnJdZe.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/circle-alert-Bfn1iP-t.js",
			"/assets/lock-Gk46U7zb.js",
			"/assets/search-BkWW5K0u.js",
			"/assets/SlaPill-B9x2G6Ly.js",
			"/assets/PriorityMark-DSH7PoRK.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/DataTable-BP19fd2_.js",
			"/assets/EscalateModal-BhgEod9P.js",
			"/assets/input-DFewJ89B.js"
		]
	},
	"/state-machine": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/state-machine.tsx",
		children: void 0,
		preloads: [
			"/assets/state-machine-B_Ndz6ER.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/check-CDxrIGbY.js",
			"/assets/circle-alert-Bfn1iP-t.js",
			"/assets/circle-check-dvwT2aLC.js",
			"/assets/lock-Gk46U7zb.js",
			"/assets/StatusMark-DDlqNIGf.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/label-CJU1AMAK.js"
		]
	},
	"/cases/$id": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/cases/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-DNQm3EBm.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/useMutation-CnSjOY__.js",
			"/assets/check-CDxrIGbY.js",
			"/assets/dateUtils-CpCNYU6x.js",
			"/assets/circle-alert-Bfn1iP-t.js",
			"/assets/lock-Gk46U7zb.js",
			"/assets/SlaPill-B9x2G6Ly.js",
			"/assets/StatusMark-DDlqNIGf.js",
			"/assets/PriorityMark-DSH7PoRK.js",
			"/assets/textarea-DaDib1Wx.js",
			"/assets/label-CJU1AMAK.js",
			"/assets/skeleton-BQ6XT510.js",
			"/assets/EscalateModal-BhgEod9P.js"
		]
	},
	"/cases/": {
		filePath: "/home/pratik/Documents/Projects/SIH/SIH-PROTOTYPE/frontend-new/src/routes/cases/index.tsx",
		children: void 0,
		preloads: [
			"/assets/cases-B5zuchmv.js",
			"/assets/useQuery-BRoN3UUG.js",
			"/assets/dateUtils-CpCNYU6x.js",
			"/assets/search-BkWW5K0u.js",
			"/assets/SlaPill-B9x2G6Ly.js",
			"/assets/StatusMark-DDlqNIGf.js",
			"/assets/PriorityMark-DSH7PoRK.js",
			"/assets/PageHeader-BlZj6iH3.js",
			"/assets/DataTable-BP19fd2_.js",
			"/assets/dist-Bp3T7v0s.js",
			"/assets/input-DFewJ89B.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
