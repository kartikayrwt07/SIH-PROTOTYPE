globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-10-24T17:00:50.782Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-24T17:00:50.782Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/Combination-BF5UEky1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe5d-w/xHuzdUuCxHW1cm7ota19RdTVc\"",
		"mtime": "2026-10-24T17:00:49.765Z",
		"size": 65117,
		"path": "../public/assets/Combination-BF5UEky1.js"
	},
	"/assets/DataTable-BP19fd2_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a6b-0+HITmOhd4H5atEX44MPqn/l3ro\"",
		"mtime": "2026-10-24T17:00:49.765Z",
		"size": 2667,
		"path": "../public/assets/DataTable-BP19fd2_.js"
	},
	"/assets/EmptyState-BUmmLXlW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"253-4xyP5AEwir5DEjaYZGHv2DlIkM0\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 595,
		"path": "../public/assets/EmptyState-BUmmLXlW.js"
	},
	"/assets/EscalateModal-BhgEod9P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13a9-urQ4oscu1qedrFOM4qa9iL7itr4\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 5033,
		"path": "../public/assets/EscalateModal-BhgEod9P.js"
	},
	"/assets/PageHeader-BlZj6iH3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"27a-q8+hDLsoY+b1KY7erPlGKaHxNBY\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 634,
		"path": "../public/assets/PageHeader-BlZj6iH3.js"
	},
	"/assets/PriorityMark-DSH7PoRK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"297-v4dQ4IPrH8iawkprzJfAZvTbs3w\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 663,
		"path": "../public/assets/PriorityMark-DSH7PoRK.js"
	},
	"/assets/RoleContext-Dfbw2RMN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39c-NnKa2AWUlq3ykq0KTD2GrV5YCVU\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 924,
		"path": "../public/assets/RoleContext-Dfbw2RMN.js"
	},
	"/assets/SlaPill-B9x2G6Ly.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11c1-pkWjQRXLlVP9GHNAgz1wyogqHwY\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 4545,
		"path": "../public/assets/SlaPill-B9x2G6Ly.js"
	},
	"/assets/StatusMark-DDlqNIGf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"285-hyxWaJs6XN9LLcN9LBcDM+0KQP8\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 645,
		"path": "../public/assets/StatusMark-DDlqNIGf.js"
	},
	"/assets/_id-DNQm3EBm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"acd0-b+nvPYsrzybc/GWHqJUKl5FJT2k\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 44240,
		"path": "../public/assets/_id-DNQm3EBm.js"
	},
	"/assets/_id-vSaOc2qX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47d-lF+lCRkv9Jyg/y8gKajRuUJEEXQ\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 1149,
		"path": "../public/assets/_id-vSaOc2qX.js"
	},
	"/assets/ai-triage-CAKFC73Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"278c-QjCTnEm73NN3wjjoT0oRMADJbp0\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 10124,
		"path": "../public/assets/ai-triage-CAKFC73Q.js"
	},
	"/assets/button-BOaZD2s5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12072-kxNVupZ+ym2l1dfIgblWbgWuiqQ\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 73842,
		"path": "../public/assets/button-BOaZD2s5.js"
	},
	"/assets/cases-B5zuchmv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3941-CWoeWhNSjF9ixfY/OJLEjjJ2ShU\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 14657,
		"path": "../public/assets/cases-B5zuchmv.js"
	},
	"/assets/cases-Cz-IkvrJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45a-wbfuRZ5OzmrQwoBCxDzeLjBdfBk\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 1114,
		"path": "../public/assets/cases-Cz-IkvrJ.js"
	},
	"/assets/check-CDxrIGbY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-XV+3BwSpD1xITFUThCUnYUQnVuk\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 124,
		"path": "../public/assets/check-CDxrIGbY.js"
	},
	"/assets/circle-alert-Bfn1iP-t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-MAb6qBr5btP49ak6BCca8SwljZY\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 250,
		"path": "../public/assets/circle-alert-Bfn1iP-t.js"
	},
	"/assets/circle-check-dvwT2aLC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-9Pp18/GPNiGmI0+F5JA2cf+d8vg\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 178,
		"path": "../public/assets/circle-check-dvwT2aLC.js"
	},
	"/assets/createLucideIcon-BePiNLCR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30ac-2EiQGg9z047HGWNV/xEFfCIyugI\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 12460,
		"path": "../public/assets/createLucideIcon-BePiNLCR.js"
	},
	"/assets/dashboard-uC3tYnG5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5521-S2O3uozApkhot4c9vDsjIJlTISM\"",
		"mtime": "2026-10-24T17:00:49.766Z",
		"size": 21793,
		"path": "../public/assets/dashboard-uC3tYnG5.js"
	},
	"/assets/dateUtils-CpCNYU6x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a8-CZC/r+yhaLeM9CcKfUE+4i2iBF4\"",
		"mtime": "2026-10-24T17:00:49.768Z",
		"size": 424,
		"path": "../public/assets/dateUtils-CpCNYU6x.js"
	},
	"/assets/dist-Bp3T7v0s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12dd-DtYDIIPh+49bTGQPOQ+1fYIx990\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 4829,
		"path": "../public/assets/dist-Bp3T7v0s.js"
	},
	"/assets/dist-V7qNp5kR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8313-O3tgd//KV2EgNGkanl7A/YuAT/U\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 33555,
		"path": "../public/assets/dist-V7qNp5kR.js"
	},
	"/assets/ingest-DfWxRVVN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c63-2tAOCpU7bizJQgn+HLwWpR9kQ/s\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 11363,
		"path": "../public/assets/ingest-DfWxRVVN.js"
	},
	"/assets/input-DFewJ89B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"247-0OM/jpHv6Txg6+n+MJlBHH9V4L0\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 583,
		"path": "../public/assets/input-DFewJ89B.js"
	},
	"/assets/label-CJU1AMAK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28e-Hq+II7NfrW29Ngr16hTu6SOkUnM\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 654,
		"path": "../public/assets/label-CJU1AMAK.js"
	},
	"/assets/index-QTNQmt59.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"52dcc-NYlLqIZof2PN3jErcPqWpSU4acw\"",
		"mtime": "2026-10-24T17:00:49.764Z",
		"size": 339404,
		"path": "../public/assets/index-QTNQmt59.js"
	},
	"/assets/link-CLLZqjS_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c00-ffhy950jrxs+lVa7uHYtyurKgbw\"",
		"mtime": "2026-10-24T17:00:49.769Z",
		"size": 11264,
		"path": "../public/assets/link-CLLZqjS_.js"
	},
	"/assets/lock-Gk46U7zb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce-PUb4aZd5XNxO2eE8DXociGsuY8o\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 206,
		"path": "../public/assets/lock-Gk46U7zb.js"
	},
	"/assets/login-DO4XLwOC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1449-23UuecJglMSlAkMat5qcWm3Qgv4\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 5193,
		"path": "../public/assets/login-DO4XLwOC.js"
	},
	"/assets/mutation-DRFXSfck.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d7c-DtiRiXF7iTUnaguxe0DJ0GEjRZs\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 3452,
		"path": "../public/assets/mutation-DRFXSfck.js"
	},
	"/assets/preload-helper-m2fBcjh1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16b6-cKLMszfrkmSZ7WIaM/pCPS/3isg\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 5814,
		"path": "../public/assets/preload-helper-m2fBcjh1.js"
	},
	"/assets/public-sans-latin-400-normal-8Rpg0ruU.woff2": {
		"type": "font/woff2",
		"etag": "\"3928-iX2SzIIY0aEzlACSmABPrY89Xr4\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 14632,
		"path": "../public/assets/public-sans-latin-400-normal-8Rpg0ruU.woff2"
	},
	"/assets/public-sans-latin-500-normal-NlrCPXnF.woff2": {
		"type": "font/woff2",
		"etag": "\"3940-baCUigUI1/n85WQoIB5vH5sH4co\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 14656,
		"path": "../public/assets/public-sans-latin-500-normal-NlrCPXnF.woff2"
	},
	"/assets/public-sans-latin-400-normal-SBbinRkI.woff": {
		"type": "font/woff",
		"etag": "\"4838-MluiDwXLuLPSixodTDamjpXbk70\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 18488,
		"path": "../public/assets/public-sans-latin-400-normal-SBbinRkI.woff"
	},
	"/assets/public-sans-latin-500-normal-vCxiVFAq.woff": {
		"type": "font/woff",
		"etag": "\"485c-99lYEfab/d5AWMS9pXlEiscphnY\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 18524,
		"path": "../public/assets/public-sans-latin-500-normal-vCxiVFAq.woff"
	},
	"/assets/public-sans-latin-600-normal-BR59oU-I.woff": {
		"type": "font/woff",
		"etag": "\"487c-iGT13d2Cr0vfrk/uMHNRzvr6oLY\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 18556,
		"path": "../public/assets/public-sans-latin-600-normal-BR59oU-I.woff"
	},
	"/assets/public-sans-latin-600-normal-Fru-LXNs.woff2": {
		"type": "font/woff2",
		"etag": "\"3900-UhY3tq2GODmpMNNPv2nnBPkASpw\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 14592,
		"path": "../public/assets/public-sans-latin-600-normal-Fru-LXNs.woff2"
	},
	"/assets/public-sans-latin-ext-400-normal-B02wwOdZ.woff": {
		"type": "font/woff",
		"etag": "\"377c-supv3XklfafPbVZ4B80/4yv1llw\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 14204,
		"path": "../public/assets/public-sans-latin-ext-400-normal-B02wwOdZ.woff"
	},
	"/assets/public-sans-latin-ext-400-normal-mk90oQqJ.woff2": {
		"type": "font/woff2",
		"etag": "\"28d4-O8stkt2L353kXEM9rJg6PgXuTc8\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 10452,
		"path": "../public/assets/public-sans-latin-ext-400-normal-mk90oQqJ.woff2"
	},
	"/assets/public-sans-latin-ext-500-normal-BHCCp-na.woff": {
		"type": "font/woff",
		"etag": "\"377c-KDXKZJFMQOp7Iw3YRScNNUffPLM\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 14204,
		"path": "../public/assets/public-sans-latin-ext-500-normal-BHCCp-na.woff"
	},
	"/assets/public-sans-latin-ext-500-normal-DC-z7ASZ.woff2": {
		"type": "font/woff2",
		"etag": "\"28d0-TRfu7JO3qrNtGkIjbdocLT6j/7M\"",
		"mtime": "2026-10-24T17:00:49.771Z",
		"size": 10448,
		"path": "../public/assets/public-sans-latin-ext-500-normal-DC-z7ASZ.woff2"
	},
	"/assets/public-sans-latin-ext-600-normal-DchWdWJ_.woff2": {
		"type": "font/woff2",
		"etag": "\"291c-20ag9xS1MlycAsZuiLM0K7A+gWM\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 10524,
		"path": "../public/assets/public-sans-latin-ext-600-normal-DchWdWJ_.woff2"
	},
	"/assets/public-sans-latin-ext-600-normal-DfkbVac2.woff": {
		"type": "font/woff",
		"etag": "\"37b4-1Y1KKD5xsNV3xM13b6r4E9nusaE\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 14260,
		"path": "../public/assets/public-sans-latin-ext-600-normal-DfkbVac2.woff"
	},
	"/assets/public-sans-vietnamese-400-normal-BO1meqcx.woff": {
		"type": "font/woff",
		"etag": "\"1738-HabX/mFn6st1prnmrLgFdukoFNw\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 5944,
		"path": "../public/assets/public-sans-vietnamese-400-normal-BO1meqcx.woff"
	},
	"/assets/public-sans-vietnamese-400-normal-TxZB8OSn.woff2": {
		"type": "font/woff2",
		"etag": "\"11ac-MysRrsCZLNbu2ZOe2/lUPfCh27c\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 4524,
		"path": "../public/assets/public-sans-vietnamese-400-normal-TxZB8OSn.woff2"
	},
	"/assets/public-sans-vietnamese-500-normal-CXYe29CY.woff": {
		"type": "font/woff",
		"etag": "\"1734-BDzU6Ffip/H9iTuqnzh87rWXnHU\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 5940,
		"path": "../public/assets/public-sans-vietnamese-500-normal-CXYe29CY.woff"
	},
	"/assets/public-sans-vietnamese-500-normal-DjztbcKe.woff2": {
		"type": "font/woff2",
		"etag": "\"1190-f6ZWCx7Lh3gq83jIUTcz43aRNag\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 4496,
		"path": "../public/assets/public-sans-vietnamese-500-normal-DjztbcKe.woff2"
	},
	"/assets/public-sans-vietnamese-600-normal-CcnAzmUX.woff": {
		"type": "font/woff",
		"etag": "\"1738-ofmhZbQwIhy9HrKn18H87uZB7RE\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 5944,
		"path": "../public/assets/public-sans-vietnamese-600-normal-CcnAzmUX.woff"
	},
	"/assets/public-sans-vietnamese-600-normal-P4BtCUdw.woff2": {
		"type": "font/woff2",
		"etag": "\"1194-MxAISce4hGQnf5wj5JNAUjqokt4\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 4500,
		"path": "../public/assets/public-sans-vietnamese-600-normal-P4BtCUdw.woff2"
	},
	"/assets/search-BkWW5K0u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-fvc+M/mBPCaZl7jm9MJoBxnQW14\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 174,
		"path": "../public/assets/search-BkWW5K0u.js"
	},
	"/assets/select-D5LBgnmw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b2d-1ZiHL77o59xHjXwxtYGsKzfSV8w\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 31533,
		"path": "../public/assets/select-D5LBgnmw.js"
	},
	"/assets/skeleton-BQ6XT510.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be-VDsLf0lxLrVrXCUth+WVYnLX9Kk\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 190,
		"path": "../public/assets/skeleton-BQ6XT510.js"
	},
	"/assets/sla-radar-DZ2S2jBM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1927-eHICzzURjvgcQfIl1Kz3OqyKm80\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 6439,
		"path": "../public/assets/sla-radar-DZ2S2jBM.js"
	},
	"/assets/source-serif-4-cyrillic-400-normal-C44pakCn.woff2": {
		"type": "font/woff2",
		"etag": "\"375c-BV0Zl1n2aFns/IUXFQIJgG97UPw\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 14172,
		"path": "../public/assets/source-serif-4-cyrillic-400-normal-C44pakCn.woff2"
	},
	"/assets/source-serif-4-cyrillic-400-normal-DEwCKrdL.woff": {
		"type": "font/woff",
		"etag": "\"3e24-BKvZh1HMVrdq+dboOi88MfoQttY\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 15908,
		"path": "../public/assets/source-serif-4-cyrillic-400-normal-DEwCKrdL.woff"
	},
	"/assets/source-serif-4-cyrillic-600-normal-BDP5YDHD.woff2": {
		"type": "font/woff2",
		"etag": "\"39b8-m+y0KzxdGf/SCLbgPnEZGeFpkyc\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 14776,
		"path": "../public/assets/source-serif-4-cyrillic-600-normal-BDP5YDHD.woff2"
	},
	"/assets/source-serif-4-cyrillic-600-normal-CHh5eQWW.woff": {
		"type": "font/woff",
		"etag": "\"406c-Oa3nEvjvtsKOMms6/0Y07NNKo0w\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 16492,
		"path": "../public/assets/source-serif-4-cyrillic-600-normal-CHh5eQWW.woff"
	},
	"/assets/source-serif-4-cyrillic-ext-400-normal-CWV284fw.woff2": {
		"type": "font/woff2",
		"etag": "\"1bec-Awk2V/IpLGM0uHBmKHvF9TqJHYg\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 7148,
		"path": "../public/assets/source-serif-4-cyrillic-ext-400-normal-CWV284fw.woff2"
	},
	"/assets/source-serif-4-cyrillic-ext-400-normal-CYkrUebz.woff": {
		"type": "font/woff",
		"etag": "\"1fec-nW+CLfnA3XbQPNlEIjYrp6WQEN0\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 8172,
		"path": "../public/assets/source-serif-4-cyrillic-ext-400-normal-CYkrUebz.woff"
	},
	"/assets/source-serif-4-cyrillic-ext-600-normal-D_E8FDgP.woff2": {
		"type": "font/woff2",
		"etag": "\"1c78-mVCI7Tm9B5dZg79tvn17YdcUXdE\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 7288,
		"path": "../public/assets/source-serif-4-cyrillic-ext-600-normal-D_E8FDgP.woff2"
	},
	"/assets/source-serif-4-cyrillic-ext-600-normal-h2VnbV3V.woff": {
		"type": "font/woff",
		"etag": "\"2080-INJ0OVmT0o4+wVehfN+ruc0I4G0\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 8320,
		"path": "../public/assets/source-serif-4-cyrillic-ext-600-normal-h2VnbV3V.woff"
	},
	"/assets/source-serif-4-greek-400-normal-Cw5-AHNN.woff2": {
		"type": "font/woff2",
		"etag": "\"1ef4-6pajgDniVAS+fU455ruAwdyAQqk\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 7924,
		"path": "../public/assets/source-serif-4-greek-400-normal-Cw5-AHNN.woff2"
	},
	"/assets/source-serif-4-greek-400-normal-D_DO3bho.woff": {
		"type": "font/woff",
		"etag": "\"2444-cgrvLbUlEKlhTqLrMW9ChQhSwyA\"",
		"mtime": "2026-10-24T17:00:49.772Z",
		"size": 9284,
		"path": "../public/assets/source-serif-4-greek-400-normal-D_DO3bho.woff"
	},
	"/assets/source-serif-4-greek-600-normal-DdRkKr-1.woff2": {
		"type": "font/woff2",
		"etag": "\"1fc4-TE1Zfzx1AWiIAkmEhjz+0yk9Lh4\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 8132,
		"path": "../public/assets/source-serif-4-greek-600-normal-DdRkKr-1.woff2"
	},
	"/assets/source-serif-4-greek-600-normal-OkzgCkGB.woff": {
		"type": "font/woff",
		"etag": "\"2564-wD22SMGFkfrv7zynDjVJ4D80ka0\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 9572,
		"path": "../public/assets/source-serif-4-greek-600-normal-OkzgCkGB.woff"
	},
	"/assets/source-serif-4-latin-400-normal-C1O10bxN.woff": {
		"type": "font/woff",
		"etag": "\"5e30-VYfQfqhtE/W4npsU3Nj0xRfzBLI\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 24112,
		"path": "../public/assets/source-serif-4-latin-400-normal-C1O10bxN.woff"
	},
	"/assets/source-serif-4-latin-400-normal-DJ5YJwmz.woff2": {
		"type": "font/woff2",
		"etag": "\"4e78-JeAv51QWhETR+W6NhHLOI0K36Cw\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 20088,
		"path": "../public/assets/source-serif-4-latin-400-normal-DJ5YJwmz.woff2"
	},
	"/assets/source-serif-4-latin-600-normal-DeJomR3S.woff": {
		"type": "font/woff",
		"etag": "\"6474-YFmVkCSMGYmVpZ+7mbLDxe4Iawg\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 25716,
		"path": "../public/assets/source-serif-4-latin-600-normal-DeJomR3S.woff"
	},
	"/assets/source-serif-4-latin-600-normal-DouSKlru.woff2": {
		"type": "font/woff2",
		"etag": "\"541c-0uvbIvIqwrx9MZ/erzoMas8DO68\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 21532,
		"path": "../public/assets/source-serif-4-latin-600-normal-DouSKlru.woff2"
	},
	"/assets/source-serif-4-latin-ext-400-normal-B5LksYz5.woff2": {
		"type": "font/woff2",
		"etag": "\"45b4-I0E863XzR1rz+dXXv4suw1up8vU\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 17844,
		"path": "../public/assets/source-serif-4-latin-ext-400-normal-B5LksYz5.woff2"
	},
	"/assets/source-serif-4-latin-ext-400-normal-DKmgyNre.woff": {
		"type": "font/woff",
		"etag": "\"55cc-eIv//c9l+ufc8MaaGUbzoKx3OZA\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 21964,
		"path": "../public/assets/source-serif-4-latin-ext-400-normal-DKmgyNre.woff"
	},
	"/assets/source-serif-4-latin-ext-600-normal-B2fExS53.woff": {
		"type": "font/woff",
		"etag": "\"5828-0qBFCUQCu6QC1BeFrrGfad67OVc\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 22568,
		"path": "../public/assets/source-serif-4-latin-ext-600-normal-B2fExS53.woff"
	},
	"/assets/source-serif-4-latin-ext-600-normal-pa-C5Dkf.woff2": {
		"type": "font/woff2",
		"etag": "\"479c-apyrU8HEuxPlvg8VsXYxl+GRxkU\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 18332,
		"path": "../public/assets/source-serif-4-latin-ext-600-normal-pa-C5Dkf.woff2"
	},
	"/assets/source-serif-4-vietnamese-400-normal-9XEw6Pmr.woff": {
		"type": "font/woff",
		"etag": "\"1fa0-64lJkpTLfpEhtpLxMGtabIeo56E\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 8096,
		"path": "../public/assets/source-serif-4-vietnamese-400-normal-9XEw6Pmr.woff"
	},
	"/assets/source-serif-4-vietnamese-400-normal-DFDfvBrN.woff2": {
		"type": "font/woff2",
		"etag": "\"1898-+MQCmMClyNF3eTlPkiV6vG7WPlk\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 6296,
		"path": "../public/assets/source-serif-4-vietnamese-400-normal-DFDfvBrN.woff2"
	},
	"/assets/source-serif-4-vietnamese-600-normal-B33FcZBi.woff2": {
		"type": "font/woff2",
		"etag": "\"18e4-rqKsXn1Lxj76Lp57b8e8mhbRWPU\"",
		"mtime": "2026-10-24T17:00:49.773Z",
		"size": 6372,
		"path": "../public/assets/source-serif-4-vietnamese-600-normal-B33FcZBi.woff2"
	},
	"/assets/source-serif-4-vietnamese-600-normal-CKUOBVO_.woff": {
		"type": "font/woff",
		"etag": "\"2024-KWbnigJj7hD6CJyIhztaAYnkS6Q\"",
		"mtime": "2026-10-24T17:00:49.774Z",
		"size": 8228,
		"path": "../public/assets/source-serif-4-vietnamese-600-normal-CKUOBVO_.woff"
	},
	"/assets/sparkles-Bs-x-cPW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-nwpGSEgPMSMKvXMiphhexWgrHIg\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 494,
		"path": "../public/assets/sparkles-Bs-x-cPW.js"
	},
	"/assets/state-machine-B_Ndz6ER.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7725-QUfcEAYGZ/H0uQJJsG86AczTs54\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 30501,
		"path": "../public/assets/state-machine-B_Ndz6ER.js"
	},
	"/assets/styles-BQvUtNXq.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"22181-pl++XJVvkTMLtHRtkoEk3Y+kD20\"",
		"mtime": "2026-10-24T17:00:49.775Z",
		"size": 139649,
		"path": "../public/assets/styles-BQvUtNXq.css"
	},
	"/assets/textarea-DaDib1Wx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e1-fWsXRVUlo5l6S3Zf7g5SiA5nhj0\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 481,
		"path": "../public/assets/textarea-DaDib1Wx.js"
	},
	"/assets/useMutation-CnSjOY__.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"93c-uKylHvTzeneNGfWMx20U7GLV8z0\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 2364,
		"path": "../public/assets/useMutation-CnSjOY__.js"
	},
	"/assets/useNavigate-lcMnJdZe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df-uOclAQWiMe83eLrpiMkvFdauCVY\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 223,
		"path": "../public/assets/useNavigate-lcMnJdZe.js"
	},
	"/assets/useQuery-BRoN3UUG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f52-/wB8ZwCCYr0peYC05JFr9YppujY\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 8018,
		"path": "../public/assets/useQuery-BRoN3UUG.js"
	},
	"/assets/useRouter-CKNHIGoA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-mdR9yP2RJ2eqBQSWWDR7Yry6Zik\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 146,
		"path": "../public/assets/useRouter-CKNHIGoA.js"
	},
	"/assets/x-DhsGUK3I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-psQANy8jBg4zzU+fXq5qJIGxtL8\"",
		"mtime": "2026-10-24T17:00:49.770Z",
		"size": 154,
		"path": "../public/assets/x-DhsGUK3I.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_BZe7tu = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_BZe7tu
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
